#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_FILE="$PROJECT_DIR/cliente_godot/project.godot"

if command -v godot4 >/dev/null 2>&1; then
  exec godot4 --editor --path "$PROJECT_DIR/cliente_godot"
fi

if command -v godot >/dev/null 2>&1; then
  exec godot --editor --path "$PROJECT_DIR/cliente_godot"
fi

for candidate in \
  "$HOME/Descargas/Godot_v4.7.2-stable_linux.x86_64" \
  "$HOME/Downloads/Godot_v4.7.2-stable_linux.x86_64"
do
  if [[ -x "$candidate" ]]; then
    exec "$candidate" --editor "$PROJECT_FILE"
  fi
done

printf '%s\n' "No se encontró Godot 4.7.2."
printf '%s\n' "Coloca el ejecutable en ~/Descargas, dale permiso con chmod +x y vuelve a ejecutar."
exit 1
