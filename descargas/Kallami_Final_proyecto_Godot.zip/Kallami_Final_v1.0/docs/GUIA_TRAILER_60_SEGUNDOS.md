# Guía de grabación — tráiler gameplay de 60 segundos

## Configuración obligatoria

Graba el juego real a **1920 × 1080**, 30 o 60 FPS, con el HUD legible. Activa el servidor antes de abrir Godot y entra al perfil antes de empezar a capturar. El video final debe durar entre **55 y 65 segundos**. No muestres la pantalla de perfiles, cargas, edición de código ni caminatas largas sin acción.

> Nota: la consigna pide captura directa del juego. Los cortes sirven para eliminar tiempos muertos; no deben sustituir el gameplay con una cinemática prerenderizada.

## Guion cronometrado

| Tiempo | Imagen que debe verse | Acción y propósito |
|---|---|---|
| 0:00–0:04 | Juan rodeado por una sombra, barra de vida visible | Lanza una piedra con `F`; muestra la onda de la honda y el impacto. Es el gancho. |
| 0:04–0:09 | La sombra persigue a Juan en una zona oscura | Recibe un golpe para que la barra baje a amarillo o rojo y se escuche la tensión. |
| 0:09–0:15 | Nivel 1, casas de adobe y minimapa | Camina hacia una zona todavía oculta; el minimapa debe revelarla mientras avanzas. |
| 0:15–0:22 | Primer plano del diálogo con Florencio | Pulsa `E`; deja reproducir su voz y muestra el retrato con movimiento de boca. |
| 0:22–0:26 | Tarjeta `NIVEL 2 • EL ASCENSO` | Cruza el portal y conserva la transición para demostrar que existen mapas separados. |
| 0:26–0:34 | Santuario de una memoria en el cerro | Recoge una pista con `E`; conserva el HUD y el efecto sonoro completo. |
| 0:34–0:39 | Puente y checkpoint del ascenso | Cruza la bandera y deja aparecer el mensaje de guardado. |
| 0:39–0:44 | Cámara de plata | Corte corto: muestra a los dos guardianes y un ataque con honda. |
| 0:44–0:49 | Pedestales de memoria | Activa el último pedestal y deja que desaparezca el sello. |
| 0:49–0:55 | Altar encendido y pantalla `KALLAMI RESTAURADO` | Acércate al altar y mantén el cierre legible. |
| 0:55–1:00 | Título limpio o montaje de los tres niveles | Añade en edición: `Kallami: Senderos de Plata`, equipo, `Godot 4.7.2` y `Versión final 1.1`. |

## Preparación de la partida para grabar

La ruta completa dura más de un minuto. Haz una toma larga y luego corta los fragmentos indicados. Para lograr los planos finales sin repetir todo, conserva un perfil cercano al final y otro perfil al inicio. El sistema ya separa el progreso de cada uno.

Antes de cada toma:

1. Confirma que el servidor muestre `Uvicorn running`.
2. Entra al perfil correcto.
3. Pulsa `G` en el punto de partida y espera la confirmación verde.
4. Oculta el cursor fuera de la ventana del juego.
5. Inicia OBS, espera dos segundos y realiza la acción.
6. Deja dos segundos extra al final para facilitar el corte.

## Ajustes de OBS

- Resolución base y de salida: `1920x1080`.
- FPS: `30` si la laptop pierde fluidez; `60` si mantiene el juego estable.
- Formato de grabación: `MKV` para evitar perder el archivo por un cierre inesperado.
- Remultiplexado final: **Archivo → Remultiplexar grabaciones → MP4**.
- Audio de escritorio: activado; micrófono: desactivado si la narración se añadirá después.

## Publicación en YouTube

Título recomendado:

```text
Kallami: Senderos de Plata - Gameplay | Equipo Kallami
```

Descripción lista para adaptar:

```text
Kallami: Senderos de Plata es una aventura narrativa 2D dividida en tres niveles: comunidad, ascenso y cámara de plata. Juan debe recuperar tres memorias, enfrentar sombras con su honda y devolver al sendero la historia que protege la comunidad.

Motor: Godot 4.7.2
Género: aventura narrativa, exploración y combate 2D
Estado: versión final académica 1.1

Equipo:
- Brayan Quispe Mamani — cliente, jugabilidad e integración
- Douglas Israel Roman Quispe — servidor FastAPI y persistencia SQLite
- Eduardo Ricardo Condori Mamani — pruebas y Seguridad de la Información

Enlace del proyecto o repositorio: [PEGAR ENLACE]
```

Configura el video como **Público** u **Oculto**, nunca **Privado**. Abre el enlace en una ventana de incógnito antes de entregarlo.

## Lista de control final

- Duración entre 55 y 65 segundos.
- Gameplay real, sin editor ni terminal visibles.
- HUD, vida, objetivo y minimapa legibles.
- Ataque especial durante los primeros 10 segundos.
- Ciclo de movimiento, combate, interacción y pista entre 0:10 y 0:35.
- Al menos un plano reconocible de cada uno de los tres niveles.
- Montaje de clímax entre 0:39 y 0:55.
- Título, motor, equipo y estado al cierre.
- MP4 reproducible a 1080p.
- Enlace probado sin iniciar sesión.
