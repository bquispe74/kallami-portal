#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/cliente_godot/assets/audio/dialogue"
CACHE_BASE="${XDG_CACHE_HOME:-${HOME}/.cache}"
VOICE_ENV="$CACHE_BASE/kallami-voz-natural"
TMP_DIR="$(mktemp -d /tmp/kallami_voz_XXXXXX)"
VOICE="es-BO-MarceloNeural"
RATE="-14%"
PITCH="-8Hz"
FILTER="highpass=f=70,lowpass=f=9000,loudnorm=I=-18:TP=-2:LRA=9"

command -v python3 >/dev/null || { printf 'Falta Python 3.\n' >&2; exit 1; }
command -v ffmpeg >/dev/null || { printf 'Falta FFmpeg. Instálalo antes de continuar.\n' >&2; exit 1; }
mkdir -p "$OUT_DIR" "$CACHE_BASE"

if [[ ! -x "$VOICE_ENV/bin/edge-tts" ]]; then
	python3 -m venv "$VOICE_ENV"
	"$VOICE_ENV/bin/python" -m pip install --disable-pip-version-check "edge-tts==7.2.8"
fi

render_voice() {
	local file_name="$1"
	local dialogue_text="$2"
	local mp3_path="$TMP_DIR/${file_name}.mp3"
	"$VOICE_ENV/bin/edge-tts" \
		--voice "$VOICE" \
		--rate="$RATE" \
		--pitch="$PITCH" \
		--text "$dialogue_text" \
		--write-media "$mp3_path"
	ffmpeg -y -hide_banner -loglevel error \
		-i "$mp3_path" -af "$FILTER" -ar 44100 -ac 1 -c:a pcm_s16le \
		"$OUT_DIR/${file_name}.wav"
	printf 'Generada: %s.wav\n' "$file_name"
}

render_voice "florencio_intro_01" "Juan, el cerro está inquieto. Las sombras despertaron y el camino ya no es seguro."
render_voice "florencio_intro_02" "Cruza el pueblo y entra por el portal de la cumbre. Allí comienza el verdadero ascenso."
render_voice "florencio_intro_03" "En el cerro recupera los tres recuerdos. Tu honda puede dispersar las sombras."
render_voice "florencio_intro_04" "No sigas solamente el brillo de la plata. Escucha lo que protege este pueblo."
render_voice "florencio_repeat" "El sendero está abierto. Ve con cuidado, Juan, y no olvides volver."
render_voice "florencio_all_clues_01" "Ya reuniste los tres recuerdos. El sendero dorado del cerro está abierto."
render_voice "florencio_all_clues_02" "Llega al portal de la cumbre. Allí podrás devolverle su memoria a Kallami."
render_voice "florencio_completed" "La plata puede agotarse; la memoria compartida no. El pueblo volverá a caminar sin miedo."

printf '\nVoces naturales guardadas en %s\n' "$OUT_DIR"
printf 'Los archivos quedan dentro del proyecto y funcionan después sin internet.\n'
