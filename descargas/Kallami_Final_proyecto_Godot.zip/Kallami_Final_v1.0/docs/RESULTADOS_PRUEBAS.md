# Resultados de validación de la versión final

Fecha de ejecución: **28 de septiembre de 2026**.

## Suite automatizada

Comando ejecutado desde `servidor/`:

```bash
python -m pytest -q tests
```

Resultado real:

```text
............                                                             [100%]
12 passed
```

La suite cubre estado del servicio, creación y listado de perfiles, login, rechazo de PIN incorrecto, ausencia de PIN en texto plano, autorización obligatoria, aislamiento entre perfiles, carga y guardado, validación de pistas, checkpoint imposible, progresión por tres niveles, rompecabezas final, reinicio y eliminación en cascada.

## Prueba HTTP de integración

Se levantó Uvicorn sobre una base temporal y se ejecutaron peticiones con `curl`. Respuestas observadas:

```text
GET  /api/estado                         200 OK
POST /api/perfiles                       201 Created
GET  /api/progreso/{perfil}              200 OK
POST /api/progreso                       200 OK
```

El progreso recuperado comienza con vida `5`, posición `(220, 1260)` y ninguna memoria. Las actualizaciones autenticadas pueden conservar el nivel actual, las tres pistas y `puzzle_step`, además de vida, checkpoint y posición.

## Validación estática del cliente

- Los 16 scripts GDScript tienen delimitadores balanceados.
- Todas las rutas `res://` utilizadas por scripts, escena y proyecto existen.
- El retrato de Florencio contiene dos regiones cuadradas de 887 píxeles.
- Los 16 WAV son PCM mono de 16 bits a 44,1 kHz.
- Los scripts de Linux pasaron `bash -n`.

> Nota: la validación visual definitiva debe hacerse al abrir `cliente_godot/project.godot` con Godot 4.7.2 en el equipo de presentación. El entorno de construcción de este paquete no incluye el ejecutable de Godot, por lo que no se afirma una ejecución gráfica que no se realizó aquí.
