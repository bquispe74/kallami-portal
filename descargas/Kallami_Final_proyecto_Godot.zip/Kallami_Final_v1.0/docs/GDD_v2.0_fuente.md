**DOCUMENTO DE DISEÑO DEL JUEGO**

**KALLAMI**

*Senderos de plata*

**GDD grupal v2.0 · Opción B · Semana 2**

| **Dato académico** | **Información** |
|---|---|
| Universidad | Universidad Mayor de San Andrés |
| Carrera | Informática |
| Asignatura | Taller de Proyecto INF-266 |
| Docente | Lic. Brigida Alexandra Carvajal Blanco |
| Equipo | Equipo Kallami |
| Modalidad | Trabajo grupal - opción B |
| Integrantes principales | Brayan Quispe Mamani y Douglas Israel Roman Quispe |
| Apoyo de Seguridad | Eduardo Ricardo Condori Mamani - informe técnico independiente |
| Motor y plataforma | Godot Engine 4.7.2 Compatibility para PC |
| Fecha de actualización | 14 de septiembre de 2026 |

*Proyecto de cuatro semanas basado en un relato oral andino*

# Propósito del documento

Este GDD v2.0 registra la implementación del prototipo Alpha de la opción
B. La versión mantiene la propuesta narrativa y el alcance de cuatro
semanas, pero sustituye las previsiones técnicas de la Semana 1 por
componentes verificables: movimiento, cámara, colisiones, interacción,
NPC, enemigo, HUD, escenario base y primera conexión cliente-servidor.

El núcleo narrativo se basa en el relato oral del Cerro Kallami narrado
por Mariano Quispe y registrado en Pucarani, Cota Cota, el 14 de mayo de 2006. El Cerro Kallami, el extranjero, el hombre aymara y los cántaros de
plata pertenecen al relato de referencia. Juan Huanca, Florencio Mamani,
las sombras enemigas, las pistas y los desafíos son creaciones del equipo
para convertir el relato en una experiencia interactiva; no se presentan
como personajes históricos ni como partes originales del testimonio.

**Decisión de alcance.** La Semana 2 entrega un solo escenario vertical
que demuestra el core loop. Los otros dos niveles y el arte definitivo
permanecen planificados para la Beta.

# 1. Introducción

El proyecto propone un videojuego 2D de acción, exploración y aventura narrativa
inspirado en el relato del Cerro Kallami. Su desarrollo seguirá la
modalidad grupal descrita en el Informe general del proyecto, con una
dupla responsable del cliente y del servidor, además del apoyo
transversal que corresponda. El producto esperado no es un juego
comercial completo, sino un prototipo breve, jugable y respaldado por
evidencia de diseño, implementación y pruebas (Informe general del
proyecto, s. f.).

La guía de la asignatura establece que el trabajo debe comenzar por el
mito, pasar por la adaptación y el Camino del Héroe, y recién después
traducirse en mecánicas, niveles y prototipos (Clase 1: Introducción al
desarrollo de videojuegos, s. f.). Esta secuencia evita programar
funciones aisladas que no sirven a una experiencia concreta. También
coincide con el enfoque playcentric: diseñar, probar con personas y
modificar el juego a partir de lo observado, no solo de las intenciones
del equipo (Fullerton, 2018).

La propuesta adopta un alcance pequeño porque el plazo es de cuatro
semanas. Tendrá tres niveles, un protagonista, un NPC principal, cuatro
mecánicas centrales, un enemigo base y dos tipos de obstáculos. El combate
se limita a un ataque a distancia, tres puntos de salud y patrones de
persecución sencillos. No habrá jefes, árboles de habilidades, inventarios
de armas ni variedad extensa de enemigos.

# 2. Fundamentos y criterios del proyecto

## 2.1 Documentos orientadores

El Informe general del proyecto establece un proceso de prototipado
iterativo, asigna responsabilidades a la dupla de desarrollo y exige que
el GDD se actualice conforme el juego cambie. También define los
entregables semanales, la matriz mínima de pruebas y la necesidad de
demostrar aportes individuales verificables (Informe general del
proyecto, s. f.).

La guía de Clase 1 organiza el trabajo desde el relato andino hasta la
experiencia jugable: mito, adaptación, Camino del Héroe, mecánicas,
niveles, GDD, prototipo y pruebas. Para cuatro semanas recomienda tres
niveles principales, entre tres y cinco mecánicas, un NPC, condiciones
claras de victoria y derrota, interfaz básica, sonido y una pantalla
final (Clase 1: Introducción al desarrollo de videojuegos, s. f.).

## 2.2 Criterios adoptados

La propuesta convierte esos requerimientos en decisiones concretas. El
juego será 2D, de un solo jugador, con vista superior y estética pixel
art. La exploración será la acción principal; la interacción, la
recopilación de pistas y un combate breve completarán el ciclo jugable.
Los niveles serán pequeños y reutilizarán sistemas, arte y componentes de
interfaz. Cualquier función adicional deberá demostrar que mejora el
objetivo principal sin poner en riesgo la entrega.

| **Requisito base**               | **Aplicación en el GDD**             | **Criterio de cumplimiento**                                                        |
|----------------------------------|--------------------------------------|-------------------------------------------------------------------------------------|
| Relato andino investigado        | Relato del Cerro Kallami             | Se identifica narrador, lugar y fecha del registro oral.                            |
| Camino del Héroe                 | Diez etapas adaptadas al recorrido   | Cada etapa narrativa se relaciona con un objetivo, nivel o cambio del protagonista. |
| Tres escenarios o niveles        | Comunidad, ascenso y cámara de plata | Cada nivel tendrá objetivo, obstáculo, recompensa, inicio y salida.                 |
| Entre tres y cinco mecánicas     | Exploración, interacción, pistas y combate | Las cuatro deben funcionar de manera integrada en el prototipo.                |
| Dos tipos de obstáculos          | Peligros ambientales y sombras       | Deben aumentar la dificultad con reglas simples y predecibles.                      |
| Un NPC                           | Florencio Mamani, informante         | Tendrá diálogo y estados vinculados al progreso de la misión.                       |
| Interfaz y condiciones del juego | HUD, pausa, victoria y reinicio      | El jugador recibirá información clara y podrá terminar o reiniciar la partida.      |
| Prototipado iterativo            | Versiones v1.0, Alpha, Beta y final  | Cada semana registrará pruebas, problemas y cambios aplicados.                      |

# 3. Datos generales

| **Campo**            | **Definición**                                                                           |
|----------------------|------------------------------------------------------------------------------------------|
| Título                | Kallami: Senderos de plata                                                               |
| Versión               | GDD grupal v2.0 - Semana 2                                                               |
| Género                | Acción y aventura narrativa con exploración y misterio                                   |
| Perspectiva          | 2D en vista superior (top-down)                                                          |
| Modo                 | Un jugador                                                                               |
| Motor                | Godot Engine 4.7.2 con renderizador Compatibility                                        |
| Plataforma principal | PC                                                                                       |
| Público              | Mayores de 13 años interesados en relatos andinos y juegos breves de misterio            |
| Dificultad           | Baja al inicio y media en los niveles 2 y 3                                              |
| Duración estimada    | 10 a 15 minutos                                                                          |
| Alcance              | Tres niveles, un protagonista, un NPC, cuatro mecánicas, un enemigo y dos obstáculos     |

# 4. Concepto general

## 4.1 Sinopsis y high concept

Kallami: Senderos de plata es un videojuego 2D de acción, exploración y
aventura narrativa. El jugador controla a Juan Huanca, un joven aymara ficticio que parte
desde una comunidad cercana, asciende por los senderos del Cerro Kallami
y entra en una cámara oculta para reconstruir un antiguo acontecimiento
relacionado con un extranjero, un hombre aymara y cántaros de plata.

El combate acompaña a la exploración, pero no sustituye el misterio. El
jugador observa el entorno, conversa con Florencio Mamani, recoge pistas,
evita peligros y dispersa sombras que bloquean rutas. El desenlace exige
comprender lo ocurrido y regresar a la comunidad. La mecánica y la
narración deben sostener la misma pregunta: qué ocurre cuando la riqueza
del cerro se trata como una mercancía y no como parte de una memoria
colectiva.

## 4.2 Elemento diferenciador

El rasgo distintivo es la adaptación de un relato oral local a una
experiencia breve donde la progresión depende de interpretar pistas, no
de acumular fuerza o recursos. La oralidad no se utiliza como
decoración. Los diálogos, sonidos y objetos del escenario funcionan como
fragmentos de una memoria que el jugador debe ordenar.

Este tratamiento exige prudencia. La Convención para la Salvaguardia del
Patrimonio Cultural Inmaterial vincula la protección del patrimonio con
el respeto hacia las comunidades que lo producen y transmiten (UNESCO,
2003). Por esa razón, el juego diferenciará de forma visible el relato
documentado de los elementos creados por el equipo para hacerlo jugable.

# 5. Relato de referencia y criterio cultural

## 5.1 Versión de referencia

La versión de referencia relata que el Cerro Kallami posee
abundante plata. Un gringo llega acompañado por un hombre aymara y
pretende entregarlo como pago para obtener la riqueza del cerro. Cuando
ambos ingresan y encuentran cántaros de plata, el cerro reconoce al
hombre aymara como su nieto. Las condiciones cambian, el cerro se cierra
y el gringo desaparece.

**Criterio académico.** La adaptación conserva los acontecimientos
centrales comunicados en el relato oral y señala por separado cada
elemento ficticio creado para la jugabilidad.

## 5.2 Fuente del relato

El relato fue narrado por Mariano Quispe y registrado en Pucarani, Cota
Cota, el 14 de mayo de 2006. En este GDD se cita como relato oral. Si la
docente facilita una ficha archivística, una transcripción o el nombre de
la persona que realizó el registro, esos datos se incorporarán en la
siguiente versión sin modificar el núcleo de la propuesta.

| **Elemento** | **Dato registrado** | **Estado de verificación** |
|---|---|---|
| Narrador | Mariano Quispe | Identificado con los datos proporcionados |
| Procedencia | Pucarani, Cota Cota | Identificada con los datos proporcionados |
| Fecha del registro | 14 de mayo de 2006 | Identificada con los datos proporcionados |
| Soporte primario | Transcripción, audio o ficha archivística | Pendiente de adjuntar si la docente lo solicita |

Esta situación no autoriza a completar vacíos con información inventada.
Hasta consultar el soporte primario, el equipo conservará únicamente los
acontecimientos ya identificados y mantendrá separados los recursos creados
para la adaptación.

## 5.3 Protocolo de uso responsable

1.  Solicitar o localizar la transcripción, audio, ficha de archivo o
    > documento original.

2.  Comparar el contenido original con el resumen incluido en este GDD.

3.  Confirmar nombres, lugares, fecha de registro, narrador y
    > procedencia.

4.  Separar los hechos del relato de las adiciones realizadas para el
    > videojuego.

5.  Consultar con la docente cualquier duda antes de fijar diálogos o
    > representaciones culturales.

6.  Registrar en el GDD cada cambio narrativo y la razón de su
    > incorporación.

# 6. Adaptación grupal

## 6.1 Criterio de adaptación

La nueva versión no reproduce el relato palabra por palabra. Convierte
su conflicto en una investigación jugable y mantiene el Cerro Kallami
como centro de la experiencia. El protagonista recorre tres espacios,
encuentra información fragmentada y llega a una cámara donde comprende
la relación entre el cerro, el hombre aymara y la ambición del
extranjero.

Las pistas, el NPC y los obstáculos son recursos creados para el
videojuego. No se presentarán como parte del testimonio oral. Esta
distinción permite trabajar con libertad narrativa sin atribuir a una
comunidad detalles que el equipo no ha confirmado.

## 6.2 Elementos conservados

- El Cerro Kallami como espacio central y entidad narrativa.

- La presencia del hombre aymara y del extranjero.

- Los cántaros de plata y el conflicto provocado por la ambición.

- El ingreso al interior del cerro y su cierre.

- La relación del hombre aymara con el cerro.

## 6.3 Elementos creados para la jugabilidad

- Juan Huanca, protagonista ficticio que investiga los hechos tiempo después.

- Florencio Mamani, NPC ficticio que introduce la misión y ofrece contexto.

- Tres pistas obligatorias que desbloquean el acceso final.

- Rutas falsas, terreno rocoso y zonas de visibilidad limitada.

- Un sistema de objetivos, checkpoints y reinicio.

- Sombras enemigas y una honda de uso jugable. Estos elementos no forman
  parte del relato oral.

# 7. Estructura narrativa: Camino del Héroe

El Camino del Héroe se usa como herramienta de organización, no como
fórmula rígida. La guía de la asignatura trabaja con diez etapas
simplificadas; su función es conectar la transformación del protagonista
con la progresión de los niveles (Clase 1: Introducción al desarrollo de
videojuegos, s. f.). La estructura deriva de un modelo narrativo más
amplio asociado a Campbell (2008), pero aquí se reduce para ajustarse a
un prototipo corto.

| **Etapa**        | **Aplicación en el videojuego**                                                                     |
|------------------|-----------------------------------------------------------------------------------------------------|
| Mundo ordinario  | Juan Huanca vive en una comunidad cercana al Cerro Kallami.                                        |
| Llamado          | Aparece una pista relacionada con el antiguo ingreso al cerro.                                      |
| Duda             | El protagonista teme que la búsqueda repita el peligro del relato.                                  |
| Mentor           | Florencio Mamani explica lo que conoce y entrega la primera orientación.                            |
| Cruce del umbral | El protagonista abandona la comunidad e inicia el ascenso.                                          |
| Pruebas          | Explora rutas, evita zonas peligrosas y reúne fragmentos de información.                            |
| Prueba principal | Ingresa en la cámara de plata y debe interpretar correctamente las pistas.                          |
| Recompensa       | Comprende el acontecimiento y obtiene la evidencia narrativa final.                                 |
| Regreso          | Sale del cerro y vuelve a la comunidad.                                                             |
| Transformación   | Reconoce que la memoria y el vínculo comunitario no pueden reducirse al valor material de la plata. |

# 8. Personajes

## 8.1 Protagonista

| **Aspecto**    | **Definición**                                                                           |
|----------------|------------------------------------------------------------------------------------------|
| Nombre         | Juan Huanca                                                                              |
| Rol            | Protagonista e investigador                                                              |
| Edad           | 23 años                                                                                  |
| Personalidad   | Observador, prudente y persistente                                                       |
| Motivación     | Comprender el antiguo suceso y evitar que la búsqueda de riqueza vuelva a causar daño    |
| Habilidades    | Movimiento, interacción, lectura de pistas y ataque a distancia con honda                |
| Estadísticas   | Tres puntos de salud; sin fuerza, experiencia ni árbol de habilidades                    |
| Relación       | Recibe la misión de Florencio y reconstruye el relato del Cerro Kallami                  |
| Transformación | Pasa de buscar una explicación individual a reconocer el valor de la memoria comunitaria |

## 8.2 NPC principal

El prototipo incluirá un solo NPC principal: Florencio Mamani, informante
de la comunidad de 65 años. Es un personaje ficticio creado para la
adaptación. Su función no será resolver el misterio, sino orientar a
Juan, activar la misión y reaccionar cuando el protagonista regrese.
Florencio es sereno, observador y prudente; no participa en el combate.

| **Aspecto** | **Definición** |
|---|---|
| Nombre | Florencio Mamani |
| Clasificación | NPC aliado y mentor narrativo |
| Función | Presentar el contexto, activar la misión, orientar y reconocer el regreso |
| Personalidad | Sereno, observador y prudente |
| Habilidades | Diálogo contextual, activación de misión y respuesta al progreso; no combate |
| Relación con Juan | Le entrega la orientación inicial y valida la reconstrucción al final |

| **Estado**        | **Comportamiento**                                        | **Transición**                              |
|-------------------|-----------------------------------------------------------|---------------------------------------------|
| Idle              | Permanece en su ubicación y muestra señal de interacción. | El jugador entra en el área y presiona E.   |
| Diálogo inicial   | Presenta el contexto y el objetivo.                       | Finaliza el diálogo y activa la misión.     |
| Misión activa     | Recuerda al jugador qué debe buscar.                      | Juan obtiene las tres pistas y vuelve.      |
| Diálogo posterior | Reconoce el avance y pide ordenar los hechos.             | Juan completa la reconstrucción final.      |
| Completado        | Muestra el cierre narrativo.                              | Se activa la pantalla final.                |

Diálogo inicial de referencia: “El sendero conserva señales de quienes
entraron antes. Obsérvalas antes de avanzar”. Diálogo final de
referencia: “La plata quedó en el cerro; lo que vuelve con nosotros es la
memoria”. Estas líneas pertenecen a la adaptación y podrán ajustarse sin
atribuirlas a Mariano Quispe.

## 8.3 Figuras del relato

El extranjero, el hombre aymara y el Cerro Kallami aparecerán mediante
narración ambiental, imágenes, diálogos o una escena breve. No se
programarán como tres sistemas complejos de NPC. Esta decisión conserva
su función narrativa sin multiplicar animaciones y comportamientos.

## 8.4 Enemigo: sombra errante

La sombra errante es una creación ficticia del equipo y no pertenece al
relato oral. Su única función es introducir un desafío de combate breve.
Utilizará cuatro estados fáciles de implementar y comprobar.

| **Estado** | **Comportamiento** | **Transición** |
|---|---|---|
| Espera | Permanece dentro de una zona pequeña. | Juan entra en el radio de detección. |
| Persecución | Se dirige hacia Juan evitando obstáculos simples. | Entra en rango de contacto o pierde al jugador. |
| Ataque | Produce un punto de daño y espera antes de repetirlo. | Termina el enfriamiento o Juan se aleja. |
| Dispersa | Reproduce la animación final y deja de colisionar. | Recibe dos impactos de la honda. |

![Figura 1. Boceto conceptual de Juan Huanca, Florencio Mamani y la sombra enemiga. Diseños ficticios para el prototipo.](assets/boceto_personajes.png){width=92%}

# 9. Objetivos y core gameplay loop

## 9.1 Objetivo principal

Explorar el Cerro Kallami, reunir las pistas necesarias para reconstruir
el acontecimiento relacionado con la plata y regresar a la comunidad
después de comprender su significado.

## 9.2 Objetivos secundarios

- Hablar con el NPC informante.

- Obtener la primera pista en el nivel 1 y dos pistas en el nivel 2.

- Evitar peligros ambientales y dispersar sombras que bloquean rutas.

- Abrir el acceso a la cámara final.

- Interpretar correctamente la información reunida.

## 9.3 Core gameplay loop

**Ciclo principal.** RECIBIR OBJETIVO -> EXPLORAR -> INTERACTUAR ->
ENCONTRAR PISTA -> EVITAR O COMBATIR -> DESBLOQUEAR RUTA -> AVANZAR.

El ciclo es breve y se repite con variaciones en los tres niveles. Cada
acción produce una respuesta visible o sonora. Schell (2019) plantea el
diseño como una experiencia compuesta por elementos que deben observarse
en conjunto; siguiendo esa idea, ninguna mecánica se conservará solo
porque sea técnicamente atractiva. Debe contribuir al misterio, a la
progresión o a la comprensión del jugador.

# 10. Mecánicas y reglas

## 10.1 Mecánicas principales

| **Mecánica**           | **Descripción**                                               | **Criterio mínimo de funcionamiento**                                                         |
|------------------------|---------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
| Exploración            | Movimiento en cuatro direcciones por escenarios 2D.           | El jugador se desplaza sin atravesar colisiones y la cámara mantiene el área jugable visible. |
| Interacción            | Conversación con NPC y examen de objetos o puntos de interés. | La acción E solo se activa dentro del área correspondiente y produce feedback.                |
| Recopilación de pistas | Registro de tres elementos narrativos obligatorios.           | El HUD actualiza el progreso y las rutas se desbloquean según el estado real.                 |
| Combate breve          | Ataque direccional con honda contra un solo tipo de sombra.   | El ataque respeta enfriamiento; el impacto reduce salud y la derrota reinicia el tramo.       |

## 10.2 Reglas

1.  El jugador debe completar el objetivo del nivel para acceder al
    > siguiente.

2.  Las pistas obligatorias no pueden recogerse más de una vez.

3.  Los peligros ambientales se evitan; las sombras pueden esquivarse o
    > dispersarse mediante el ataque.

4.  Juan dispone de tres puntos de salud. Recibir tres impactos o caer
    > en una zona peligrosa lo devuelve al checkpoint más reciente.

5.  El nivel final solo puede resolverse después de reunir todas las
    > pistas.

6.  El juego debe mostrar una respuesta clara ante cada interacción
    > válida o inválida.

7.  El ataque tendrá un enfriamiento inicial de 0,45 segundos y no
    > utilizará un inventario de munición.

# 11. Escenarios y niveles

| **Nivel**              | **Lugar**                  | **Objetivo**                                      | **Obstáculo**                                          | **Recompensa**                    |
|------------------------|----------------------------|---------------------------------------------------|--------------------------------------------------------|-----------------------------------|
| 1\. La advertencia     | Comunidad cercana al cerro | Hablar con el NPC y comprender la misión          | Localizar al informante y seguir el recorrido tutorial | Primera pista y acceso al sendero |
| 2\. El ascenso         | Senderos del Cerro Kallami | Obtener la segunda y tercera pista                 | Terreno peligroso, rutas falsas y sombras              | Apertura del acceso al interior   |
| 3\. La cámara de plata | Interior del Cerro Kallami | Ordenar los tres hechos y regresar                 | Dos sombras y una zona de caída                        | Resolución del misterio y regreso |

## 11.1 Nivel 1: La advertencia

Funciona como tutorial integrado. El jugador aprende a moverse,
interactuar y leer el objetivo. La conversación con el NPC entrega el
contexto mínimo y evita una introducción extensa. El nivel termina
cuando se recoge la primera pista y se cruza la salida hacia el sendero.

## 11.2 Nivel 2: El ascenso

Introduce la exploración completa. Las rutas falsas no son laberintos
grandes: son desvíos cortos que enseñan al jugador a observar señales
del entorno. El riesgo proviene de zonas de caída, terreno bloqueado y
visibilidad reducida. Una sombra introduce el combate sin interrumpir la
exploración. Al reunir las pistas segunda y tercera, se activa la entrada
del cerro.

## 11.3 Nivel 3: La cámara de plata

Reutiliza las mecánicas ya aprendidas y agrega una reconstrucción final.
Juan debe superar un encuentro breve con dos sombras y ordenar los tres
hechos del relato. Un orden incorrecto mantiene activa la interfaz para
un nuevo intento; el orden correcto activa el regreso. No habrá jefe de
combate.

![Figura 2. Boceto visual de los tres niveles: comunidad, ascenso y cámara interior.](assets/boceto_niveles.png){width=96%}

![Figura 3. Mapas funcionales con inicio, salida, NPC, pistas, enemigos, peligros y checkpoints.](assets/mapas_niveles.png){width=96%}

# 12. Objetos y obstáculos

## 12.1 Objetos relevantes

| **Objeto**           | **Función jugable**                                         | **Condición**                                                   |
|----------------------|-------------------------------------------------------------|-----------------------------------------------------------------|
| Fragmentos de memoria | Desbloquean rutas y completan la reconstrucción del relato. | Tres obligatorios; representación visual creada para el juego.  |
| Honda                 | Permite dispersar sombras mediante un proyectil simple.     | Sin munición; ataque limitado por enfriamiento.                  |
| Marcador del sendero | Orienta al jugador y reduce la desorientación.              | Elemento de navegación, no objeto coleccionable.                |
| Acceso a la cámara   | Representa el bloqueo del nivel final.                      | Se activa automáticamente cuando se cumplen los objetivos.      |

## 12.2 Obstáculos

| **Obstáculo** | **Comportamiento** | **Dificultad prevista** | **Forma de superarlo** |
|---|---|---|---|
| Peligros ambientales | Zonas de caída y terreno bloqueado reducen salud o reinician el tramo. | Baja en el nivel 1 y media en los niveles 2 y 3. | Observar el recorrido y utilizar caminos seguros. |
| Sombras enemigas | Permanecen en espera, detectan a Juan, lo persiguen y atacan por contacto. | Media: se mueven más lento que Juan y se dispersan con dos impactos. | Esquivarlas o acertar dos ataques con la honda. |

## 12.3 Contenido de las tres pistas

| **Pista** | **Ubicación** | **Información del relato** | **Efecto jugable** |
|---|---|---|---|
| Fragmento 1: La llegada | Nivel 1, después del diálogo | Un extranjero ingresó acompañado por un hombre aymara en busca de la plata. | Activa la salida hacia el ascenso. |
| Fragmento 2: Los cántaros | Nivel 2, ruta occidental | Dentro del cerro encontraron cántaros de plata. | Revela el segundo tramo del sendero. |
| Fragmento 3: El reconocimiento | Nivel 2, ruta oriental | El cerro reconoció al hombre aymara como su nieto; luego se cerró y el extranjero desapareció. | Abre el acceso a la cámara final. |

# 13. Interfaz y experiencia de usuario

## 13.1 Pantallas

- Menú principal: título, iniciar, opciones, créditos y salir.

- HUD: tres puntos de salud, objetivo actual e indicador de pistas obtenidas.

- Diálogo: nombre o función del hablante, texto y control para
  continuar.

- Pausa: continuar, reiniciar nivel y volver al menú.

- Pantalla final: resultado narrativo y opción de regresar al menú.

**Exclusiones de interfaz.** No habrá inventario, barra de energía ni
contador de munición. La única información persistente en pantalla será
salud, objetivo y pistas.

## 13.2 Principios de uso

La interfaz debe informar sin ocupar gran parte de la pantalla. El
objetivo aparecerá al inicio del nivel y podrá consultarse en el HUD.
Cuando una pista se recoja, el juego mostrará una señal visual y un
sonido corto. Si el jugador intenta interactuar fuera del área válida,
no se abrirán ventanas ni diálogos.

![Figura 4. Wireframes del menú, HUD, diálogo y pantalla final.](assets/wireframes_ui.png){width=96%}

# 14. Arte, animación y sonido

## 14.1 Dirección visual

El juego utilizará pixel art 2D de detalle moderado, inspirado en la
claridad visual de los juegos retro sin copiar personajes ni escenarios
de títulos existentes. La perspectiva será superior y los escenarios se
construirán con piezas modulares reutilizables. La paleta combinará
tonos tierra, azules fríos y contrastes cálidos en puntos narrativos.

La representación de prendas, objetos y símbolos culturales se basará en
referencias verificables. Cuando un recurso sea inventado para el juego,
se registrará como diseño ficticio. Esta práctica reduce el riesgo de
presentar una creación del equipo como si fuera parte del relato oral.

## 14.2 Animaciones mínimas

- Quieto y caminar en cuatro direcciones.

- Interacción o gesto breve del protagonista.

- Idle y respuesta de diálogo del NPC.

- Activación de pista, acceso y checkpoint.

- Ataque de Juan, persecución, impacto y dispersión de la sombra.

## 14.3 Sonido

La banda sonora será breve y atmosférica. Se priorizarán viento, pasos,
ecos, ambiente de montaña, confirmaciones de interfaz y un motivo
musical para el final. Cualquier música tradicional deberá contar con
una licencia o autorización clara; no se utilizará una grabación
encontrada en internet sin revisar sus derechos.
Los diálogos serán únicamente textuales; no se grabarán voces para esta
versión.

# 15. Controles

| **Acción**        | **Control**     | **Respuesta esperada**                                                     |
|-------------------|-----------------|----------------------------------------------------------------------------|
| Movimiento        | WASD o flechas  | Desplazamiento en cuatro direcciones con animación correspondiente.        |
| Interactuar       | E               | Abre diálogo, examina un objeto o recoge una pista dentro del área válida. |
| Atacar            | F               | Ejecuta un ataque breve en la última dirección de movimiento.              |
| Continuar diálogo | E, Espacio o Enter | Muestra la siguiente línea o cierra la conversación.                    |
| Pausa             | Esc             | Detiene el juego y abre el menú de pausa.                                  |

## 15.1 Movimiento, cámara y colisiones

Juan utilizará `CharacterBody2D` y una velocidad inicial de 180 píxeles
por segundo, valor que se ajustará mediante pruebas. `Camera2D` seguirá
al personaje con suavizado moderado y límites asociados al tamaño de
cada nivel. La resolución interna será 960 × 540, escalada a la ventana
sin deformar el pixel art.

Las capas de colisión separarán jugador, paredes, peligros, enemigos,
proyectiles y áreas de interacción. El ataque solo afectará a las sombras;
las pistas y el NPC responderán únicamente al área de interacción.

# 16. Condiciones del juego

## 16.1 Victoria

El jugador gana cuando completa los tres niveles, reúne las pistas
obligatorias, interpreta correctamente el acontecimiento final y activa
el regreso a la comunidad.

## 16.2 Derrota y reinicio

El prototipo no tendrá una muerte permanente. Juan pierde un punto de
salud por contacto enemigo. Al perder los tres puntos o caer en una zona
peligrosa, regresa al checkpoint más reciente con la salud restaurada.
Una reconstrucción final incorrecta permite reordenar las pistas sin
reiniciar todo el nivel. El progreso conservado será únicamente el
registrado en el último checkpoint.

## 16.3 Inicio, progresión y cierre

La secuencia final será: menú principal, nivel 1, nivel 2, nivel 3,
regreso breve al escenario del nivel 1, diálogo final con Florencio y
pantalla de cierre. En el Alpha, Godot genera un `player_id` local y
consulta su progreso mediante HTTP. Si el servicio no responde, la
partida puede comenzar y el HUD informa la desconexión; el siguiente
checkpoint vuelve a intentar el guardado.

# 17. Diseño técnico del cliente

Godot organiza el contenido mediante nodos y escenas reutilizables, lo
que permite separar personaje, niveles, interfaz y sistemas globales
(Godot Engine contributors, s. f.-a). Esta arquitectura resulta adecuada
para distribuir el trabajo y evitar que toda la lógica quede concentrada
en una sola escena. La documentación oficial también propone integrar
una escena principal con instancias de elementos previamente
construidos, un patrón útil para este prototipo (Godot Engine
contributors, s. f.-b).

## 17.1 Estructura implementada en el Alpha

El prototipo adopta una escena principal mínima y crea sus componentes
desde scripts separados. Esta solución reduce archivos provisionales,
permite importar el proyecto sin reconstruir nodos y mantiene visible la
responsabilidad de cada sistema.

| **Archivo o sistema** | **Responsabilidad en Alpha 0.1** |
|-----------------------|----------------------------------|
| `main.tscn` | Punto de entrada del proyecto. |
| `main.gd` | Construcción del escenario, core loop, objetivos y señales. |
| `player.gd` | Movimiento, cámara, colisión, interacción, ataque, salud y reinicio. |
| `npc_florencio.gd` | Estados y diálogos provisionales de Florencio Mamani. |
| `shadow.gd` | Patrulla, detección, persecución, daño y dispersión. |
| `clue.gd` | Activación y recolección única de la primera pista. |
| `checkpoint.gd` | Punto de reaparición y solicitud de guardado. |
| `level_art.gd` | Escenario provisional, obstáculos, colisiones y salida. |
| `hud.gd` | Objetivo, salud, pistas, diálogo, pausa y estado del servidor. |
| `GameManager` | Identificador local, solicitudes HTTP y progreso recuperado. |

## 17.2 Señales y estados

Los sistemas se comunicarán mediante señales como `interaction_requested`,
`clue_collected`, `health_changed`, `enemy_defeated`,
`objective_updated`, `checkpoint_reached` y `level_completed`.
El uso de señales reduce dependencias directas entre escenas y facilita
probar cada componente de forma aislada. Los nombres definitivos se
documentarán en el repositorio.

## 17.3 Organización de recursos

| **Carpeta**   | **Contenido**                                  |
|---------------|------------------------------------------------|
| cliente_godot/ | Proyecto Godot importable y escena principal. |
| cliente_godot/scripts/ | Jugabilidad, NPC, HUD, escenario e integración. |
| servidor/app/ | API FastAPI y reglas de validación. |
| servidor/data/ | Base SQLite creada en la primera ejecución. |
| servidor/tests/ | Pruebas automáticas del contrato y reglas. |
| docs/ | GDD, contrato, guía de demo, pruebas y bitácora. |

## 17.4 Control de versiones

El equipo utilizará Git y un repositorio compartido. La rama `main`
contendrá versiones demostrables; las tareas se desarrollarán en ramas
breves con el formato `feature/nombre-tarea`. Cada commit deberá indicar
una acción concreta, por ejemplo: `feat: movimiento y colisiones del
jugador`. Al final de cada semana se creará una etiqueta de versión y se
registrará su relación con el GDD.

# 18. Integración con Ingeniería de Sistemas

La modalidad grupal asigna a Brayan Quispe Mamani el cliente y la
jugabilidad, mientras Douglas Israel Roman Quispe se ocupa del servidor y
los datos (Informe general del proyecto, s. f.). La integración será
obligatoria, pero limitada al progreso de una partida individual. No se
crearán salas multijugador, sincronización de movimiento ni inventarios
en línea.

El cliente Godot utiliza `HTTPRequest` para intercambiar JSON con una API
desarrollada con FastAPI. El servidor registra el identificador del
jugador, el nivel, las pistas, el checkpoint y la finalización de la
partida en SQLite. La integración fue confirmada como obligatoria y se
mantiene limitada al progreso de una partida individual.

| **Operación** | **Método y ruta implementada** | **Datos principales** | **Respuesta esperada** |
|---|---|---|---|
| Estado del servicio | `GET /api/estado` | Sin cuerpo | Estado y versión del Alpha |
| Guardar avance | `POST /api/progreso` | jugador, nivel, pistas, checkpoint y finalización | Progreso validado y fecha |
| Consultar avance | `GET /api/progreso/{player_id}` | Identificador local | Estado persistido o código 404 |

La API valida rangos, checkpoints permitidos, saltos de nivel y aumentos
imposibles de pistas. Utiliza consultas SQL parametrizadas. La mesa de
Redes revisará el formato JSON, los tiempos de espera y el manejo de
desconexión. No se requiere predicción de movimiento porque la partida
no es multijugador.

![Figura 5. Arquitectura mínima del cliente, servidor, datos y apoyos transversales.](assets/arquitectura.png){width=96%}

**Límite.** Este documento no incluye auditoría, pentesting,
autenticación avanzada, protección de cuentas ni servidor autoritativo.
Eduardo desarrollará el aporte de Seguridad de la Información en un
informe separado.

# 19. Alcance del prototipo

## 19.1 Incluido

- Un protagonista controlable.

- Un NPC principal con cinco estados sencillos.

- Tres niveles jugables y conectados.

- Exploración, interacción, recolección de pistas y combate breve.

- Dos tipos de obstáculos: peligros ambientales y sombras enemigas.

- Menú, HUD, pausa, checkpoints y pantalla final.

- Sonido ambiental, efectos y música con licencia.

- Integración mínima cliente-servidor para registrar sesión y progreso.

## 19.2 Excluido de la primera versión

- Jefes, variedad de armas, munición e inventarios de combate.

- Inventario de supervivencia o múltiples estadísticas.

- Multijugador y sincronización en tiempo real.

- Generación procedural de mapas.

- Más de un NPC con comportamiento complejo.

- Finales múltiples y cinemáticas extensas.

## 19.3 Corte funcional de la Semana 2

El Alpha no intenta presentar los tres niveles terminados. Implementa un
escenario tutorial que concentra las funciones necesarias para comprobar
la arquitectura: Juan se mueve y colisiona, conversa con Florencio,
activa la misión, atraviesa un checkpoint, encuentra una pista, puede
enfrentar una sombra y llega a una salida. El servidor guarda y recupera
el progreso. Esta sección vertical permite corregir los sistemas antes de
duplicarlos en los niveles 2 y 3.

# 20. Plan de trabajo de cuatro semanas

| **Semana** | **Tareas principales** | **Responsables** | **Producto** |
|---|---|---|---|
| 1 | Cerrar GDD, bocetos, roles, escenas, contrato HTTP/JSON y repositorio. | Brayan, Douglas y equipo | GDD v1.0, bocetos, lista de tareas y arquitectura |
| 2 | Implementar movimiento, colisiones, interacción, ataque, enemigo base, API y persistencia inicial. | Brayan y Douglas; revisión IA/Redes | Alpha 0.1, API inicial y GDD v2.0 |
| 3 | Integrar tres niveles, NPC, pistas, HUD, audio, checkpoints y conexión completa. | Brayan y Douglas | Beta jugable y GDD v3.0 |
| 4 | Probar con tres personas externas, corregir errores, cerrar evidencias, build y presentación. | Equipo completo | Build final, matriz de pruebas, GDD final y video |

# 21. Plan inicial de pruebas

Las pruebas se planifican desde la primera semana para que cada sistema
tenga una condición observable. Fullerton (2018) señala que el prototipo
y el playtesting permiten descubrir problemas que no aparecen en la
descripción escrita. El equipo utilizará la matriz mínima propuesta por
el informe oficial y distingue las comprobaciones automáticas de las que
todavía requieren ejecución visual en el equipo del grupo.

| **ID** | **Elemento** | **Resultado esperado** | **Estado al generar Alpha** |
|---|---|---|---|
| P01 | Controles | Juan responde a WASD y flechas. | Pendiente de ejecución local |
| P02 | Colisiones | Juan no atraviesa límites ni obstáculos. | Pendiente de ejecución local |
| P03 | Cámara | La cámara sigue al jugador dentro del mapa. | Pendiente de ejecución local |
| P04 | Objetivo y HUD | Objetivo, salud y pistas responden al estado. | Pendiente de ejecución local |
| P05 | NPC y diálogo | Florencio activa y actualiza la misión. | Pendiente de ejecución local |
| P06 | Pista | Solo puede recogerse una vez y desbloquea la salida. | Pendiente de ejecución local |
| P07 | Sombra | Patrulla, persigue, daña y se dispersa con dos ataques. | Pendiente de ejecución local |
| P08 | Reinicio | La derrota devuelve al checkpoint con salud completa. | Pendiente de ejecución local |
| P09 | Core loop | Hablar, explorar, superar riesgo, recoger y avanzar forma un ciclo completo. | Pendiente de ejecución local |
| P10 | Servidor | La API guarda y recupera progreso. | Prueba automatizada aprobada |
| P11 | Validación | La API rechaza checkpoint y avance imposibles. | Prueba automatizada aprobada |
| P12 | Desconexión | Un fallo de red no cierra el juego. | Pendiente de ejecución local |

Las pruebas del servidor se ejecutaron con cuatro casos automatizados y
no registraron fallos. La demostración en Godot debe completar la columna
de resultado obtenido y adjuntar capturas reales. En la Semana 4
participarán como mínimo tres personas que no formen parte del equipo.

# 22. Responsabilidades iniciales

| **Responsable** | **Mención o apoyo** | **Aporte en la opción B** | **Evidencia prevista** |
|---|---|---|---|
| Brayan Quispe Mamani | Desarrollo de Software | Cliente Godot: movimiento, combate, colisiones, cámara, escenas, NPC, UI, audio, integración y pruebas. | Escenas, scripts, commits y casos P01-P11 |
| Douglas Israel Roman Quispe | Ingeniería de Sistemas | API FastAPI, modelo SQLite, persistencia y contrato HTTP/JSON. | Repositorio del servidor, endpoints y prueba P12 |
| Eduardo Ricardo Condori Mamani | Seguridad de la Información | Revisión y documento técnico independiente. | Informe separado; sus detalles no forman parte de este GDD |
| Mesa de IA | Apoyo transversal | Revisar la máquina de estados de la sombra y la lógica del NPC. | Bitácora o recomendación de asesoría |
| Mesa de Redes | Apoyo transversal | Validar protocolo, reintento y comportamiento ante desconexión. | Contrato revisado y prueba de conexión |
| Equipo Kallami | Trabajo conjunto | Relato, decisiones narrativas, recursos, pruebas externas y presentación. | GDD actualizado, recursos y defensa |

# 23. Aporte específico de Brayan

El aporte de Desarrollo de Software no consiste únicamente en programar
al personaje. Durante la Semana 1, Brayan debe transformar las decisiones
del GDD en especificaciones claras y tareas implementables. La construcción
del prototipo jugable comenzará en la Semana 2, de acuerdo con el cronograma
oficial.

## 23.1 Entregables de Semana 1

1.  Validar el core gameplay loop y expresarlo como acciones, datos y
    > respuestas observables.

2.  Documentar el mapa de controles, la perspectiva, la cámara y la
    > resolución objetivo.

3.  Definir la matriz de colisiones entre jugador, paredes, peligros,
    > enemigos, proyectiles y áreas de interacción.

4.  Diseñar la estructura de escenas, estados y señales del cliente Godot.

5.  Crear el repositorio, la estructura inicial de carpetas y las reglas
    > básicas de ramas y commits.

6.  Finalizar los wireframes del menú, HUD, diálogo, pausa y pantalla final.

7.  Especificar las condiciones de victoria, derrota, checkpoint y reinicio.

8.  Acordar con Douglas el contrato HTTP/JSON y el comportamiento ante una
    > desconexión antes de programar la conexión.

9.  Distribuir las tareas de la Semana 2 y registrar las decisiones en la
    > bitácora del GDD.

## 23.2 Criterios de aceptación

- El GDD v1.0 contiene título, sinopsis, relato, adaptación, Camino del
  Héroe, personajes, mecánicas, tres niveles y bocetos.

- El core gameplay loop relaciona cada acción con una respuesta y una
  condición de avance.

- Los controles, la cámara y las capas de colisión están especificados sin
  exigir todavía una implementación jugable.

- La arquitectura de escenas, estados y señales permite iniciar el Alpha
  sin decisiones técnicas esenciales abiertas.

- Los wireframes y mapas muestran la interfaz y el recorrido de los tres
  niveles.

- El contrato cliente-servidor define operaciones, datos, respuesta y
  comportamiento ante desconexión.

- Cada tarea de la Semana 2 tiene responsable y evidencia prevista.

- No se exige movimiento, combate ni conexión funcionando hasta la fase de
  Prototipo Alpha de la Semana 2.

## 23.3 Transición a la Semana 2

| **Implementación del Alpha** | **Responsable principal** | **Evidencia esperada** |
|---|---|---|
| Player.tscn, movimiento y colisiones | Brayan | Escena de prueba y commits |
| Interacción, ataque y sombra base | Brayan, con revisión de IA | Demostración del core loop |
| Main.tscn y primer escenario funcional | Brayan | Alpha 0.1 ejecutable |
| API, persistencia y primera conexión | Douglas, con revisión de Redes | Endpoints y prueba cliente-servidor |

## 23.4 Resultado preparado para la Semana 2

El paquete Alpha 0.1 contiene el proyecto importable de Godot, scripts
separados por responsabilidad, API FastAPI, esquema SQLite, pruebas
automatizadas del servidor, contrato JSON, manual de instalación y guía
de demostración. Los recursos visuales del juego son provisionales y se
dibujan desde código; por tanto, no se presentan como arte cultural
definitivo. Las capturas, el registro de ejecución y las observaciones de
la primera prueba jugable deberán añadirse después de abrir el proyecto
en la computadora del equipo.

# 24. Riesgos y medidas de control

| **Prioridad** | **Riesgo** | **Medida de control** |
|---|---|---|
| Alta | El combate puede retrasar el núcleo narrativo. | Mantener un ataque, un enemigo y cuatro estados; eliminarlo si impide cerrar el Alpha. |
| Alta | El servidor puede consumir tiempo de producción. | Limitarlo a cuatro operaciones y datos de sesión/progreso. |
| Alta | Una representación visual puede confundirse con el relato original. | Rotular personajes, sombras y pistas como recursos ficticios de adaptación. |
| Media | Los tres niveles pueden resultar extensos. | Limitar cada nivel a una ruta principal y dos desvíos cortos. |
| Media | Una desconexión puede bloquear la partida. | Conservar temporalmente el progreso local y realizar un solo reintento. |
| Media | Recursos de terceros pueden carecer de licencia. | Registrar autor, enlace y licencia antes de integrarlos. |
| Media | El equipo podría ampliar el alcance. | No aceptar funciones nuevas hasta completar el core loop. |

# 25. Registro de cambios

| **Versión** | **Fecha** | **Problema encontrado** | **Cambio aplicado** | **Motivo** |
|---|---|---|---|---|
| 0.1 | 04/09/2026 | Existían datos, roles y decisiones abiertas. | Se creó el borrador grupal inicial. | Delimitar el proyecto de la opción B. |
| 1.0 | 05/09/2026 | Faltaban fichas completas, dificultad explícita y separación entre preproducción y prototipo. | Se cerraron personajes, obstáculos, arte, arquitectura, controles y evidencias de Semana 1. | Entregar el GDD v1.0 sin adelantar la implementación de la Semana 2. |
| 2.0 | 14/09/2026 | La integración obligatoria y el comportamiento real del Alpha no estaban documentados. | Se implementó una sección vertical con cliente Godot, API FastAPI, SQLite, NPC, enemigo, HUD y guardado. | Presentar Alpha, GDD v2.0 y demo coherentes. |

# 26. Conclusiones

La propuesta grupal mantiene la secuencia planteada por los documentos
oficiales y ya cuenta con una primera traducción funcional del GDD. El
Alpha integra movimiento, interacción, pista, obstáculo, enemigo,
interfaz y persistencia dentro de un recorrido corto. Ninguno de estos
componentes se presenta aislado durante la demostración.

El valor del prototipo no depende de la cantidad de funciones. En la
Semana 2 depende de que el jugador comprenda el objetivo, complete el
core loop y pueda recuperar el avance registrado en el servidor. La
siguiente iteración deberá corregir los problemas observados al ejecutar
el Alpha y extender únicamente los sistemas comprobados hacia los
niveles 2 y 3.

Para Brayan, la Semana 2 cierra con un cliente importable, scripts
separados y una demostración completa del núcleo jugable. Para Douglas,
cierra con una API persistente y validaciones comprobadas mediante
pruebas. Las evidencias visuales y observaciones reales deberán añadirse
después de ejecutar el paquete en los equipos del grupo.

# Referencias

Campbell, J. (2008). The hero with a thousand faces (3rd ed.). New World
Library.

Clase 1: Introducción al desarrollo de videojuegos. Proyecto: Videojuego
basado en mitos y relatos andinos. (s. f.). \[Material de cátedra no
publicado\].

Fullerton, T. (2018). Game design workshop: A playcentric approach to
creating innovative games (4th ed.). CRC Press.
https://doi.org/10.1201/b22309

Godot Engine contributors. (s. f.-a). Nodes and scenes. Godot Engine
documentation. Recuperado el 4 de septiembre de 2026, de
https://docs.godotengine.org/en/stable/getting_started/step_by_step/nodes_and_scenes.html

Godot Engine contributors. (s. f.-b). The main game scene. Godot Engine
documentation. Recuperado el 4 de septiembre de 2026, de
https://docs.godotengine.org/en/stable/getting_started/first_2d_game/05.the_main_game_scene.html

Informe general del proyecto: Diseño y desarrollo de videojuegos en
equipo. (s. f.). \[Documento de orientación académica no publicado\].

Quispe, M. (2006, 14 de mayo). *Relato sobre el Cerro Kallami* \[Relato
oral registrado en Pucarani, Cota Cota\].

Schell, J. (2019). The art of game design: A book of lenses (3rd ed.).
CRC Press. https://doi.org/10.1201/b22101

UNESCO. (2003). Convention for the safeguarding of the intangible
cultural heritage. https://ich.unesco.org/en/convention
