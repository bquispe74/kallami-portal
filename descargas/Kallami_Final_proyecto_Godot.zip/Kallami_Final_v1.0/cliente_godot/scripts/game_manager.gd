extends Node

signal server_status_changed(connected: bool, message: String)
signal profiles_loaded(profiles: Array)
signal profile_session_started(profile: Dictionary)
signal profile_operation_failed(message: String)
signal profile_deleted
signal progress_loaded(data: Dictionary)
signal progress_saved(data: Dictionary)
signal new_game_ready

const API_URL := "http://127.0.0.1:8000"

var player_id := ""
var profile_name := ""
var access_token := ""
var last_progress: Dictionary = {
	"level": 1,
	"clues": 0,
	"clue_ids": [],
	"checkpoint_id": "inicio",
	"completed": false,
	"health": 5,
	"position_x": 220.0,
	"position_y": 1260.0,
	"mission_state": 0,
	"puzzle_step": 0
}

var _profile_http: HTTPRequest
var _load_http: HTTPRequest
var _save_http: HTTPRequest
var _reset_http: HTTPRequest
var _profile_operation := ""
var _profile_busy := false
var _load_busy := false
var _save_busy := false
var _save_pending := false


func _ready() -> void:
	_profile_http = _http_node("ProfileRequest", _on_profile_request_completed)
	_load_http = _http_node("LoadRequest", _on_load_completed)
	_save_http = _http_node("SaveRequest", _on_save_completed)
	_reset_http = _http_node("ResetRequest", _on_reset_completed)


func has_active_session() -> bool:
	return not player_id.is_empty() and not access_token.is_empty()


func close_session() -> void:
	while _load_busy:
		await _load_http.request_completed
	while _save_busy:
		await _save_http.request_completed
	_save_pending = false
	player_id = ""
	profile_name = ""
	access_token = ""
	last_progress = _default_progress()


func list_profiles() -> void:
	if _profile_busy:
		return
	_profile_busy = true
	_profile_operation = "list"
	var error := _profile_http.request("%s/api/perfiles" % API_URL)
	if error != OK:
		_profile_busy = false
		profile_operation_failed.emit("No se pudo conectar con el servidor de perfiles.")


func create_profile(display_name: String, pin: String) -> void:
	_profile_operation = "create"
	_request_profile("%s/api/perfiles" % API_URL, {"display_name": display_name, "pin": pin})


func login_profile(profile_id: String, pin: String) -> void:
	_profile_operation = "login"
	_request_profile("%s/api/perfiles/login" % API_URL, {"profile_id": profile_id, "pin": pin})


func delete_profile(profile_id: String, pin: String) -> void:
	_profile_operation = "delete"
	_request_profile("%s/api/perfiles/%s/eliminar" % [API_URL, profile_id], {"pin": pin})


func load_progress() -> void:
	if _load_busy or not has_active_session():
		return
	_load_busy = true
	var error := _load_http.request("%s/api/progreso/%s" % [API_URL, player_id], _auth_headers(false))
	if error != OK:
		_load_busy = false
		server_status_changed.emit(false, "No se pudo iniciar la conexión")
		progress_loaded.emit(last_progress.duplicate(true))


func save_progress(data: Dictionary) -> void:
	if not has_active_session():
		return
	last_progress.merge(data, true)
	if _save_busy:
		_save_pending = true
		return
	_save_busy = true
	var payload := {
		"player_id": player_id,
		"level": int(last_progress.get("level", 1)),
		"clues": int(last_progress.get("clues", 0)),
		"clue_ids": last_progress.get("clue_ids", []),
		"checkpoint_id": str(last_progress.get("checkpoint_id", "inicio")),
		"completed": bool(last_progress.get("completed", false)),
		"health": int(last_progress.get("health", 5)),
		"position_x": float(last_progress.get("position_x", 220.0)),
		"position_y": float(last_progress.get("position_y", 1260.0)),
		"mission_state": int(last_progress.get("mission_state", 0)),
		"puzzle_step": int(last_progress.get("puzzle_step", 0))
	}
	var error := _save_http.request(
		"%s/api/progreso" % API_URL,
		_auth_headers(true),
		HTTPClient.METHOD_POST,
		JSON.stringify(payload)
	)
	if error != OK:
		_save_busy = false
		server_status_changed.emit(false, "Progreso pendiente: servidor no disponible")


func reset_current_progress() -> void:
	if not has_active_session():
		return
	var error := _reset_http.request(
		"%s/api/progreso/%s/reiniciar" % [API_URL, player_id],
		_auth_headers(false),
		HTTPClient.METHOD_POST
	)
	if error != OK:
		profile_operation_failed.emit("No se pudo reiniciar la partida.")


func _request_profile(url: String, payload: Dictionary) -> void:
	if _profile_busy:
		profile_operation_failed.emit("Espera a que termine la operación anterior.")
		return
	_profile_busy = true
	var headers := PackedStringArray(["Content-Type: application/json"])
	var error := _profile_http.request(url, headers, HTTPClient.METHOD_POST, JSON.stringify(payload))
	if error != OK:
		_profile_busy = false
		profile_operation_failed.emit("No se pudo enviar la solicitud al servidor.")


func _on_profile_request_completed(
	result: int,
	response_code: int,
	_headers: PackedStringArray,
	body: PackedByteArray
) -> void:
	_profile_busy = false
	if result != HTTPRequest.RESULT_SUCCESS:
		server_status_changed.emit(false, "Servidor de perfiles desconectado")
		profile_operation_failed.emit("Inicia el servidor FastAPI y vuelve a intentar.")
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if response_code in [200, 201]:
		server_status_changed.emit(true, "Servidor conectado • perfiles protegidos")
		match _profile_operation:
			"list":
				if typeof(parsed) == TYPE_ARRAY:
					profiles_loaded.emit(parsed)
				else:
					profiles_loaded.emit([])
			"create", "login":
				if typeof(parsed) == TYPE_DICTIONARY:
					_start_session(parsed)
			"delete":
				profile_deleted.emit()
				call_deferred("list_profiles")
		return
	profile_operation_failed.emit(_error_detail(parsed, "El servidor rechazó la operación de perfil."))


func _start_session(response: Dictionary) -> void:
	var profile: Dictionary = response.get("profile", {})
	player_id = str(profile.get("profile_id", ""))
	profile_name = str(profile.get("display_name", "Perfil"))
	access_token = str(response.get("access_token", ""))
	last_progress = _default_progress()
	if not has_active_session():
		profile_operation_failed.emit("La sesión recibida no es válida.")
		return
	profile_session_started.emit(profile)


func _on_load_completed(
	result: int,
	response_code: int,
	_headers: PackedStringArray,
	body: PackedByteArray
) -> void:
	_load_busy = false
	if result != HTTPRequest.RESULT_SUCCESS:
		server_status_changed.emit(false, "Servidor desconectado")
		progress_loaded.emit(last_progress.duplicate(true))
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if response_code == 200 and typeof(parsed) == TYPE_DICTIONARY:
		last_progress.merge(parsed, true)
		server_status_changed.emit(true, "Progreso restaurado y sesión verificada")
		progress_loaded.emit(last_progress.duplicate(true))
		return
	server_status_changed.emit(false, _error_detail(parsed, "No se pudo cargar el progreso"))
	progress_loaded.emit(last_progress.duplicate(true))


func _on_save_completed(
	result: int,
	response_code: int,
	_headers: PackedStringArray,
	body: PackedByteArray
) -> void:
	_save_busy = false
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if result == HTTPRequest.RESULT_SUCCESS and response_code in [200, 201] and typeof(parsed) == TYPE_DICTIONARY:
		last_progress.merge(parsed, true)
		server_status_changed.emit(true, "Progreso guardado • perfil %s" % profile_name)
		progress_saved.emit(last_progress.duplicate(true))
	else:
		server_status_changed.emit(false, _error_detail(parsed, "No se pudo guardar el progreso"))
	if _save_pending:
		_save_pending = false
		save_progress(last_progress)


func _on_reset_completed(
	result: int,
	response_code: int,
	_headers: PackedStringArray,
	body: PackedByteArray
) -> void:
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if result == HTTPRequest.RESULT_SUCCESS and response_code == 200 and typeof(parsed) == TYPE_DICTIONARY:
		last_progress = _default_progress()
		last_progress.merge(parsed, true)
		server_status_changed.emit(true, "Partida del perfil reiniciada")
		new_game_ready.emit()
	else:
		profile_operation_failed.emit(_error_detail(parsed, "No se pudo reiniciar la partida."))


func _auth_headers(include_json: bool) -> PackedStringArray:
	var headers := PackedStringArray(["Authorization: Bearer %s" % access_token])
	if include_json:
		headers.append("Content-Type: application/json")
	return headers


func _http_node(node_name: String, callback: Callable) -> HTTPRequest:
	var request := HTTPRequest.new()
	request.name = node_name
	add_child(request)
	request.request_completed.connect(callback)
	return request


func _error_detail(parsed, fallback: String) -> String:
	if typeof(parsed) == TYPE_DICTIONARY:
		var detail = parsed.get("detail", fallback)
		if typeof(detail) == TYPE_STRING:
			return detail
	return fallback


static func _default_progress() -> Dictionary:
	return {
		"level": 1,
		"clues": 0,
		"clue_ids": [],
		"checkpoint_id": "inicio",
		"completed": false,
		"health": 5,
		"position_x": 220.0,
		"position_y": 1260.0,
		"mission_state": 0,
		"puzzle_step": 0
	}
