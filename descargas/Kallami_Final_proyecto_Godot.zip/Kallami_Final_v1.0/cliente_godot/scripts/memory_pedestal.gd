extends Area2D

signal selected(order_index: int)

@export var order_index := 0
@export var display_name := "Memoria"

var active := false
var completed := false
var _pulse := 0.0


func _ready() -> void:
	name = "PedestalMemoria%d" % order_index
	z_index = 12
	collision_layer = 2
	collision_mask = 0
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 38.0
	collision.shape = shape
	add_child(collision)
	queue_redraw()


func _process(delta: float) -> void:
	_pulse += delta * 2.8
	queue_redraw()


func interact(_player: Node) -> void:
	if active and not completed:
		selected.emit(order_index)


func is_available() -> bool:
	return active and not completed


func set_active(value: bool) -> void:
	active = value
	queue_redraw()


func mark_completed() -> void:
	active = false
	completed = true
	queue_redraw()


func reset_memory() -> void:
	active = true
	completed = false
	queue_redraw()


func _draw() -> void:
	var base_color := Color("343944")
	var symbol_color := Color("68717c")
	if active:
		symbol_color = Color("e4c86e")
	if completed:
		base_color = Color("46634f")
		symbol_color = Color("91dfa1")
	draw_circle(Vector2(0, 16), 47, Color(0.01, 0.02, 0.04, 0.48))
	draw_rect(Rect2(-40, 14, 80, 26), base_color)
	draw_rect(Rect2(-31, -10, 62, 25), base_color.lightened(0.12))
	draw_rect(Rect2(-22, -35, 44, 26), base_color.lightened(0.22))
	if order_index == 0:
		draw_colored_polygon(PackedVector2Array([Vector2(-15, -43), Vector2(0, -57), Vector2(15, -43)]), symbol_color)
		draw_rect(Rect2(-12, -43, 24, 17), symbol_color)
		draw_rect(Rect2(-3, -34, 6, 8), base_color)
	elif order_index == 1:
		draw_line(Vector2(-14, -54), Vector2(14, -29), symbol_color, 7)
		draw_line(Vector2(12, -57), Vector2(-13, -31), symbol_color, 7)
		draw_circle(Vector2(-15, -55), 5, symbol_color)
		draw_circle(Vector2(15, -55), 5, symbol_color)
	else:
		draw_colored_polygon(PackedVector2Array([Vector2(-19, -28), Vector2(-4, -54), Vector2(5, -43), Vector2(13, -60), Vector2(23, -28)]), symbol_color)
	if active:
		draw_arc(Vector2(0, -37), 35 + sin(_pulse) * 4.0, 0, TAU, 28, Color(symbol_color.r, symbol_color.g, symbol_color.b, 0.48), 3)
