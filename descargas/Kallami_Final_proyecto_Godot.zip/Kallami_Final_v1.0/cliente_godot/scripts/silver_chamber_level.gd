extends Node2D

signal exit_reached

const WORLD_SIZE := Vector2(2400, 1500)
const EXIT_POSITION := Vector2(1200, 205)

var exit_active := false
var _seal_collision: CollisionShape2D


func _ready() -> void:
	name = "CamaraDePlata"
	z_index = -20
	_build_chamber_collision()
	_build_exit()
	queue_redraw()


func set_exit_active(value: bool) -> void:
	exit_active = value
	if is_instance_valid(_seal_collision):
		_seal_collision.set_deferred("disabled", value)
	queue_redraw()


func _build_chamber_collision() -> void:
	_add_wall(Rect2(0, 0, 2400, 40))
	_add_wall(Rect2(0, 1460, 2400, 40))
	_add_wall(Rect2(0, 0, 40, 1500))
	_add_wall(Rect2(2360, 0, 40, 1500))
	_add_wall(Rect2(300, 280, 260, 250))
	_add_wall(Rect2(1840, 280, 260, 250))
	_add_wall(Rect2(270, 960, 250, 260))
	_add_wall(Rect2(1880, 960, 250, 260))
	_add_wall(Rect2(700, 260, 250, 150))
	_add_wall(Rect2(1450, 260, 250, 150))
	var seal_body := StaticBody2D.new()
	seal_body.name = "SelloDePlata"
	seal_body.collision_layer = 1
	seal_body.position = Vector2(1200, 390)
	_seal_collision = CollisionShape2D.new()
	var seal_shape := RectangleShape2D.new()
	seal_shape.size = Vector2(420, 42)
	_seal_collision.shape = seal_shape
	seal_body.add_child(_seal_collision)
	add_child(seal_body)


func _add_wall(rect: Rect2) -> void:
	var wall := StaticBody2D.new()
	wall.collision_layer = 1
	wall.collision_mask = 0
	wall.position = rect.get_center()
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	wall.add_child(collision)
	add_child(wall)


func _build_exit() -> void:
	var area := Area2D.new()
	area.name = "AltarFinal"
	area.position = EXIT_POSITION
	area.collision_layer = 8
	area.collision_mask = 1
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 60.0
	collision.shape = shape
	area.add_child(collision)
	add_child(area)
	area.body_entered.connect(func(body: Node2D) -> void:
		if exit_active and body.name == "Juan":
			exit_reached.emit()
	)


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("090c14"))
	draw_rect(Rect2(40, 40, 2320, 1420), Color("252b38"))
	_draw_floor()
	_draw_walls_and_columns()
	_draw_silver_veins()
	_draw_seal()
	_draw_altar()


func _draw_floor() -> void:
	for tile_y in range(55, 1450, 72):
		for tile_x in range(55, 2350, 72):
			var alternate: int = int(tile_x / 72 + tile_y / 72)
			var tone := Color("353c4a") if alternate % 2 == 0 else Color("303744")
			draw_rect(Rect2(tile_x, tile_y, 68, 68), tone)
			draw_rect(Rect2(tile_x, tile_y, 68, 68), Color(0.55, 0.62, 0.72, 0.10), false, 2)


func _draw_walls_and_columns() -> void:
	var blocks: Array[Rect2] = [
		Rect2(300, 280, 260, 250), Rect2(1840, 280, 260, 250),
		Rect2(270, 960, 250, 260), Rect2(1880, 960, 250, 260),
		Rect2(700, 260, 250, 150), Rect2(1450, 260, 250, 150)
	]
	for block in blocks:
		draw_rect(Rect2(block.position + Vector2(14, 18), block.size), Color(0.0, 0.0, 0.0, 0.35))
		draw_rect(block, Color("171d28"))
		draw_rect(block.grow(-10), Color("414958"), false, 8)
		for row_y in range(int(block.position.y + 24), int(block.end.y - 5), 42):
			draw_line(Vector2(block.position.x + 12, row_y), Vector2(block.end.x - 12, row_y), Color("262d38"), 4)
	var columns: Array[Vector2] = [
		Vector2(650, 610), Vector2(1750, 610), Vector2(650, 1130), Vector2(1750, 1130)
	]
	for center in columns:
		draw_circle(center + Vector2(10, 15), 58, Color(0.0, 0.0, 0.0, 0.30))
		draw_circle(center, 52, Color("202735"))
		draw_circle(center, 38, Color("566070"))
		draw_circle(center, 26, Color("2b3340"))


func _draw_silver_veins() -> void:
	var veins: Array[PackedVector2Array] = [
		PackedVector2Array([Vector2(60, 760), Vector2(300, 700), Vector2(520, 760), Vector2(710, 715)]),
		PackedVector2Array([Vector2(1690, 720), Vector2(1900, 660), Vector2(2130, 735), Vector2(2340, 675)]),
		PackedVector2Array([Vector2(810, 1310), Vector2(1070, 1240), Vector2(1340, 1300), Vector2(1590, 1240)])
	]
	for vein in veins:
		draw_polyline(vein, Color(0.75, 0.86, 0.95, 0.22), 14, true)
		draw_polyline(vein, Color("c5dae7"), 4, true)


func _draw_seal() -> void:
	if exit_active:
		for rock in [Vector2(1004, 402), Vector2(1043, 410), Vector2(1378, 405), Vector2(1400, 414)]:
			draw_colored_polygon(PackedVector2Array([
				rock + Vector2(-18, 7), rock + Vector2(-10, -8),
				rock + Vector2(7, -13), rock + Vector2(19, 5), rock + Vector2(8, 13)
			]), Color("68727f"))
		draw_line(Vector2(1064, 418), Vector2(1112, 406), Color("91a2b4", 0.48), 3)
		draw_line(Vector2(1303, 409), Vector2(1342, 420), Color("91a2b4", 0.42), 3)
		return
	draw_rect(Rect2(990, 370, 420, 40), Color(0.30, 0.68, 0.84, 0.24))
	for seal_x in range(1010, 1400, 34):
		draw_line(Vector2(seal_x, 370), Vector2(seal_x + 20, 410), Color("8ad5ec"), 3)


func _draw_altar() -> void:
	draw_circle(EXIT_POSITION + Vector2(0, 25), 98, Color(0.02, 0.03, 0.06, 0.62))
	draw_rect(Rect2(EXIT_POSITION + Vector2(-74, 25), Vector2(148, 36)), Color("555d69"))
	draw_rect(Rect2(EXIT_POSITION + Vector2(-56, -12), Vector2(112, 38)), Color("747e8b"))
	draw_rect(Rect2(EXIT_POSITION + Vector2(-34, -50), Vector2(68, 40)), Color("9da9b5"))
	var glow := Color("f4d878") if exit_active else Color("65717d")
	draw_circle(EXIT_POSITION + Vector2(0, -58), 19, glow)
	draw_arc(EXIT_POSITION + Vector2(0, -58), 35, 0, TAU, 32, Color(glow.r, glow.g, glow.b, 0.42), 5)
	if exit_active:
		for ray_index in range(12):
			var angle := TAU * float(ray_index) / 12.0
			draw_line(EXIT_POSITION + Vector2(0, -58) + Vector2.from_angle(angle) * 36, EXIT_POSITION + Vector2(0, -58) + Vector2.from_angle(angle) * 64, glow, 3)
