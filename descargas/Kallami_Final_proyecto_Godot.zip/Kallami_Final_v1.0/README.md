# Kallami: Senderos de Plata — versión final 1.5

Videojuego de aventura narrativa 2D ambientado en un pueblo cercano al Cerro Kallami. Esta versión contiene tres niveles completos —comunidad, ascenso y cámara de plata—, honda cargable, esquiva, tres clases de sombra, tres memorias, rompecabezas final, niebla de exploración, minimapa progresivo, música reactiva, diálogos con voz natural, perfiles independientes y persistencia cliente-servidor.

## Integrantes

- **Brayan Quispe Mamani:** cliente, jugabilidad e integración en Godot.
- **Douglas Israel Roman Quispe:** servidor FastAPI, SQLite y contrato HTTP/JSON.
- **Eduardo Ricardo Condori Mamani:** pruebas y revisión de Seguridad de la Información.

## Contenido

- `cliente_godot/`: proyecto compatible con Godot 4.7.2.
- `servidor/`: API FastAPI 1.0 y base SQLite local.
- `docs/`: recorrido, arquitectura, guion de tráiler, defensa y contrato de API.
- `tools/`: generador reproducible de los efectos y pistas de audio originales.

## Inicio rápido en Linux

Instala Python, soporte para entornos virtuales y herramientas básicas:

```bash
sudo apt update
sudo apt install -y python3 python3-venv unzip
```

En una terminal inicia el servidor:

```bash
cd ~/Workspace/inf_266/Kallami_Final_v1.0/servidor
chmod +x iniciar_servidor.sh probar_servidor.sh
./iniciar_servidor.sh
```

Déjala abierta. Debe mostrar `Uvicorn running on http://127.0.0.1:8000`.

En otra terminal abre Godot desde la raíz del proyecto:

```bash
cd ~/Workspace/inf_266/Kallami_Final_v1.0
chmod +x iniciar_godot_linux.sh
./iniciar_godot_linux.sh
```

El script detecta `godot`, `godot4` o el ejecutable `Godot_v4.7.2-stable_linux.x86_64` dentro de `~/Descargas` o `~/Downloads`.

## Inicio rápido en Windows 10/11

1. Instala **Python 3.11 o superior** desde python.org y activa `Add Python to PATH`.
2. Descarga Godot 4.7.2 para Windows y descomprime el ejecutable.
3. Abre PowerShell dentro de `servidor` y ejecuta:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\iniciar_servidor_windows.bat
```

4. Mantén esa ventana abierta. En otra terminal, desde la raíz, ejecuta:

```powershell
.\iniciar_godot_windows.bat
```

Si Godot está en otra carpeta, también puedes abrirlo manualmente, elegir **Importar** y seleccionar `cliente_godot/project.godot`.

## Primera partida

1. Con el servidor activo, abre el juego con `F6` o `F5`.
2. Escribe un nombre y un PIN de cuatro números, luego pulsa **Crear**.
3. En el **Nivel 1**, habla con Florencio mediante `E` y cruza el pueblo hasta el portal del cerro.
4. En el **Nivel 2**, explora el ascenso. Cerca de la entrada de la cueva la luz se enfría y el sendero se vuelve más oscuro. El minimapa solo revela los sectores recorridos.
5. Mantén `F` para cargar la honda y suéltala para disparar. Un tiro cargado viaja más lejos y causa doble daño.
6. Esquiva con `Espacio` cuando una sombra marque su ataque. La barra inferior indica cuándo está disponible.
7. Recupera las tres memorias y cruza el portal superior.
8. En el **Nivel 3**, dispersa a los dos guardianes y activa los pedestales en este orden: comunidad, mineros y cerro.
9. Cuando la cámara tiemble, esquiva las rocas que caen. El derrumbe abrirá el sello; luego corre al altar de plata para terminar la aventura.

## Controles

| Acción | Tecla |
|---|---|
| Movimiento | `WASD` o flechas |
| Interacción / diálogo | `E` |
| Avanzar texto | `E`, `Espacio` o `Enter` |
| Cargar y lanzar piedra con la honda | Mantener y soltar `F` |
| Esquiva breve | `Espacio` |
| Guardado manual | `G` |
| Pausa real | `Esc` |
| Alternar ventana / pantalla completa | `F11` o los botones visibles del menú y la pausa |
| Cambiar de perfil durante la partida | `Esc` → **CAMBIAR PERFIL** |
| Reiniciar perfil tras completar | `N` |

## Verificar servidor y pruebas

Estado de la API:

```text
http://127.0.0.1:8000/api/estado
```

Documentación interactiva:

```text
http://127.0.0.1:8000/docs
```

Suite automatizada:

```bash
cd servidor
./probar_servidor.sh
```

El resultado esperado es `12 passed`.

## Cómo demostrar el guardado

Presiona `G` y espera el texto verde del HUD. La terminal del servidor mostrará un `POST /api/progreso ... 200 OK`. Detén el juego, ejecútalo otra vez, selecciona el mismo perfil e ingresa su PIN. La terminal mostrará `GET /api/progreso/<perfil> ... 200 OK`; Juan reaparecerá con el nivel, posición, vida, misión, memorias, checkpoint y paso del rompecabezas guardados.

## Voces y música

Florencio tiene ocho clips de voz sincronizados con el movimiento de boca, incluidas sus líneas de cierre. La versión final usa la voz neuronal boliviana masculina `es-BO-MarceloNeural`, ligeramente más lenta y grave para representar a un anciano. Los WAV ya incluidos funcionan sin internet durante el juego. `tools/generar_voces_naturales.sh` permite regenerarlos mediante una conexión temporal al servicio de voz de Microsoft Edge; `tools/generar_voces.sh` conserva la voz robótica como respaldo totalmente local. `tools/generar_audio.py` reconstruye los ambientes del pueblo, ascenso y cámara, además de los efectos.

El plan priorizado para convertir el prototipo en una experiencia más entretenida está en `docs/PLAN_MEJORAS_JUGABILIDAD_Y_ARTE.md`.

## Combate y desenlace de la versión 1.5

- La **sombra cazadora** persigue a Juan y busca golpearlo de cerca.
- El **eco tirador** mantiene distancia, muestra un círculo rojo de preparación y dispara un proyectil violeta.
- Los **guardianes** tienen seis puntos de vida y lanzan ráfagas de tres ecos.
- Los enemigos muestran barra de vida durante el combate.
- Los impactos producen destello, partículas dibujadas, sacudida de cámara y sonidos diferenciados.
- La esquiva concede una ventana breve de invulnerabilidad, pero tiene enfriamiento.
- Al completar el rompecabezas, comienza un derrumbe de tres oleadas; las rocas muestran una zona roja antes de caer.
- La secuencia final mezcla una música propia de suspenso y persecución con el ambiente atenuado; la música se pausa con el juego.
- El paso queda libre al terminar el temblor. Hay que llegar al altar para cerrar la historia.

## Perfiles y pantalla

El menú de pausa incluye **Cambiar perfil**. El juego guarda el avance del perfil actual antes de volver a la selección; cada perfil conserva su propia partida. La misma opción aparece en la pantalla de aventura completada.

`F11` alterna entre ventana y pantalla completa. También se puede pulsar el botón visible en la pantalla de perfiles o en el menú de pausa; el texto cambia a **Volver a ventana** cuando la pantalla completa está activa.

## Alcance de seguridad

El PIN se deriva con **PBKDF2-HMAC-SHA256**, sal aleatoria y 210 000 iteraciones. El servidor guarda el hash, no el PIN. Cada inicio de sesión entrega un token aleatorio; las rutas de progreso verifican que ese token pertenezca al perfil solicitado. Es una protección adecuada para una demostración local académica, no sustituye HTTPS, gestión de cuentas remotas ni recuperación de credenciales de un servicio en producción.

## Tráiler y defensa

- `docs/GUIA_TRAILER_60_SEGUNDOS.md`: plano a plano conforme a la consigna.
- `docs/DEFENSA_FINAL.md`: orden de exposición, evidencia técnica y respuestas breves.
- `docs/RECORRIDO_DEMO_FINAL.md`: ruta para mostrar todas las mecánicas sin perder tiempo.
