#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/cliente_godot/assets/audio/dialogue"
mkdir -p "$OUT_DIR"

FILTER="highpass=f=85,lowpass=f=4300,atempo=0.94,aecho=0.8:0.35:28:0.10,loudnorm=I=-18:TP=-3:LRA=9"

ffmpeg -y -hide_banner -loglevel error -f lavfi -i "flite=text='Juan, el cerro esta inquieto. Las sombras despertaron y el camino ya no es seguro.':voice=rms" -af "$FILTER" -ar 44100 -ac 1 -c:a pcm_s16le "$OUT_DIR/florencio_intro_01.wav"
ffmpeg -y -hide_banner -loglevel error -f lavfi -i "flite=text='Cruza el pueblo y entra por el portal de la cumbre. Alli comienza el verdadero ascenso.':voice=rms" -af "$FILTER" -ar 44100 -ac 1 -c:a pcm_s16le "$OUT_DIR/florencio_intro_02.wav"
ffmpeg -y -hide_banner -loglevel error -f lavfi -i "flite=text='En el cerro recupera los tres recuerdos. Tu honda puede dispersar las sombras.':voice=rms" -af "$FILTER" -ar 44100 -ac 1 -c:a pcm_s16le "$OUT_DIR/florencio_intro_03.wav"
ffmpeg -y -hide_banner -loglevel error -f lavfi -i "flite=text='No sigas solamente el brillo de la plata. Escucha lo que protege este pueblo.':voice=rms" -af "$FILTER" -ar 44100 -ac 1 -c:a pcm_s16le "$OUT_DIR/florencio_intro_04.wav"
ffmpeg -y -hide_banner -loglevel error -f lavfi -i "flite=text='El sendero esta abierto. Ve con cuidado, Juan, y no olvides volver.':voice=rms" -af "$FILTER" -ar 44100 -ac 1 -c:a pcm_s16le "$OUT_DIR/florencio_repeat.wav"

printf 'Voces generadas en %s\n' "$OUT_DIR"
