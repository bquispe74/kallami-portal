extends CharacterBody2D

signal health_changed(current: int, maximum: int)
signal died
signal attack_requested(origin: Vector2, direction: Vector2, power: float)
signal dodge_started
signal hurt

const WORLD_SIZE := Vector2(2400, 1500)
const DODGE_DURATION := 0.20
const DODGE_COOLDOWN := 1.05
const DODGE_SPEED := 560.0
const CHARGE_DURATION := 0.95

@export var speed := 210.0
@export var max_health := 5

var input_enabled := true
var facing := Vector2.DOWN
var health := 5
var _attack_cooldown := 0.0
var _attack_flash := 0.0
var _invulnerability := 0.0
var _walk_phase := 0.0
var _damage_flash := 0.0
var _charging := false
var _charge_time := 0.0
var _attack_strength := 0.0
var _dodge_time := 0.0
var _dodge_cooldown := 0.0
var _dodge_direction := Vector2.DOWN
var _camera: Camera2D
var _shake_time := 0.0
var _shake_strength := 0.0


func _ready() -> void:
	name = "Juan"
	z_index = 20
	health = max_health
	_build_collision()
	_build_camera()
	health_changed.emit(health, max_health)
	queue_redraw()


func _physics_process(delta: float) -> void:
	_attack_cooldown = maxf(0.0, _attack_cooldown - delta)
	_attack_flash = maxf(0.0, _attack_flash - delta)
	_invulnerability = maxf(0.0, _invulnerability - delta)
	_damage_flash = maxf(0.0, _damage_flash - delta)
	_dodge_time = maxf(0.0, _dodge_time - delta)
	_dodge_cooldown = maxf(0.0, _dodge_cooldown - delta)
	_update_camera_shake(delta)
	if input_enabled:
		if _dodge_time > 0.0:
			velocity = _dodge_direction * DODGE_SPEED
		else:
			var direction := Input.get_vector("mover_izquierda", "mover_derecha", "mover_arriba", "mover_abajo")
			velocity = direction * speed
			if direction.length_squared() > 0.01:
				facing = direction.normalized()
				_walk_phase += delta * 11.0
			if Input.is_action_just_pressed("esquivar") and _dodge_cooldown <= 0.0:
				_start_dodge(direction)
			else:
				_update_attack_input(delta)
	else:
		velocity = Vector2.ZERO
	move_and_slide()
	queue_redraw()


func set_input_enabled(value: bool) -> void:
	input_enabled = value
	if not value:
		velocity = Vector2.ZERO
		_charging = false
		_charge_time = 0.0
		_dodge_time = 0.0


func receive_damage(amount: int) -> bool:
	if _invulnerability > 0.0 or health <= 0:
		return false
	health = maxi(0, health - amount)
	_invulnerability = 0.9
	_damage_flash = 0.20
	add_camera_shake(8.0, 0.22)
	health_changed.emit(health, max_health)
	hurt.emit()
	if health <= 0:
		died.emit()
	return true


func respawn(at_position: Vector2) -> void:
	global_position = at_position
	health = max_health
	_invulnerability = 1.2
	health_changed.emit(health, max_health)


func restore_health(saved_health: int) -> void:
	health = clampi(saved_health, 1, max_health)
	health_changed.emit(health, max_health)


func get_dodge_ready_ratio() -> float:
	return clampf(1.0 - _dodge_cooldown / DODGE_COOLDOWN, 0.0, 1.0)


func get_charge_ratio() -> float:
	if not _charging:
		return 0.0
	return clampf(_charge_time / CHARGE_DURATION, 0.0, 1.0)


func is_charging() -> bool:
	return _charging


func add_camera_shake(strength: float, duration: float) -> void:
	_shake_strength = maxf(_shake_strength, strength)
	_shake_time = maxf(_shake_time, duration)


func _update_attack_input(delta: float) -> void:
	if _attack_cooldown > 0.0:
		_charging = false
		_charge_time = 0.0
		return
	if Input.is_action_just_pressed("atacar"):
		_charging = true
		_charge_time = 0.0
	if not _charging:
		return
	if Input.is_action_pressed("atacar"):
		_charge_time = minf(CHARGE_DURATION, _charge_time + delta)
	if Input.is_action_just_released("atacar"):
		_release_attack()
	elif not Input.is_action_pressed("atacar"):
		_charging = false
		_charge_time = 0.0


func _release_attack() -> void:
	var power := clampf(_charge_time / CHARGE_DURATION, 0.0, 1.0)
	_charging = false
	_charge_time = 0.0
	_attack_cooldown = lerpf(0.45, 0.62, power)
	_attack_flash = 0.24
	_attack_strength = power
	attack_requested.emit(global_position + facing * 24.0, facing, power)


func _start_dodge(input_direction: Vector2) -> void:
	_charging = false
	_charge_time = 0.0
	_dodge_direction = input_direction.normalized() if input_direction.length_squared() > 0.01 else facing
	_dodge_time = DODGE_DURATION
	_dodge_cooldown = DODGE_COOLDOWN
	_invulnerability = maxf(_invulnerability, DODGE_DURATION + 0.10)
	velocity = _dodge_direction * DODGE_SPEED
	add_camera_shake(2.0, 0.10)
	dodge_started.emit()


func _build_collision() -> void:
	var collision := CollisionShape2D.new()
	collision.name = "BodyCollision"
	var shape := RectangleShape2D.new()
	shape.size = Vector2(27, 38)
	collision.shape = shape
	add_child(collision)
	collision_layer = 1
	collision_mask = 1 | 4
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING


func _build_camera() -> void:
	_camera = Camera2D.new()
	_camera.name = "Camera2D"
	_camera.enabled = true
	_camera.zoom = Vector2(1.28, 1.28)
	_camera.position_smoothing_enabled = true
	_camera.position_smoothing_speed = 7.0
	_camera.limit_left = 0
	_camera.limit_top = 0
	_camera.limit_right = int(WORLD_SIZE.x)
	_camera.limit_bottom = int(WORLD_SIZE.y)
	add_child(_camera)


func _update_camera_shake(delta: float) -> void:
	if not is_instance_valid(_camera):
		return
	_shake_time = maxf(0.0, _shake_time - delta)
	if _shake_time > 0.0:
		_camera.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake_strength
		_shake_strength = lerpf(_shake_strength, 0.0, minf(1.0, delta * 9.0))
	else:
		_camera.offset = _camera.offset.lerp(Vector2.ZERO, minf(1.0, delta * 16.0))


func _draw() -> void:
	var bob := sin(_walk_phase) * 1.8 if velocity.length_squared() > 1.0 else 0.0
	if absf(facing.x) > absf(facing.y):
		_draw_side(bob, 1.0 if facing.x >= 0.0 else -1.0)
	elif facing.y < 0.0:
		_draw_back(bob)
	else:
		_draw_front(bob)
	_draw_health_bar()
	if _invulnerability > 0.0:
		draw_arc(Vector2.ZERO, 29, 0, TAU, 24, Color(1, 1, 1, 0.58), 2.5)
	if _damage_flash > 0.0:
		draw_circle(Vector2(0, -2), 27, Color(0.95, 0.16, 0.12, 0.22))
	if _dodge_time > 0.0:
		var dodge_progress := 1.0 - _dodge_time / DODGE_DURATION
		for trail_index in range(3):
			var trail_offset := -_dodge_direction * (18.0 + float(trail_index) * 15.0)
			var trail_alpha := 0.34 - float(trail_index) * 0.08
			draw_arc(trail_offset, 23.0 + dodge_progress * 5.0, 0, TAU, 18, Color(0.55, 0.87, 1.0, trail_alpha), 2.5)
	if _charging:
		var charge_ratio := get_charge_ratio()
		var charge_color := Color("f2d26f").lerp(Color("ffffff"), charge_ratio)
		draw_arc(Vector2.ZERO, 32.0 + charge_ratio * 5.0, -PI / 2.0, -PI / 2.0 + TAU * charge_ratio, 28, charge_color, 3.5)
		draw_circle(facing * (27.0 + charge_ratio * 5.0), 3.0 + charge_ratio * 3.0, Color(1.0, 0.82, 0.34, 0.55 + charge_ratio * 0.35))
	if _attack_flash > 0.0:
		var progress := 1.0 - (_attack_flash / 0.24)
		var center := facing * 17.0
		var base_angle := facing.angle()
		var flash_color := Color("f3cf6b").lerp(Color("ffffff"), _attack_strength)
		draw_arc(center, 23.0 + progress * (9.0 + _attack_strength * 8.0), base_angle - 1.05, base_angle + 1.05, 18, flash_color, 4.0 + _attack_strength * 2.0)
		draw_arc(center, 31.0 + progress * (13.0 + _attack_strength * 10.0), base_angle - 0.72, base_angle + 0.72, 14, Color(flash_color.r, flash_color.g, flash_color.b, 0.55), 2.0)


func _draw_health_bar() -> void:
	var ratio := float(health) / float(max_health)
	var bar_color := Color("66c56f")
	if ratio <= 0.35:
		bar_color = Color("e44b3f")
	elif ratio <= 0.65:
		bar_color = Color("e7ad45")
	var width := 58.0
	draw_rect(Rect2(-width / 2.0 - 2.0, -49.0, width + 4.0, 10.0), Color(0.02, 0.03, 0.04, 0.90))
	draw_rect(Rect2(-width / 2.0, -47.0, width, 6.0), Color("382c2b"))
	draw_rect(Rect2(-width / 2.0, -47.0, width * ratio, 6.0), bar_color)
	draw_line(Vector2(-width / 2.0, -40.0), Vector2(width / 2.0, -40.0), Color(1, 1, 1, 0.22), 1.0)


func _draw_front(bob: float) -> void:
	_draw_shadow_and_legs(bob)
	var poncho := PackedVector2Array([Vector2(-19, -8), Vector2(19, -8), Vector2(15, 16), Vector2(0, 22), Vector2(-15, 16)])
	draw_colored_polygon(poncho, Color("873d35"))
	draw_polyline(PackedVector2Array([poncho[0], poncho[1], poncho[2], poncho[3], poncho[4], poncho[0]]), Color("382824"), 3.0)
	draw_line(Vector2(-16, 1), Vector2(14, 11), Color("d39b55"), 4)
	draw_line(Vector2(-15, 6), Vector2(10, 15), Color("e2c077"), 2)
	draw_circle(Vector2(0, -17), 12, Color("a96f4f"))
	draw_arc(Vector2(0, -17), 12, PI, TAU, 14, Color("211f22"), 8)
	draw_circle(Vector2(-5, -17), 1.6, Color("171a20"))
	draw_circle(Vector2(5, -17), 1.6, Color("171a20"))
	draw_line(Vector2(-14, -9), Vector2(12, 17), Color("4c3227"), 2.5)
	draw_circle(Vector2(15, 16), 6, Color("a56a3e"))


func _draw_back(bob: float) -> void:
	_draw_shadow_and_legs(bob)
	var poncho := PackedVector2Array([Vector2(-19, -8), Vector2(19, -8), Vector2(15, 17), Vector2(0, 22), Vector2(-15, 17)])
	draw_colored_polygon(poncho, Color("78352f"))
	draw_polyline(PackedVector2Array([poncho[0], poncho[1], poncho[2], poncho[3], poncho[4], poncho[0]]), Color("332521"), 3.0)
	draw_line(Vector2(-15, 6), Vector2(15, 6), Color("d39b55"), 4)
	draw_line(Vector2(-13, 12), Vector2(13, 12), Color("e2c077"), 2)
	draw_circle(Vector2(0, -17), 12, Color("915f47"))
	draw_circle(Vector2(0, -19), 12, Color("211f22"))
	draw_rect(Rect2(-12, -20, 24, 9), Color("272329"))
	draw_line(Vector2(13, -7), Vector2(-10, 17), Color("4c3227"), 2.5)
	draw_circle(Vector2(-14, 16), 6, Color("a56a3e"))


func _draw_side(bob: float, direction: float) -> void:
	draw_custom_ellipse(Vector2(0, 22), Vector2(22, 7), Color(0.08, 0.07, 0.06, 0.38))
	draw_rect(Rect2(-9 + bob, 9, 9, 17), Color("2f2926"))
	draw_rect(Rect2(2 - bob, 9, 9, 17), Color("2f2926"))
	var poncho := PackedVector2Array([Vector2(-17, -8), Vector2(17, -8), Vector2(15, 15), Vector2(4, 22), Vector2(-15, 16)])
	draw_colored_polygon(poncho, Color("823831"))
	draw_polyline(PackedVector2Array([poncho[0], poncho[1], poncho[2], poncho[3], poncho[4], poncho[0]]), Color("352622"), 3.0)
	draw_line(Vector2(-13 * direction, 0), Vector2(14 * direction, 10), Color("d39b55"), 4)
	var head_center := Vector2(3 * direction, -17)
	draw_circle(head_center, 12, Color("a96f4f"))
	draw_arc(head_center, 12, PI, TAU, 14, Color("211f22"), 8)
	draw_circle(head_center + Vector2(6 * direction, -1), 1.7, Color("171a20"))
	draw_line(head_center + Vector2(9 * direction, 1), head_center + Vector2(14 * direction, 2), Color("7b4939"), 2)
	draw_circle(Vector2(-14 * direction, 15), 6, Color("a56a3e"))


func _draw_shadow_and_legs(bob: float) -> void:
	draw_custom_ellipse(Vector2(0, 22), Vector2(22, 7), Color(0.08, 0.07, 0.06, 0.38))
	draw_rect(Rect2(-13, 9 + bob, 9, 17), Color("2f2926"))
	draw_rect(Rect2(4, 9 - bob, 9, 17), Color("2f2926"))
	draw_rect(Rect2(-14, 23 + bob, 10, 5), Color("241f1d"))
	draw_rect(Rect2(4, 23 - bob, 10, 5), Color("241f1d"))


func draw_custom_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for index in range(24):
		var angle := TAU * float(index) / 24.0
		points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
	draw_colored_polygon(points, color)
