extends Area2D

signal dialogue_requested(speaker: String, lines: Array, voice_clips: Array, action_after: String)

const VOICE_INTRO_01 = preload("res://assets/audio/dialogue/florencio_intro_01.wav")
const VOICE_INTRO_02 = preload("res://assets/audio/dialogue/florencio_intro_02.wav")
const VOICE_INTRO_03 = preload("res://assets/audio/dialogue/florencio_intro_03.wav")
const VOICE_INTRO_04 = preload("res://assets/audio/dialogue/florencio_intro_04.wav")
const VOICE_REPEAT = preload("res://assets/audio/dialogue/florencio_repeat.wav")
const VOICE_ALL_CLUES_01 = preload("res://assets/audio/dialogue/florencio_all_clues_01.wav")
const VOICE_ALL_CLUES_02 = preload("res://assets/audio/dialogue/florencio_all_clues_02.wav")
const VOICE_COMPLETED = preload("res://assets/audio/dialogue/florencio_completed.wav")

var state := "idle"


func _ready() -> void:
	name = "FlorencioMamani"
	z_index = 15
	scale = Vector2(1.12, 1.12)
	collision_layer = 2
	collision_mask = 0
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(34, 44)
	collision.shape = shape
	add_child(collision)
	var name_label := Label.new()
	name_label.text = "FLORENCIO"
	name_label.position = Vector2(-62, -64)
	name_label.size = Vector2(124, 22)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.add_theme_font_size_override("font_size", 12)
	name_label.add_theme_color_override("font_color", Color("f6df9a"))
	name_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	name_label.add_theme_constant_override("shadow_offset_x", 2)
	name_label.add_theme_constant_override("shadow_offset_y", 2)
	add_child(name_label)
	queue_redraw()


func interact(_player: Node) -> void:
	match state:
		"idle":
			dialogue_requested.emit("Florencio Mamani", [
				"Juan, el cerro está inquieto. Las sombras despertaron y el camino ya no es seguro.",
				"Cruza el pueblo y entra por el portal de la cumbre. Allí comienza el verdadero ascenso.",
				"En el cerro recupera los tres recuerdos. Tu honda puede dispersar las sombras.",
				"No sigas solamente el brillo de la plata. Escucha lo que protege este pueblo."
			], [VOICE_INTRO_01, VOICE_INTRO_02, VOICE_INTRO_03, VOICE_INTRO_04], "start_journey")
		"mission_active":
			dialogue_requested.emit("Florencio Mamani", [
				"El sendero está abierto. Ve con cuidado, Juan, y no olvides volver."
			], [VOICE_REPEAT], "")
		"all_clues":
			dialogue_requested.emit("Florencio Mamani", [
				"Ya reuniste los tres recuerdos. El sendero dorado del cerro está abierto.",
				"Llega al portal de la cumbre. Allí podrás devolverle su memoria a Kallami."
			], [VOICE_ALL_CLUES_01, VOICE_ALL_CLUES_02], "unlock_exit")
		"completed":
			dialogue_requested.emit("Florencio Mamani", [
				"La plata puede agotarse; la memoria compartida no. El pueblo volverá a caminar sin miedo."
			], [VOICE_COMPLETED], "")


func set_mission_active() -> void:
	state = "mission_active"


func set_all_clues_found() -> void:
	state = "all_clues"


func set_completed() -> void:
	state = "completed"


func _draw() -> void:
	draw_circle(Vector2(0, 21), 21, Color(0.08, 0.07, 0.06, 0.36))
	draw_rect(Rect2(-13, 10, 9, 16), Color("302a25"))
	draw_rect(Rect2(4, 10, 9, 16), Color("302a25"))
	var poncho := PackedVector2Array([Vector2(-20, -9), Vector2(20, -9), Vector2(17, 20), Vector2(6, 25), Vector2(-6, 25), Vector2(-17, 20)])
	draw_colored_polygon(poncho, Color("643a2f"))
	draw_polyline(PackedVector2Array([poncho[0], poncho[1], poncho[2], poncho[3], poncho[4], poncho[5], poncho[0]]), Color("30231f"), 3)
	draw_rect(Rect2(-15, -6, 5, 29), Color("d29143"))
	draw_rect(Rect2(10, -6, 5, 29), Color("d29143"))
	draw_rect(Rect2(-8, -7, 16, 27), Color("263743"))
	draw_circle(Vector2(0, -18), 12, Color("9b674d"))
	draw_circle(Vector2(-5, -18), 1.5, Color("182029"))
	draw_circle(Vector2(5, -18), 1.5, Color("182029"))
	draw_colored_polygon(PackedVector2Array([Vector2(-12, -25), Vector2(12, -25), Vector2(7, -37), Vector2(-7, -37)]), Color("8c5a39"))
	draw_rect(Rect2(-11, -31, 22, 4), Color("d49a52"))
	draw_circle(Vector2(0, -41), 4, Color("7b452f"))
	draw_arc(Vector2.ZERO, 37, 0, TAU, 28, Color(0.95, 0.82, 0.42, 0.72), 2.5)
