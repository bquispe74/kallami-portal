# Plan de mejoras de jugabilidad y presentación

## Objetivo de diseño

La siguiente versión debe conservar el recorrido narrativo de Kallami, pero lograr que cada minuto tenga una decisión: explorar, esquivar, atacar, buscar un secreto o interpretar una pista. La meta razonable para la defensa es una experiencia de 15 a 20 minutos con inicio claro, crecimiento de dificultad y un cierre memorable.

## Estado incorporado hasta la versión 1.5

- Alternancia inmediata entre **ventana 960 × 540** y **pantalla completa** mediante `F11`.
- Ocho diálogos de Florencio con voz neuronal masculina en español de Bolivia, más pausada y grave.
- Voz completa para la advertencia inicial, repetición, recuperación de memorias y epílogo.
- Audio almacenado dentro del proyecto: el juego no necesita internet para reproducirlo.
- Esquiva con `Espacio`, invulnerabilidad breve, efecto de desplazamiento y barra de enfriamiento.
- Honda cargable con alcance, velocidad y daño variables.
- Sombras cazadoras, ecos tiradores y guardianes con ráfagas.
- Avisos visuales de ataque, vida de enemigos, impactos, sacudida de cámara y nuevos efectos sonoros.
- Transición de iluminación del ascenso hacia la boca de la cueva, con tonos fríos y cristales azules.
- Derrumbe jugable al ordenar las memorias: tres oleadas de rocas telegrafiadas, esquiva y apertura del sello.
- Botón **Cambiar perfil** desde pausa y desde la pantalla final; guarda y cierra la sesión antes de mostrar los perfiles.
- Alternancia de pantalla completa con `F11` y botones visibles; la interfaz indica el modo actual y ofrece volver a ventana.
- Música original de suspenso durante el derrumbe final, con fundido de entrada/salida y atenuación del ambiente.

## Prioridad 1: que combatir se sienta bien

| Mejora | Cambio visible | Razón |
|---|---|---|
| Esquiva corta | Rodar con `Espacio`, invulnerable durante una fracción de segundo y con enfriamiento | Agrega una decisión defensiva y evita que el combate sea solo caminar y presionar `F` |
| Honda cargada | Mantener `F` aumenta alcance y daño; soltar dispara | Da control, riesgo y precisión |
| Retroalimentación de impacto | Destello, partículas de polvo, sacudida breve y pausa de 0,05 s | Hace que cada piedra se sienta pesada |
| Tres tipos de sombra | Perseguidora, tiradora y guardián resistente | Obliga a cambiar de posición y prioridad |
| Hierbas curativas limitadas | Pequeños recursos fuera del camino principal | Premia explorar y permite recuperarse sin reiniciar |

La esquiva, la sombra a distancia, los efectos de impacto y el derrumbe final ya están incorporados. El siguiente bloque recomendado es añadir **hierbas curativas**, **tres secretos opcionales** y una **segunda fase para el último guardián**.

## Prioridad 2: exploración con recompensa

El minimapa debe orientar, no resolver el recorrido. Conviene dejar el camino principal reconocible y colocar ramales cortos con una recompensa concreta: una memoria opcional, una mejora de salud, un fragmento de plata o una conversación. El jugador debería ver algo llamativo a lo lejos, buscar cómo llegar y regresar al sendero sin perderse demasiado.

- Añadir tres fragmentos de plata ocultos, uno por nivel.
- Usar huellas, fogatas, banderas y sonidos para insinuar rutas.
- Colocar un cofre o altar secundario detrás de cada combate difícil.
- Hacer que la niebla revele áreas por sectores y conserve lo descubierto al guardar.
- Mostrar un porcentaje de exploración solo en el mapa de pausa.

## Prioridad 3: un final jugable, no solo una puerta

Los guardianes de la cámara pueden convertirse en una pelea final de dos fases. Primero alternan ataques y obligan a moverse entre columnas. Cuando uno cae, el otro gana velocidad y lanza una onda oscura. Después del combate, los tres pedestales mantienen el rompecabezas narrativo actual. Así el cierre evalúa combate, memoria y exploración.

El desenlace ahora tiene señales claras: un rugido anuncia el temblor, círculos rojos marcan dónde caen las rocas y la esquiva permite salir de la zona. Tras tres oleadas se abre el sello y el jugador debe correr al altar. No conviene aumentar la vida sin agregar patrones; eso solo alarga el combate.

## Prioridad 4: acabado visual

El salto visual más grande vendrá de reemplazar las formas básicas por un conjunto coherente de arte pixelado. Todo debería compartir tamaño de píxel, dirección de luz y paleta.

- Animaciones de Juan en cuatro direcciones: quieto, caminar, atacar, recibir daño y rodar.
- Dos o tres cuadros de movimiento para cada tipo de sombra.
- Casas con puertas, ventanas, techos, cercas y puestos distintos para evitar repetición.
- Capas de fondo con montañas y nubes lentas para dar profundidad.
- Sombras suaves debajo de personajes y construcciones.
- Polvo al caminar, hojas movidas por el viento, brasas en fogatas y motas de plata en la cámara.
- Transiciones de color: pueblo cálido, ascenso frío con una boca de cueva azul y cámara azul plateada.
- Cámara con seguimiento amortiguado y un pequeño desplazamiento hacia la dirección de movimiento.

## Prioridad 5: sonido y música

La música debería responder a la situación sin cortar de golpe. Una base ambiental puede mantenerse mientras entra una capa de percusión al acercarse una sombra. Durante los diálogos, la música debe bajar entre 5 y 7 dB para que la voz sea clara.

- Ambiente propio para pueblo, viento del cerro y cámara subterránea.
- Sonidos posicionales de sombras, agua, banderas y fogatas.
- Variaciones de lanzamiento e impacto para evitar repetición.
- Señal musical breve al encontrar una memoria o abrir un portal.
- Control separado de volumen para música, efectos y voces.

## Prioridad 6: interfaz y accesibilidad

- Menú de opciones con ventana/pantalla completa, volumen y sacudida de cámara.
- Indicador visual del enfriamiento de la honda y de la esquiva.
- Barra de vida sobre Juan que cambie de verde a amarillo y rojo.
- Tutoriales breves que desaparezcan después de usar cada acción.
- Texto de diálogo más grande y opción para acelerar o silenciar la voz.
- Dificultad narrativa, normal y desafío; debe cambiar daño y agresividad, no el contenido.
- Reasignación de teclas si el tiempo de desarrollo lo permite.

## Prioridad 7: rejugabilidad y perfiles

Los perfiles ya separan el progreso. Se puede aprovechar esa base con estadísticas pequeñas al terminar: tiempo, daño recibido, secretos encontrados y precisión con la honda. Una medalla por nivel ofrece una razón para repetir sin construir otro juego completo.

También conviene añadir un códice por perfil. Cada memoria encontrada desbloquea una ilustración y un párrafo sobre el pueblo, los mineros o el cerro. Ese contenido refuerza el tema del proyecto y convierte la exploración en algo más que sumar objetos.

## Orden recomendado de producción

1. Probar la nueva voz, el cambio `F11` y el cambio de perfil en Linux y Windows. **Implementado; falta prueba final en ambos sistemas.**
2. Implementar esquiva, sombra a distancia y respuesta de impacto. **Implementado en la versión 1.3.**
3. Añadir un derrumbe final con zonas de impacto visibles, ruta de salida y música de persecución. **Implementado en la versión 1.5.**
4. Crear una segunda fase para el último guardián.
5. Sustituir primero a Juan, Florencio y las sombras por sprites animados; luego mejorar el escenario.
6. Añadir opciones de audio, controles y accesibilidad.
7. Incorporar secretos, estadísticas finales y códice solo después de estabilizar el recorrido principal.

## Criterio de versión lista para defensa

La versión puede considerarse lista cuando una partida nueva llega al final sin errores, el guardado restaura nivel, posición, vida y objetivos, las tres etapas se distinguen visual y sonoramente, cada control aparece dentro del juego, y el jugador entiende por qué ganó o perdió sin necesitar una explicación externa.
