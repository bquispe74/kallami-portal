"""Genera audio original y libre de dependencias para Kallami.

Los WAV resultantes se sintetizan desde cero. No contienen muestras de terceros.
"""

from __future__ import annotations

import math
import wave
from pathlib import Path

import numpy as np


RATE = 44_100
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "cliente_godot" / "assets" / "audio"
RNG = np.random.default_rng(266)


def envelope(length: int, attack: float = 0.03, release: float = 0.15) -> np.ndarray:
    env = np.ones(length, dtype=np.float64)
    attack_samples = min(length, int(RATE * attack))
    release_samples = min(length, int(RATE * release))
    if attack_samples:
        env[:attack_samples] = np.linspace(0.0, 1.0, attack_samples)
    if release_samples:
        env[-release_samples:] *= np.linspace(1.0, 0.0, release_samples)
    return env


def tone(freq: float, duration: float, volume: float = 1.0, phase: float = 0.0) -> np.ndarray:
    t = np.arange(int(RATE * duration), dtype=np.float64) / RATE
    return np.sin((2.0 * math.pi * freq * t) + phase) * volume


def write_wav(name: str, samples: np.ndarray) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    samples = np.asarray(samples, dtype=np.float64)
    peak = max(float(np.max(np.abs(samples))), 1e-9)
    if peak > 0.96:
        samples = samples * (0.96 / peak)
    pcm = (samples * 32767.0).astype("<i2")
    with wave.open(str(OUT / name), "wb") as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(RATE)
        audio.writeframes(pcm.tobytes())


def village_ambience() -> np.ndarray:
    duration = 24.0
    t = np.arange(int(RATE * duration), dtype=np.float64) / RATE
    bed = 0.075 * np.sin(2 * np.pi * 55 * t)
    bed += 0.045 * np.sin(2 * np.pi * 82.5 * t + 0.8)
    bed += 0.025 * np.sin(2 * np.pi * 110 * t + 1.7)
    wind = RNG.normal(0.0, 1.0, t.size)
    wind = np.convolve(wind, np.ones(900) / 900.0, mode="same") * 0.30
    melody = np.zeros_like(t)
    notes = [220.0, 261.63, 293.66, 246.94, 220.0, 196.0]
    for index, frequency in enumerate(notes):
        start = int((2.0 + index * 3.4) * RATE)
        note = tone(frequency, 1.7, 0.055) * envelope(int(1.7 * RATE), 0.25, 0.65)
        melody[start : start + note.size] += note
        melody[start : start + note.size] += tone(frequency * 2.0, 1.7, 0.018) * envelope(
            note.size, 0.25, 0.65
        )
    return (bed + wind + melody) * envelope(t.size, 0.8, 1.2)


def combat_music() -> np.ndarray:
    duration = 16.0
    t = np.arange(int(RATE * duration), dtype=np.float64) / RATE
    pulse = np.zeros_like(t)
    for beat in np.arange(0.0, duration, 0.5):
        start = int(beat * RATE)
        length = int(0.24 * RATE)
        local_t = np.arange(length) / RATE
        hit = np.sin(2 * np.pi * (76 - 25 * local_t) * local_t)
        hit *= np.exp(-local_t * 14.0) * 0.20
        pulse[start : start + length] += hit[: min(length, t.size - start)]
    drone = 0.09 * np.sin(2 * np.pi * 49 * t)
    drone += 0.045 * np.sin(2 * np.pi * 73.5 * t + np.sin(t * 0.7))
    whisper = RNG.normal(0.0, 0.018, t.size) * (0.4 + 0.6 * np.sin(t * 0.9) ** 2)
    return (pulse + drone + whisper) * envelope(t.size, 0.5, 0.8)


def final_chase_music() -> np.ndarray:
    duration = 12.0
    t = np.arange(int(RATE * duration), dtype=np.float64) / RATE
    drone = 0.080 * np.sin(2 * np.pi * 43.65 * t)
    drone += 0.045 * np.sin(2 * np.pi * 58.27 * t + 0.25 * np.sin(t * 1.7))
    pulse = np.zeros_like(t)
    for beat_index in range(20):
        start = int(beat_index * 0.6 * RATE)
        length = int(0.32 * RATE)
        local_t = np.arange(length, dtype=np.float64) / RATE
        if beat_index % 4 == 0:
            hit = np.sin(2 * np.pi * (82.0 - 112.0 * local_t) * local_t) * 0.34
        else:
            hit = np.sin(2 * np.pi * (119.0 - 165.0 * local_t) * local_t) * 0.18
        hit += RNG.normal(0.0, 0.09, length)
        hit *= np.exp(-local_t * 11.0)
        pulse[start : start + length] += hit
    sequence = np.zeros_like(t)
    notes = [130.81, 155.56, 174.61, 155.56, 146.83, 174.61, 196.0, 174.61]
    step_seconds = 0.3
    for step_index in range(40):
        start = int(step_index * step_seconds * RATE)
        length = int(0.24 * RATE)
        local_t = np.arange(length, dtype=np.float64) / RATE
        frequency = notes[step_index % len(notes)]
        note = np.sin(2 * np.pi * frequency * local_t) * 0.055
        note += np.sin(2 * np.pi * frequency * 2.01 * local_t) * 0.020
        note *= np.exp(-local_t * 3.0) * envelope(length, 0.015, 0.07)
        sequence[start : start + length] += note
    swell = 0.86 + 0.14 * np.sin(2 * np.pi * 0.25 * t) ** 2
    result = (drone + pulse + sequence) * swell
    fade_samples = int(0.12 * RATE)
    result[:fade_samples] *= np.linspace(0.0, 1.0, fade_samples)
    result[-fade_samples:] *= np.linspace(1.0, 0.0, fade_samples)
    return result


def mountain_ambience() -> np.ndarray:
    duration = 24.0
    t = np.arange(int(RATE * duration), dtype=np.float64) / RATE
    wind = RNG.normal(0.0, 1.0, t.size)
    wind = np.convolve(wind, np.ones(1500) / 1500.0, mode="same") * 0.48
    drone = 0.055 * np.sin(2 * np.pi * 46.0 * t)
    drone += 0.035 * np.sin(2 * np.pi * 69.0 * t + np.sin(t * 0.33))
    flute = np.zeros_like(t)
    notes = [293.66, 329.63, 246.94, 220.0, 293.66]
    for index, frequency in enumerate(notes):
        start = int((1.6 + index * 4.1) * RATE)
        note = tone(frequency, 2.0, 0.045) * envelope(int(2.0 * RATE), 0.38, 0.72)
        flute[start : start + note.size] += note
    return (wind + drone + flute) * envelope(t.size, 0.9, 1.1)


def chamber_ambience() -> np.ndarray:
    duration = 24.0
    t = np.arange(int(RATE * duration), dtype=np.float64) / RATE
    drone = 0.085 * np.sin(2 * np.pi * 41.2 * t)
    drone += 0.052 * np.sin(2 * np.pi * 61.8 * t + 0.6)
    drone += 0.026 * np.sin(2 * np.pi * 123.6 * t + np.sin(t * 0.42))
    air = RNG.normal(0.0, 1.0, t.size)
    air = np.convolve(air, np.ones(1100) / 1100.0, mode="same") * 0.32
    shimmer = np.zeros_like(t)
    for start_seconds in [2.8, 8.7, 14.1, 19.4]:
        start = int(start_seconds * RATE)
        note = tone(740.0, 1.8, 0.035) + tone(1110.0, 1.8, 0.018)
        note *= envelope(note.size, 0.08, 1.25)
        shimmer[start : start + note.size] += note
    return (drone + air + shimmer) * envelope(t.size, 0.8, 1.2)


def throw_rock() -> np.ndarray:
    duration = 0.38
    t = np.arange(int(RATE * duration)) / RATE
    sweep = np.sin(2 * np.pi * (850 - 610 * t / duration) * t)
    noise = RNG.normal(0.0, 1.0, t.size)
    return (0.32 * sweep + 0.14 * noise) * np.exp(-t * 8.0) * envelope(t.size, 0.008, 0.09)


def charged_throw() -> np.ndarray:
    duration = 0.58
    t = np.arange(int(RATE * duration)) / RATE
    sweep = np.sin(2 * np.pi * (440 + 1180 * t / duration) * t)
    body = np.sin(2 * np.pi * (145 - 38 * t) * t)
    noise = RNG.normal(0.0, 0.20, t.size)
    return (0.28 * sweep + 0.34 * body + noise) * np.exp(-t * 5.5) * envelope(t.size, 0.008, 0.15)


def dodge() -> np.ndarray:
    duration = 0.34
    t = np.arange(int(RATE * duration)) / RATE
    air = RNG.normal(0.0, 1.0, t.size)
    air = np.convolve(air, np.ones(28) / 28.0, mode="same")
    sweep = np.sin(2 * np.pi * (980 - 690 * t / duration) * t)
    return (air * 0.52 + sweep * 0.13) * np.exp(-t * 8.5) * envelope(t.size, 0.004, 0.10)


def enemy_shot() -> np.ndarray:
    duration = 0.62
    t = np.arange(int(RATE * duration)) / RATE
    pulse = np.sin(2 * np.pi * (190 - 85 * t / duration) * t)
    pulse += 0.45 * np.sin(2 * np.pi * (285 + 24 * np.sin(t * 19.0)) * t)
    whisper = RNG.normal(0.0, 0.12, t.size)
    return (pulse * 0.28 + whisper) * np.exp(-t * 4.8) * envelope(t.size, 0.012, 0.18)


def player_hurt() -> np.ndarray:
    duration = 0.42
    t = np.arange(int(RATE * duration)) / RATE
    thump = np.sin(2 * np.pi * (105 - 42 * t / duration) * t)
    grit = RNG.normal(0.0, 0.22, t.size)
    return (thump * 0.52 + grit) * np.exp(-t * 12.0) * envelope(t.size, 0.003, 0.11)


def rock_hit() -> np.ndarray:
    duration = 0.45
    t = np.arange(int(RATE * duration)) / RATE
    knock = np.sin(2 * np.pi * (125 - 60 * t) * t) * np.exp(-t * 13.0)
    grit = RNG.normal(0.0, 0.24, t.size) * np.exp(-t * 16.0)
    return (knock * 0.65 + grit) * envelope(t.size, 0.004, 0.1)


def shadow_near() -> np.ndarray:
    duration = 2.2
    t = np.arange(int(RATE * duration)) / RATE
    warble = np.sin(2 * np.pi * (87 + 12 * np.sin(t * 5.0)) * t)
    breath = RNG.normal(0.0, 0.16, t.size)
    breath = np.convolve(breath, np.ones(90) / 90.0, mode="same")
    return (warble * 0.30 + breath) * envelope(t.size, 0.22, 0.42)


def shadow_defeat() -> np.ndarray:
    duration = 1.15
    t = np.arange(int(RATE * duration)) / RATE
    fall = np.sin(2 * np.pi * (430 - 310 * t / duration) * t)
    air = RNG.normal(0.0, 0.16, t.size)
    return (fall * 0.30 + air) * np.exp(-t * 2.8) * envelope(t.size, 0.01, 0.28)


def earthquake() -> np.ndarray:
    duration = 3.2
    t = np.arange(int(RATE * duration), dtype=np.float64) / RATE
    low_rumble = 0.30 * np.sin(2 * np.pi * 31.0 * t)
    low_rumble += 0.17 * np.sin(2 * np.pi * 43.0 * t + np.sin(t * 1.8))
    noise = RNG.normal(0.0, 1.0, t.size)
    rumble_noise = np.convolve(noise, np.ones(1300) / 1300.0, mode="same") * 1.8
    hits = np.zeros_like(t)
    for start_seconds in [0.22, 1.18, 2.28]:
        start = int(start_seconds * RATE)
        length = int(0.48 * RATE)
        local_t = np.arange(length, dtype=np.float64) / RATE
        impact = np.sin(2 * np.pi * (58.0 - 30.0 * local_t) * local_t)
        impact += RNG.normal(0.0, 0.28, length)
        impact *= np.exp(-local_t * 5.5)
        hits[start : start + length] += impact
    swell = 0.68 + 0.32 * np.sin(2 * np.pi * 0.42 * t) ** 2
    return (low_rumble + rumble_noise + hits * 0.52) * swell * envelope(t.size, 0.10, 0.42)


def clue_pickup() -> np.ndarray:
    duration = 1.1
    result = np.zeros(int(RATE * duration))
    for index, frequency in enumerate([440.0, 554.37, 659.25, 880.0]):
        start = int(index * 0.16 * RATE)
        note = tone(frequency, 0.48, 0.24) * envelope(int(0.48 * RATE), 0.01, 0.28)
        result[start : start + note.size] += note
    return result


def dialogue_blip() -> np.ndarray:
    result = tone(210.0, 0.075, 0.20) + tone(315.0, 0.075, 0.08)
    return result * envelope(result.size, 0.005, 0.04)


def ui_confirm() -> np.ndarray:
    result = tone(620.0, 0.16, 0.18) + tone(930.0, 0.16, 0.10)
    return result * envelope(result.size, 0.006, 0.08)


def main() -> None:
    write_wav("ambient_village.wav", village_ambience())
    write_wav("ambient_mountain.wav", mountain_ambience())
    write_wav("ambient_chamber.wav", chamber_ambience())
    write_wav("combat_tension.wav", combat_music())
    write_wav("final_chase.wav", final_chase_music())
    write_wav("throw_rock.wav", throw_rock())
    write_wav("charged_throw.wav", charged_throw())
    write_wav("dodge.wav", dodge())
    write_wav("enemy_shot.wav", enemy_shot())
    write_wav("player_hurt.wav", player_hurt())
    write_wav("rock_hit.wav", rock_hit())
    write_wav("shadow_near.wav", shadow_near())
    write_wav("shadow_defeat.wav", shadow_defeat())
    write_wav("earthquake.wav", earthquake())
    write_wav("clue_pickup.wav", clue_pickup())
    write_wav("dialogue_blip.wav", dialogue_blip())
    write_wav("ui_confirm.wav", ui_confirm())
    print(f"Audio generado en {OUT}")


if __name__ == "__main__":
    main()
