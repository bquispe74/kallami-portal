extends Area2D

signal collected(clue_id: String)

@export var clue_id := "pista_comunidad"
@export var display_name := "Memoria de la comunidad"
@export var accent := Color("83b6c9")

var active := false
var was_collected := false
var _pulse := 0.0


func _ready() -> void:
	name = "Pista_%s" % clue_id
	z_index = 12
	collision_layer = 2
	collision_mask = 0
	monitorable = false
	visible = false
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 25.0
	collision.shape = shape
	add_child(collision)
	var label := Label.new()
	label.text = display_name.to_upper()
	label.position = Vector2(-105, -58)
	label.size = Vector2(210, 24)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 12)
	label.add_theme_color_override("font_color", Color("f3dda0"))
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.92))
	label.add_theme_constant_override("shadow_offset_x", 2)
	label.add_theme_constant_override("shadow_offset_y", 2)
	add_child(label)
	queue_redraw()


func _process(delta: float) -> void:
	if visible:
		_pulse += delta * 3.5
		queue_redraw()


func activate() -> void:
	if was_collected:
		return
	active = true
	visible = true
	monitorable = true


func is_available() -> bool:
	return active and not was_collected


func mark_collected() -> void:
	was_collected = true
	active = false
	visible = false
	monitorable = false


func interact(_player: Node) -> void:
	if not active or was_collected:
		return
	mark_collected()
	collected.emit(clue_id)


func _draw() -> void:
	var glow := 28.0 + sin(_pulse) * 5.0
	draw_circle(Vector2.ZERO, glow, Color(accent.r, accent.g, accent.b, 0.22))
	draw_circle(Vector2.ZERO, 21, Color(0.045, 0.075, 0.10, 0.78))
	var diamond := PackedVector2Array([Vector2(0, -17), Vector2(13, 0), Vector2(0, 17), Vector2(-13, 0)])
	draw_colored_polygon(diamond, Color("e2e9ea"))
	draw_polyline(PackedVector2Array([diamond[0], diamond[1], diamond[2], diamond[3], diamond[0]]), accent, 3)
	draw_line(Vector2(-6, -3), Vector2(5, -8), Color(1, 1, 1, 0.82), 2)

