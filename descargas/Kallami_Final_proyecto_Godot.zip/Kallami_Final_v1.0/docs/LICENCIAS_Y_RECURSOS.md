# Licencias y procedencia de recursos

## Código y arte procedural

El escenario, Juan, Florencio en el mundo, las sombras, checkpoints, pistas, proyectiles, HUD, niebla y minimapa se construyen con scripts y primitivas de Godot incluidos en este paquete. No se incorporaron paquetes comerciales ni sprites descargados de terceros.

## Retrato de diálogo

`cliente_godot/assets/dialogue/florencio_talk.png` fue generado específicamente para este prototipo mediante una herramienta de generación de imágenes de OpenAI, usando como referencia el boceto conceptual proporcionado por el equipo. Contiene dos fotogramas originales —boca cerrada y abierta— y se utiliza para acompañar la conversación de Florencio.

## Audio

Los ambientes y efectos de `cliente_godot/assets/audio/` fueron sintetizados desde cero por `tools/generar_audio.py`. El script usa ondas, ruido y envolventes; no contiene grabaciones, melodías tradicionales ni muestras de terceros. Los cinco clips de Florencio fueron generados localmente con el sintetizador `flite` incluido como filtro de FFmpeg y procesados con ecualización, eco leve y normalización. `tools/generar_voces.sh` documenta y reproduce el proceso. Son voces artificiales de prototipo, no la grabación de una persona real.

## Bocetos de referencia

Las imágenes bajo `cliente_godot/assets/referencias/` fueron entregadas por el equipo como orientación visual del proyecto. El juego las conserva para trazabilidad; solo la imagen `nivel_1_comunidad.png` aparece como fondo parcial de la pantalla de perfiles. No se presentan como reconstrucciones históricas del Cerro Kallami.

## Declaración de alcance cultural

La obra es ficticia y académica. Toma referencias paisajísticas del altiplano y del nombre Kallami, pero no afirma reproducir literalmente testimonios, ceremonias ni patrimonio de una comunidad. Cualquier publicación posterior debería validar nombres, símbolos y relatos con sus fuentes y registrar permisos adicionales.
