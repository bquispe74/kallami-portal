extends Node2D

const VillageLevel = preload("res://scripts/level_art.gd")
const MountainLevel = preload("res://scripts/mountain_level.gd")
const SilverChamberLevel = preload("res://scripts/silver_chamber_level.gd")
const Player = preload("res://scripts/player.gd")
const Florencio = preload("res://scripts/npc_florencio.gd")
const Clue = preload("res://scripts/clue.gd")
const Checkpoint = preload("res://scripts/checkpoint.gd")
const Shadow = preload("res://scripts/shadow.gd")
const RockProjectile = preload("res://scripts/rock_projectile.gd")
const ShadowProjectile = preload("res://scripts/shadow_projectile.gd")
const ImpactEffect = preload("res://scripts/impact_effect.gd")
const FallingRock = preload("res://scripts/falling_rock.gd")
const MemoryPedestal = preload("res://scripts/memory_pedestal.gd")
const FogOfWar = preload("res://scripts/fog_of_war.gd")
const AudioDirector = preload("res://scripts/audio_director.gd")
const HUD = preload("res://scripts/hud.gd")

const WORLD_SIZE := Vector2(2400, 1500)
const WINDOWED_SIZE := Vector2i(960, 540)
const INTERACTION_DISTANCE := 118.0
const AUTOSAVE_SECONDS := 2.5
const LEVEL_TITLES := {
	1: "La comunidad",
	2: "El ascenso",
	3: "La cámara de plata"
}
const LEVEL_SUBTITLES := {
	1: "Escucha la advertencia de Florencio y encuentra la entrada al cerro.",
	2: "Recupera las tres memorias entre senderos, niebla y sombras.",
	3: "Vence a los guardianes, ordena las memorias y escapa del derrumbe."
}
const LEVEL_SPAWNS := {
	1: {"inicio": Vector2(220, 1260), "plaza": Vector2(1050, 835), "cerro": Vector2(2050, 570)},
	2: {"ascenso_inicio": Vector2(190, 1320), "ascenso_medio": Vector2(1375, 860)},
	3: {"camara_inicio": Vector2(1200, 1320), "camara_final": Vector2(1200, 475)}
}
const LEVEL_START_CHECKPOINTS := {1: "inicio", 2: "ascenso_inicio", 3: "camara_inicio"}
const LEVEL_EXIT_POSITIONS := {
	1: Vector2(2205, 255), 2: Vector2(2200, 205), 3: Vector2(1200, 205)
}
const CLUE_DEFINITIONS := [
	{"id": "pista_comunidad", "name": "Memoria de la comunidad", "position": Vector2(650, 1155), "color": Color("83b6c9")},
	{"id": "pista_mineros", "name": "Señal de los mineros", "position": Vector2(1375, 760), "color": Color("d3aa55")},
	{"id": "pista_cerro", "name": "Relato del cerro", "position": Vector2(1990, 430), "color": Color("a08ac9")}
]
const VILLAGE_SHADOW_SPAWNS: Array[Vector2] = [
	Vector2(980, 1180), Vector2(1580, 930), Vector2(2040, 620)
]
const MOUNTAIN_SHADOW_SPAWNS: Array[Vector2] = [
	Vector2(520, 1260), Vector2(760, 1080), Vector2(820, 900),
	Vector2(1110, 880), Vector2(1390, 850), Vector2(1590, 820),
	Vector2(1810, 690), Vector2(1990, 515), Vector2(2120, 330)
]
const CHAMBER_GUARDIAN_SPAWNS: Array[Vector2] = [Vector2(930, 1060), Vector2(1470, 1020)]
const PEDESTAL_DEFINITIONS := [
	{"order": 0, "name": "El pueblo recuerda unido", "position": Vector2(1700, 760), "color": Color("83b6c9")},
	{"order": 1, "name": "Los mineros dejaron la señal", "position": Vector2(700, 760), "color": Color("d3aa55")},
	{"order": 2, "name": "El cerro protegió la memoria", "position": Vector2(1200, 620), "color": Color("a08ac9")}
]

var world_container: Node2D
var level
var player
var florencio
var clues: Array = []
var checkpoints: Array = []
var shadows: Array = []
var pedestals: Array = []
var fog
var audio
var hud

var current_level := 1
var mission_state := 0
var collected_clue_ids: Array[String] = []
var current_checkpoint := "inicio"
var pending_dialogue_action := ""
var game_completed := false
var puzzle_step := 0
var guardians_remaining := 0
var transition_in_progress := false
var collapse_in_progress := false
var autosave_timer: Timer
var _progress_ready := false
var _last_requested_signature := ""
var _collapse_rng := RandomNumberGenerator.new()


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_collapse_rng.randomize()
	_ensure_input_actions()
	_build_game_shell()
	hud.set_fullscreen_state(_is_fullscreen())
	_connect_game_manager()
	_setup_autosave()
	if GameManager.has_active_session():
		hud.finish_profile_login(GameManager.profile_name)
		GameManager.load_progress()
	else:
		GameManager.list_profiles()


func _process(_delta: float) -> void:
	if not is_instance_valid(hud) or not is_instance_valid(player):
		return
	hud.set_combat_state(player.get_dodge_ready_ratio(), player.get_charge_ratio(), player.is_charging())
	if transition_in_progress or game_completed or hud.is_dialogue_open() or not player.input_enabled:
		hud.set_interaction_hint("")
		return
	var target = _nearest_interactable()
	if target == florencio:
		hud.set_interaction_hint("[E] HABLAR CON FLORENCIO")
	elif target != null and target in clues:
		hud.set_interaction_hint("[E] RECOGER %s" % target.display_name.to_upper())
	elif target != null and target in pedestals:
		hud.set_interaction_hint("[E] RECORDAR • %s" % target.display_name.to_upper())
	else:
		hud.set_interaction_hint("")


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("pantalla_completa") and not event.is_echo():
		_toggle_fullscreen()
		_mark_input_handled()


func _unhandled_input(event: InputEvent) -> void:
	if not is_instance_valid(hud):
		return
	if hud.is_title_visible():
		return
	if event.is_action_pressed("guardar"):
		_save_progress()
		hud.show_message("Guardado manual enviado al perfil")
		_mark_input_handled()
		return
	if event.is_action_pressed("pausa"):
		get_tree().paused = not get_tree().paused
		hud.set_pause_visible(get_tree().paused)
		audio.set_game_paused(get_tree().paused)
		_mark_input_handled()
		return
	if get_tree().paused:
		return
	if event.is_action_pressed("interactuar") and player.input_enabled:
		_on_interaction_requested()
		_mark_input_handled()


func _build_game_shell() -> void:
	player = Player.new()
	player.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(player)
	player.set_input_enabled(false)
	player.health_changed.connect(_on_health_changed)
	player.died.connect(_on_player_died)
	player.attack_requested.connect(_on_attack_requested)
	player.dodge_started.connect(_on_dodge_started)
	player.hurt.connect(_on_player_hurt)
	audio = AudioDirector.new()
	add_child(audio)
	hud = HUD.new()
	add_child(hud)
	hud.dialogue_finished.connect(_on_dialogue_finished)
	hud.new_game_requested.connect(_on_new_game_requested)
	hud.profile_switch_requested.connect(_on_profile_switch_requested)
	hud.fullscreen_requested.connect(_toggle_fullscreen)
	hud.profile_create_requested.connect(GameManager.create_profile)
	hud.profile_login_requested.connect(GameManager.login_profile)
	hud.profile_delete_requested.connect(GameManager.delete_profile)
	hud.set_objective("Inicia sesión para continuar")
	hud.set_health(5, 5)
	hud.set_clues(0, 3)
	hud.set_server_status(false, "Consultando servidor...")
	_enter_level(1, "inicio", false)
	player.set_input_enabled(false)


func _enter_level(level_number: int, checkpoint_id: String, show_card: bool = true) -> void:
	current_level = clampi(level_number, 1, 3)
	current_checkpoint = checkpoint_id
	if is_instance_valid(world_container):
		world_container.free()
	world_container = Node2D.new()
	world_container.name = "MundoNivel%d" % current_level
	add_child(world_container)
	clues.clear()
	checkpoints.clear()
	shadows.clear()
	pedestals.clear()
	florencio = null
	guardians_remaining = 0
	match current_level:
		1:
			level = VillageLevel.new()
		2:
			level = MountainLevel.new()
		3:
			level = SilverChamberLevel.new()
	world_container.add_child(level)
	level.exit_reached.connect(_on_exit_reached)
	player.global_position = _spawn_position(current_checkpoint)
	match current_level:
		1:
			_build_village_content()
		2:
			_build_mountain_content()
		3:
			_build_chamber_content()
	fog = FogOfWar.new()
	fog.process_mode = Node.PROCESS_MODE_PAUSABLE
	world_container.add_child(fog)
	fog.setup(player)
	if current_level == 2:
		fog.set_cave_transition(Vector2(2200, 205), 720.0)
	audio.setup(player, shadows)
	audio.set_level(current_level)
	hud.set_level(current_level, str(LEVEL_TITLES[current_level]))
	hud.set_clues(collected_clue_ids.size(), 3)
	hud.setup_minimap(player, _minimap_landmarks(), str(LEVEL_TITLES[current_level]))
	_apply_level_state()
	if show_card:
		hud.show_level_card(current_level, str(LEVEL_TITLES[current_level]), str(LEVEL_SUBTITLES[current_level]))


func _build_village_content() -> void:
	florencio = Florencio.new()
	florencio.position = Vector2(405, 1180)
	florencio.process_mode = Node.PROCESS_MODE_PAUSABLE
	world_container.add_child(florencio)
	florencio.dialogue_requested.connect(_on_dialogue_requested)
	_create_checkpoint("plaza", _spawn_position("plaza"))
	_create_checkpoint("cerro", _spawn_position("cerro"))
	if mission_state >= 1:
		_spawn_shadows(VILLAGE_SHADOW_SPAWNS, 245.0)


func _build_mountain_content() -> void:
	for definition in CLUE_DEFINITIONS:
		var clue = Clue.new()
		clue.clue_id = str(definition["id"])
		clue.display_name = str(definition["name"])
		clue.accent = definition["color"]
		clue.position = definition["position"]
		clue.process_mode = Node.PROCESS_MODE_PAUSABLE
		world_container.add_child(clue)
		clue.collected.connect(_on_clue_collected)
		clues.append(clue)
	_create_checkpoint("ascenso_medio", _spawn_position("ascenso_medio"))
	_spawn_shadows(MOUNTAIN_SHADOW_SPAWNS, 290.0)


func _build_chamber_content() -> void:
	for definition in PEDESTAL_DEFINITIONS:
		var pedestal = MemoryPedestal.new()
		pedestal.order_index = int(definition["order"])
		pedestal.display_name = str(definition["name"])
		pedestal.position = definition["position"]
		pedestal.process_mode = Node.PROCESS_MODE_PAUSABLE
		world_container.add_child(pedestal)
		pedestal.selected.connect(_on_pedestal_selected)
		pedestals.append(pedestal)
	_create_checkpoint("camara_final", _spawn_position("camara_final"))
	if not game_completed and puzzle_step == 0:
		_spawn_shadows(CHAMBER_GUARDIAN_SPAWNS, 390.0, true)
		guardians_remaining = CHAMBER_GUARDIAN_SPAWNS.size()


func _spawn_shadows(spawn_points: Array[Vector2], detection: float, guardians: bool = false) -> void:
	for shadow_index in range(spawn_points.size()):
		var enemy = Shadow.new()
		enemy.position = spawn_points[shadow_index]
		enemy.target = player
		enemy.detection_radius = detection + float(shadow_index % 3) * 18.0
		enemy.chase_speed = 82.0 + float(shadow_index % 2) * 9.0
		var enemy_kind := "hunter"
		if guardians:
			enemy_kind = "guardian"
		elif shadow_index % 3 == 1:
			enemy_kind = "shooter"
		enemy.configure(enemy_kind)
		enemy.process_mode = Node.PROCESS_MODE_PAUSABLE
		world_container.add_child(enemy)
		if guardians:
			enemy.name = "Guardian_%02d" % (shadow_index + 1)
		elif enemy_kind == "shooter":
			enemy.name = "EcoTirador_%02d" % (shadow_index + 1)
		else:
			enemy.name = "SombraCazadora_%02d" % (shadow_index + 1)
		enemy.defeated.connect(_on_shadow_defeated)
		enemy.ranged_attack_requested.connect(_on_shadow_ranged_attack)
		shadows.append(enemy)


func _create_checkpoint(checkpoint_id: String, at_position: Vector2) -> void:
	var checkpoint = Checkpoint.new()
	checkpoint.checkpoint_id = checkpoint_id
	checkpoint.position = at_position
	checkpoint.process_mode = Node.PROCESS_MODE_PAUSABLE
	world_container.add_child(checkpoint)
	checkpoint.reached.connect(_on_checkpoint_reached)
	checkpoints.append(checkpoint)


func _minimap_landmarks() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if current_level == 1:
		if is_instance_valid(florencio):
			result.append({"position": florencio.position, "color": Color("77c483")})
	elif current_level == 2:
		for definition in CLUE_DEFINITIONS:
			result.append({"position": definition["position"], "color": definition["color"]})
	else:
		for definition in PEDESTAL_DEFINITIONS:
			result.append({"position": definition["position"], "color": definition["color"]})
	result.append({"position": LEVEL_EXIT_POSITIONS[current_level], "color": Color("f0cf67")})
	return result


func _apply_level_state() -> void:
	_restore_checkpoints()
	match current_level:
		1:
			if mission_state >= 1:
				florencio.set_mission_active()
				level.set_exit_active(true)
				hud.set_objective("Cruza el pueblo y entra al portal del cerro")
			else:
				hud.set_objective("Habla con Florencio Mamani [E]")
		2:
			_restore_clues()
			if collected_clue_ids.size() >= 3:
				mission_state = maxi(mission_state, 2)
				level.set_exit_active(true)
				hud.set_objective("Entra a la cámara de plata por el portal superior")
			else:
				hud.set_objective("Recupera %d memorias en el ascenso" % (3 - collected_clue_ids.size()))
		3:
			_restore_pedestals()
			if game_completed:
				level.set_exit_active(true)
				hud.set_objective("Kallami restaurado")
				hud.show_game_complete()
				player.set_input_enabled(false)
			elif puzzle_step >= 3:
				level.set_exit_active(true)
				hud.set_objective("Acércate al altar de plata")
			elif guardians_remaining > 0:
				hud.set_objective("Dispersa a los dos guardianes de la cámara")
			else:
				_activate_pedestals()


func _connect_game_manager() -> void:
	GameManager.server_status_changed.connect(hud.set_server_status)
	GameManager.profiles_loaded.connect(hud.set_profiles)
	GameManager.profile_session_started.connect(_on_profile_session_started)
	GameManager.profile_operation_failed.connect(_on_profile_operation_failed)
	GameManager.profile_deleted.connect(_on_profile_deleted)
	GameManager.progress_loaded.connect(_on_progress_loaded)
	GameManager.progress_saved.connect(_on_progress_saved)
	GameManager.new_game_ready.connect(_on_new_game_ready)


func _on_profile_session_started(profile: Dictionary) -> void:
	var display_name := str(profile.get("display_name", "Perfil"))
	hud.finish_profile_login(display_name)
	hud.set_objective("Cargando partida de %s..." % display_name)
	audio.set_game_paused(false)
	audio.set_finale_active(false)
	audio.play_sfx("confirm")
	GameManager.load_progress()


func _on_profile_switch_requested() -> void:
	if transition_in_progress or collapse_in_progress:
		return
	get_tree().paused = false
	audio.set_game_paused(false)
	audio.set_finale_active(false)
	hud.set_pause_visible(false)
	player.set_input_enabled(false)
	transition_in_progress = true
	_save_progress()
	hud.show_profile_selection("Guardando el perfil actual...")
	await GameManager.close_session()
	transition_in_progress = false
	GameManager.list_profiles()


func _on_profile_operation_failed(message: String) -> void:
	if hud.is_title_visible():
		hud.show_profile_error(message)
	else:
		hud.show_message(message)


func _on_profile_deleted() -> void:
	hud.set_profile_busy(true, "Perfil eliminado. Actualizando la lista...")


func _on_game_started() -> void:
	if not game_completed:
		player.set_input_enabled(true)


func _on_new_game_requested() -> void:
	player.set_input_enabled(false)
	GameManager.reset_current_progress()


func _on_new_game_ready() -> void:
	get_tree().paused = false
	audio.set_finale_active(false)
	get_tree().call_deferred("reload_current_scene")


func _on_interaction_requested() -> void:
	if hud.is_dialogue_open() or game_completed:
		return
	var target = _nearest_interactable()
	if target == null:
		hud.show_message("Acércate a un personaje, memoria u objeto interactivo")
		return
	target.interact(player)


func _nearest_interactable():
	var best_target = null
	var best_distance := INTERACTION_DISTANCE
	if is_instance_valid(florencio):
		var npc_distance: float = player.global_position.distance_to(florencio.global_position)
		if npc_distance <= best_distance:
			best_target = florencio
			best_distance = npc_distance
	for clue in clues:
		if is_instance_valid(clue) and clue.is_available():
			var clue_distance: float = player.global_position.distance_to(clue.global_position)
			if clue_distance <= best_distance:
				best_target = clue
				best_distance = clue_distance
	for pedestal in pedestals:
		if is_instance_valid(pedestal) and pedestal.is_available():
			var pedestal_distance: float = player.global_position.distance_to(pedestal.global_position)
			if pedestal_distance <= best_distance:
				best_target = pedestal
				best_distance = pedestal_distance
	return best_target


func _on_dialogue_requested(speaker: String, lines: Array, voice_clips: Array, action_after: String) -> void:
	pending_dialogue_action = action_after
	player.set_input_enabled(false)
	hud.show_dialogue(speaker, lines, voice_clips)


func _on_dialogue_finished() -> void:
	player.set_input_enabled(true)
	if pending_dialogue_action == "start_journey" and mission_state == 0:
		mission_state = 1
		florencio.set_mission_active()
		level.set_exit_active(true)
		if shadows.is_empty():
			_spawn_shadows(VILLAGE_SHADOW_SPAWNS, 245.0)
			audio.setup(player, shadows)
		hud.set_objective("Cruza el pueblo y entra al portal del cerro")
		hud.show_message("Nivel 1 iniciado • mantén F y esquiva con Espacio")
		_save_progress()
	pending_dialogue_action = ""


func _on_clue_collected(clue_id: String) -> void:
	if current_level != 2 or collected_clue_ids.has(clue_id):
		return
	collected_clue_ids.append(clue_id)
	audio.play_sfx("clue")
	hud.set_clues(collected_clue_ids.size(), 3)
	for definition in CLUE_DEFINITIONS:
		if str(definition["id"]) == clue_id:
			hud.reveal_minimap_position(definition["position"], 2)
			break
	if collected_clue_ids.size() >= 3:
		mission_state = 2
		level.set_exit_active(true)
		hud.set_objective("Entra a la cámara de plata por el portal superior")
		hud.show_message("Las tres memorias encajan • la cámara se ha abierto")
	else:
		hud.set_objective("Recupera %d memorias en el ascenso" % (3 - collected_clue_ids.size()))
		hud.show_message("Memoria recuperada y guardada en tu perfil")
	_save_progress()


func _on_pedestal_selected(selected_order: int) -> void:
	if current_level != 3 or guardians_remaining > 0 or puzzle_step >= 3:
		return
	if selected_order == puzzle_step:
		for pedestal in pedestals:
			if pedestal.order_index == selected_order:
				pedestal.mark_completed()
				break
		puzzle_step += 1
		audio.play_sfx("clue")
		if puzzle_step >= 3:
			_begin_collapse_sequence()
		else:
			hud.set_objective("Ordena las memorias • paso %d de 3" % puzzle_step)
			hud.show_message("El recuerdo encaja en su lugar")
	else:
		puzzle_step = 0
		for pedestal in pedestals:
			pedestal.reset_memory()
		hud.set_objective("Ordena: comunidad, mineros y cerro")
		hud.show_message("El orden no corresponde al relato • inténtalo otra vez")
	if not collapse_in_progress:
		_save_progress()


func _activate_pedestals() -> void:
	for pedestal in pedestals:
		if pedestal.order_index >= puzzle_step:
			pedestal.set_active(true)
	hud.set_objective("Ordena: comunidad, mineros y cerro")
	if puzzle_step == 0:
		hud.show_message("Los guardianes cayeron • reconstruye el relato")


func _on_checkpoint_reached(checkpoint_id: String, _saved_position: Vector2) -> void:
	current_checkpoint = checkpoint_id
	hud.show_message("Checkpoint %s guardado" % checkpoint_id.to_upper().replace("_", " "))
	hud.reveal_minimap_position(_spawn_position(checkpoint_id), 2)
	_save_progress()


func _on_attack_requested(origin: Vector2, direction: Vector2, power: float) -> void:
	if transition_in_progress or game_completed:
		return
	var projectile = RockProjectile.new()
	projectile.position = origin
	projectile.process_mode = Node.PROCESS_MODE_PAUSABLE
	projectile.impacted.connect(_on_projectile_impact)
	world_container.add_child(projectile)
	projectile.launch(direction, power)
	audio.play_sfx("charged_throw" if power >= 0.78 else "throw")


func _on_projectile_impact(world_position: Vector2, hit_enemy: bool, defeated_enemy: bool) -> void:
	if hit_enemy:
		audio.play_sfx("hit")
		_spawn_impact(world_position, Color("f0ca61"), defeated_enemy)
		player.add_camera_shake(7.0 if defeated_enemy else 4.5, 0.16)
	else:
		_spawn_impact(world_position, Color("a99b87"), false)


func _on_shadow_ranged_attack(origin: Vector2, direction: Vector2, projectile_count: int) -> void:
	if transition_in_progress or game_completed or not is_instance_valid(world_container):
		return
	var from_guardian := projectile_count > 1
	for projectile_index in range(projectile_count):
		var projectile = ShadowProjectile.new()
		projectile.position = origin
		projectile.process_mode = Node.PROCESS_MODE_PAUSABLE
		var center_offset := float(projectile_index) - float(projectile_count - 1) / 2.0
		projectile.launch(direction.rotated(center_offset * 0.22), from_guardian)
		projectile.impacted.connect(_on_enemy_projectile_impact)
		world_container.add_child(projectile)
	audio.play_sfx("enemy_shot", -5.0)


func _on_enemy_projectile_impact(world_position: Vector2, hit_player: bool) -> void:
	_spawn_impact(world_position, Color("ef6f7a") if hit_player else Color("b989d1"), hit_player)
	if not hit_player and is_instance_valid(player):
		player.add_camera_shake(1.4, 0.08)


func _on_falling_rock_resolved(world_position: Vector2, hit_player: bool) -> void:
	_spawn_impact(world_position, Color("f38a4c") if hit_player else Color("a7a19b"), hit_player)
	if is_instance_valid(player):
		player.add_camera_shake(8.0 if hit_player else 5.0, 0.24)
	if hit_player:
		audio.play_sfx("rock_hit", -10.0)


func _spawn_impact(world_position: Vector2, color: Color, strong: bool) -> void:
	if not is_instance_valid(world_container):
		return
	var effect = ImpactEffect.new()
	effect.position = world_position
	effect.process_mode = Node.PROCESS_MODE_PAUSABLE
	effect.setup(color, strong)
	world_container.add_child(effect)


func _on_shadow_defeated() -> void:
	audio.play_sfx("shadow_defeat")
	if current_level == 3 and guardians_remaining > 0:
		guardians_remaining -= 1
		if guardians_remaining <= 0:
			_activate_pedestals()
		else:
			hud.show_message("Queda un guardián en la cámara")
	else:
		hud.show_message("Una sombra se dispersó")


func _on_dodge_started() -> void:
	audio.play_sfx("dodge", -4.0)


func _on_player_hurt() -> void:
	audio.play_sfx("player_hurt", -3.0)
	if is_instance_valid(hud):
		hud.flash_damage()


func _on_health_changed(current: int, maximum: int) -> void:
	if is_instance_valid(hud):
		hud.set_health(current, maximum)
	if _progress_ready and current > 0:
		_save_progress()


func _on_player_died() -> void:
	player.respawn(_spawn_position(current_checkpoint))
	hud.show_message("Juan volvió al último checkpoint con la vida restaurada")
	_save_progress()


func _on_exit_reached() -> void:
	if transition_in_progress or game_completed or collapse_in_progress:
		return
	if current_level == 1 and mission_state >= 1:
		_transition_to_level(2)
	elif current_level == 2 and collected_clue_ids.size() >= 3 and mission_state >= 2:
		_transition_to_level(3)
	elif current_level == 3 and puzzle_step >= 3:
		_complete_game()


func _transition_to_level(next_level: int) -> void:
	transition_in_progress = true
	player.set_input_enabled(false)
	current_level = next_level
	current_checkpoint = str(LEVEL_START_CHECKPOINTS[next_level])
	player.global_position = _spawn_position(current_checkpoint)
	_save_progress()
	audio.play_sfx("confirm")
	await get_tree().create_timer(0.55, true, false, true).timeout
	_enter_level(next_level, current_checkpoint, true)
	player.set_input_enabled(true)
	transition_in_progress = false
	_save_progress()


func _complete_game() -> void:
	game_completed = true
	mission_state = 3
	current_checkpoint = "camara_final"
	player.set_input_enabled(false)
	audio.set_finale_active(false)
	hud.set_objective("Kallami restaurado")
	hud.show_game_complete()
	audio.play_sfx("clue", -1.0)
	_save_progress()


func _begin_collapse_sequence() -> void:
	if collapse_in_progress:
		return
	collapse_in_progress = true
	hud.set_profile_switch_enabled(false)
	level.set_exit_active(false)
	hud.set_objective("¡El cerro tiembla! Esquiva las rocas y resiste")
	hud.show_message("Un rugido sacude la cámara • ¡muévete!")
	audio.set_finale_active(true)
	audio.play_sfx("quake", -2.0)
	_run_collapse_sequence()


func _run_collapse_sequence() -> void:
	for wave_index in range(3):
		if current_level != 3 or game_completed:
			collapse_in_progress = false
			hud.set_profile_switch_enabled(true)
			audio.set_finale_active(false)
			return
		player.add_camera_shake(5.0 + float(wave_index) * 2.0, 0.55)
		for rock_index in range(2):
			var offset := Vector2(
				_collapse_rng.randf_range(-215.0, 215.0),
				_collapse_rng.randf_range(-155.0, 155.0)
			)
			var target := Vector2(
				clampf(player.global_position.x + offset.x, 170.0, WORLD_SIZE.x - 170.0),
				clampf(player.global_position.y + offset.y, 160.0, WORLD_SIZE.y - 160.0)
			)
			var falling_rock = FallingRock.new()
			falling_rock.position = target
			falling_rock.process_mode = Node.PROCESS_MODE_PAUSABLE
			falling_rock.setup(player)
			falling_rock.resolved.connect(_on_falling_rock_resolved)
			world_container.add_child(falling_rock)
			await get_tree().create_timer(0.48, false, false, false).timeout
		await get_tree().create_timer(1.35, false, false, false).timeout
	if current_level == 3 and puzzle_step >= 3 and not game_completed:
		collapse_in_progress = false
		hud.set_profile_switch_enabled(true)
		level.set_exit_active(true)
		hud.set_objective("Corre al altar de plata antes de que cierre la cámara")
		hud.show_message("¡El derrumbe abrió el paso! Corre al altar")
		_save_progress()
		if player.global_position.distance_to(LEVEL_EXIT_POSITIONS[3]) <= 78.0:
			_complete_game()


func _on_progress_loaded(data: Dictionary) -> void:
	_progress_ready = false
	collected_clue_ids.clear()
	for clue_id in data.get("clue_ids", []):
		var normalized := str(clue_id)
		if not collected_clue_ids.has(normalized):
			collected_clue_ids.append(normalized)
	current_level = clampi(int(data.get("level", 1)), 1, 3)
	current_checkpoint = str(data.get("checkpoint_id", LEVEL_START_CHECKPOINTS[current_level]))
	mission_state = clampi(int(data.get("mission_state", 0)), 0, 3)
	puzzle_step = clampi(int(data.get("puzzle_step", 0)), 0, 3)
	game_completed = bool(data.get("completed", false))
	# Las partidas terminadas con la versión de un solo mapa se muestran en el
	# desenlace nuevo y pueden reiniciarse con N sin quedar bloqueadas.
	if game_completed and current_level < 3:
		current_level = 3
		current_checkpoint = "camara_final"
		mission_state = 3
		puzzle_step = 3
	_enter_level(current_level, current_checkpoint, false)
	var fallback_position: Vector2 = _spawn_position(current_checkpoint)
	player.global_position = Vector2(
		clampf(float(data.get("position_x", fallback_position.x)), 28.0, WORLD_SIZE.x - 28.0),
		clampf(float(data.get("position_y", fallback_position.y)), 28.0, WORLD_SIZE.y - 28.0)
	)
	player.restore_health(int(data.get("health", 5)))
	hud.set_clues(collected_clue_ids.size(), 3)
	hud.reveal_minimap_position(player.global_position, 2)
	_apply_level_state()
	if not game_completed:
		_on_game_started()
	_progress_ready = true
	_last_requested_signature = _progress_signature()
	hud.show_message("Nivel %d restaurado para %s" % [current_level, GameManager.profile_name])


func _restore_checkpoints() -> void:
	var orders := {
		1: {"inicio": 0, "plaza": 1, "cerro": 2},
		2: {"ascenso_inicio": 0, "ascenso_medio": 1},
		3: {"camara_inicio": 0, "camara_final": 1}
	}
	var level_order: Dictionary = orders[current_level]
	var current_order: int = int(level_order.get(current_checkpoint, 0))
	for checkpoint in checkpoints:
		checkpoint.activated = int(level_order.get(checkpoint.checkpoint_id, 99)) <= current_order
		checkpoint.queue_redraw()


func _restore_clues() -> void:
	for clue in clues:
		if collected_clue_ids.has(clue.clue_id):
			clue.mark_collected()
			for definition in CLUE_DEFINITIONS:
				if str(definition["id"]) == clue.clue_id:
					hud.reveal_minimap_position(definition["position"], 1)
					break
		else:
			clue.activate()


func _restore_pedestals() -> void:
	for pedestal in pedestals:
		if pedestal.order_index < puzzle_step:
			pedestal.mark_completed()
		elif guardians_remaining <= 0:
			pedestal.set_active(true)


func _on_progress_saved(_data: Dictionary) -> void:
	_last_requested_signature = _progress_signature()


func _save_progress() -> void:
	if not _progress_ready or collapse_in_progress or not is_instance_valid(player):
		return
	_last_requested_signature = _progress_signature()
	GameManager.save_progress({
		"level": current_level,
		"clues": collected_clue_ids.size(),
		"clue_ids": collected_clue_ids.duplicate(),
		"checkpoint_id": current_checkpoint,
		"completed": game_completed,
		"health": maxi(1, player.health),
		"position_x": clampf(player.global_position.x, 28.0, WORLD_SIZE.x - 28.0),
		"position_y": clampf(player.global_position.y, 28.0, WORLD_SIZE.y - 28.0),
		"mission_state": mission_state,
		"puzzle_step": puzzle_step
	})


func _setup_autosave() -> void:
	autosave_timer = Timer.new()
	autosave_timer.name = "AutoguardadoSeguro"
	autosave_timer.wait_time = AUTOSAVE_SECONDS
	autosave_timer.one_shot = false
	autosave_timer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(autosave_timer)
	autosave_timer.timeout.connect(_autosave_if_changed)
	autosave_timer.start()


func _autosave_if_changed() -> void:
	if not _progress_ready or get_tree().paused or hud.is_title_visible() or transition_in_progress or collapse_in_progress:
		return
	if _progress_signature() != _last_requested_signature:
		_save_progress()


func _progress_signature() -> String:
	if not is_instance_valid(player):
		return ""
	return "%d|%d|%s|%s|%d|%d|%d|%d|%s" % [
		current_level, mission_state, ",".join(collected_clue_ids), current_checkpoint,
		puzzle_step, player.health, int(round(player.global_position.x)),
		int(round(player.global_position.y)), str(game_completed)
	]


func _spawn_position(checkpoint_id: String) -> Vector2:
	var level_spawns: Dictionary = LEVEL_SPAWNS[current_level]
	var fallback_id := str(LEVEL_START_CHECKPOINTS[current_level])
	var fallback: Vector2 = level_spawns.get(fallback_id, Vector2(220, 1260))
	var result: Vector2 = level_spawns.get(checkpoint_id, fallback)
	return result


func _mark_input_handled() -> void:
	var viewport := get_viewport()
	if viewport != null:
		viewport.set_input_as_handled()


func _toggle_fullscreen() -> void:
	if _is_fullscreen():
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		DisplayServer.window_set_size(WINDOWED_SIZE)
		var screen_size: Vector2i = DisplayServer.screen_get_size()
		var centered_position := Vector2i(
			maxi(0, int((screen_size.x - WINDOWED_SIZE.x) / 2.0)),
			maxi(0, int((screen_size.y - WINDOWED_SIZE.y) / 2.0))
		)
		DisplayServer.window_set_position(centered_position)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	call_deferred("_refresh_fullscreen_state")


func _refresh_fullscreen_state() -> void:
	var is_fullscreen := _is_fullscreen()
	hud.set_fullscreen_state(is_fullscreen)
	if not hud.is_title_visible():
		hud.show_message("Pantalla completa activada • F11 para volver" if is_fullscreen else "Modo ventana activado • F11 para ampliar")


func _is_fullscreen() -> bool:
	var mode: int = DisplayServer.window_get_mode()
	return mode == DisplayServer.WINDOW_MODE_FULLSCREEN or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN


func _ensure_input_actions() -> void:
	_add_action("mover_arriba", [KEY_W, KEY_UP])
	_add_action("mover_abajo", [KEY_S, KEY_DOWN])
	_add_action("mover_izquierda", [KEY_A, KEY_LEFT])
	_add_action("mover_derecha", [KEY_D, KEY_RIGHT])
	_add_action("interactuar", [KEY_E])
	_add_action("atacar", [KEY_F])
	_add_action("confirmar", [KEY_SPACE, KEY_ENTER])
	_add_action("pausa", [KEY_ESCAPE])
	_add_action("nueva_partida", [KEY_N])
	_add_action("guardar", [KEY_G])
	_add_action("pantalla_completa", [KEY_F11])
	_add_action("esquivar", [KEY_SPACE])


func _add_action(action: StringName, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	if not InputMap.action_get_events(action).is_empty():
		return
	for keycode in keys:
		var event := InputEventKey.new()
		event.physical_keycode = keycode
		InputMap.action_add_event(action, event)
