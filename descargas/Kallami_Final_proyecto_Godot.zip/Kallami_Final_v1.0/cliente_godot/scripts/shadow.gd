extends CharacterBody2D

signal defeated
signal ranged_attack_requested(origin: Vector2, direction: Vector2, projectile_count: int)

@export var patrol_distance := 110.0
@export var patrol_speed := 52.0
@export var chase_speed := 86.0
@export var detection_radius := 285.0

var target: Node2D
var state := "patrol"
var enemy_type := "hunter"
var health := 3
var max_health := 3
var _origin := Vector2.ZERO
var _patrol_direction := 1.0
var _damage_cooldown := 0.0
var _hit_flash := 0.0
var _float_phase := 0.0
var _ranged_cooldown := 0.85
var _windup := 0.0
var _queued_projectiles := 1
var _strafe_direction := 1.0


func configure(kind: String) -> void:
	enemy_type = kind
	match enemy_type:
		"shooter":
			max_health = 2
			health = max_health
			chase_speed = 72.0
			detection_radius = maxf(detection_radius, 350.0)
		"guardian":
			max_health = 6
			health = max_health
			chase_speed = 94.0
			patrol_distance = 175.0
			scale = Vector2(1.22, 1.22)
		_:
			enemy_type = "hunter"
			max_health = 3
			health = max_health


func _ready() -> void:
	name = "Sombra"
	z_index = 14
	_origin = global_position
	collision_layer = 4
	collision_mask = 1
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 23.0 if enemy_type == "guardian" else 20.0
	collision.shape = shape
	add_child(collision)
	queue_redraw()


func _physics_process(delta: float) -> void:
	_damage_cooldown = maxf(0.0, _damage_cooldown - delta)
	_hit_flash = maxf(0.0, _hit_flash - delta)
	_ranged_cooldown = maxf(0.0, _ranged_cooldown - delta)
	_float_phase += delta * 3.2
	if not is_instance_valid(target):
		velocity = Vector2.ZERO
		return
	var distance := global_position.distance_to(target.global_position)
	match enemy_type:
		"shooter":
			_update_shooter(delta, distance)
		"guardian":
			_update_guardian(delta, distance)
		_:
			_update_hunter(distance)
	move_and_slide()
	if is_on_wall():
		_strafe_direction *= -1.0
		_patrol_direction *= -1.0
	var contact_distance := 46.0 if enemy_type == "guardian" else 38.0
	if distance < contact_distance and _damage_cooldown <= 0.0 and target.has_method("receive_damage"):
		target.receive_damage(1)
		_damage_cooldown = 1.15
	queue_redraw()


func _update_hunter(distance: float) -> void:
	if distance <= detection_radius:
		state = "chase"
		velocity = global_position.direction_to(target.global_position) * chase_speed
	else:
		_patrol()


func _update_shooter(delta: float, distance: float) -> void:
	if _update_windup(delta, 2.35):
		return
	if distance > detection_radius:
		_patrol()
		return
	state = "chase"
	if _ranged_cooldown <= 0.0 and distance <= 430.0:
		_start_windup(1, 0.52)
		return
	if distance < 155.0:
		velocity = target.global_position.direction_to(global_position) * chase_speed
	elif distance > 285.0:
		velocity = global_position.direction_to(target.global_position) * chase_speed
	else:
		var toward := global_position.direction_to(target.global_position)
		velocity = toward.orthogonal() * _strafe_direction * patrol_speed


func _update_guardian(delta: float, distance: float) -> void:
	if _update_windup(delta, 3.10):
		return
	if distance > detection_radius:
		_patrol()
		return
	state = "chase"
	if _ranged_cooldown <= 0.0 and distance <= 390.0:
		_start_windup(3, 0.70)
		return
	velocity = global_position.direction_to(target.global_position) * chase_speed


func _start_windup(projectile_count: int, duration: float) -> void:
	state = "aim"
	velocity = Vector2.ZERO
	_queued_projectiles = projectile_count
	_windup = duration


func _update_windup(delta: float, next_cooldown: float) -> bool:
	if _windup <= 0.0:
		return false
	state = "aim"
	velocity = Vector2.ZERO
	_windup = maxf(0.0, _windup - delta)
	if _windup <= 0.0 and is_instance_valid(target):
		var shot_direction := global_position.direction_to(target.global_position)
		ranged_attack_requested.emit(global_position + shot_direction * 25.0, shot_direction, _queued_projectiles)
		_ranged_cooldown = next_cooldown
	return true


func _patrol() -> void:
	state = "patrol"
	if absf(global_position.x - _origin.x) >= patrol_distance:
		_patrol_direction *= -1.0
	velocity = Vector2(_patrol_direction * patrol_speed, sin(_float_phase) * 9.0)


func take_projectile_hit(direction: Vector2, damage: int = 1) -> bool:
	health -= maxi(1, damage)
	_hit_flash = 0.18
	if health <= 0:
		defeated.emit()
		queue_free()
		return true
	global_position += direction.normalized() * (38.0 + float(damage) * 10.0)
	queue_redraw()
	return false


func _draw() -> void:
	var lift := sin(_float_phase) * 3.0
	var body_color := Color("202437")
	var eye_color := Color("bcecff")
	if enemy_type == "shooter":
		body_color = Color("38244d")
		eye_color = Color("e1a7ff")
	elif enemy_type == "guardian":
		body_color = Color("26374b")
		eye_color = Color("ffd56f")
	if _hit_flash > 0.0:
		body_color = Color("8498ad")
	draw_circle(Vector2(0, 18), 24, Color(0.02, 0.025, 0.06, 0.34))
	draw_circle(Vector2(0, lift), 22, body_color)
	draw_circle(Vector2(-11, -9 + lift), 12, body_color.lightened(0.08))
	draw_circle(Vector2(11, -9 + lift), 12, body_color.lightened(0.08))
	draw_colored_polygon(PackedVector2Array([Vector2(-18, 10 + lift), Vector2(-12, 34 + lift), Vector2(-4, 24 + lift), Vector2(3, 37 + lift), Vector2(10, 23 + lift), Vector2(19, 10 + lift)]), body_color)
	draw_circle(Vector2(-6, -5 + lift), 3.0, eye_color)
	draw_circle(Vector2(6, -5 + lift), 3.0, eye_color)
	if state == "chase":
		draw_arc(Vector2(0, lift), 31, 0, TAU, 24, Color(eye_color.r, eye_color.g, eye_color.b, 0.50), 2.5)
		draw_arc(Vector2(0, lift), 38, 0, TAU, 24, Color(eye_color.r, eye_color.g, eye_color.b, 0.20), 2.0)
	if state == "aim":
		var aim_progress := clampf(1.0 - _windup / (0.70 if enemy_type == "guardian" else 0.52), 0.0, 1.0)
		draw_arc(Vector2(0, lift), 36, -PI / 2.0, -PI / 2.0 + TAU * aim_progress, 28, Color("ef6f7a"), 4.0)
		draw_line(Vector2.ZERO, global_position.direction_to(target.global_position) * 34.0, Color(1.0, 0.28, 0.36, 0.65), 2.0)
	if enemy_type == "shooter":
		draw_arc(Vector2(0, lift), 28, PI * 0.15, PI * 0.85, 12, Color(0.85, 0.53, 1.0, 0.55), 2.0)
	elif enemy_type == "guardian":
		draw_arc(Vector2(0, lift), 33, 0, TAU, 28, Color(1.0, 0.76, 0.30, 0.55), 3.0)
		draw_arc(Vector2(0, lift), 41, 0, TAU, 28, Color(0.48, 0.75, 1.0, 0.24), 2.0)
	if state != "patrol" or _hit_flash > 0.0:
		var health_ratio := clampf(float(health) / float(max_health), 0.0, 1.0)
		draw_rect(Rect2(-24, -43 + lift, 48, 6), Color(0.03, 0.025, 0.05, 0.88))
		draw_rect(Rect2(-22, -41 + lift, 44 * health_ratio, 2), Color("cf5b65") if health_ratio <= 0.45 else Color("74bad1"))
