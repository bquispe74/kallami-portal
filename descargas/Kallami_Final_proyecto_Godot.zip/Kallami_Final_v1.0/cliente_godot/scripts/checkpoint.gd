extends Area2D

signal reached(checkpoint_id: String, spawn_position: Vector2)

@export var checkpoint_id := "plaza"
var activated := false


func _ready() -> void:
	name = "Checkpoint"
	z_index = 8
	scale = Vector2(1.15, 1.15)
	collision_layer = 8
	collision_mask = 1
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 34.0
	collision.shape = shape
	add_child(collision)
	body_entered.connect(_on_body_entered)
	queue_redraw()


func _on_body_entered(body: Node2D) -> void:
	if activated or body.name != "Juan":
		return
	activated = true
	queue_redraw()
	reached.emit(checkpoint_id, global_position)


func _draw() -> void:
	var color := Color("77b27b") if activated else Color("4d7894")
	draw_circle(Vector2.ZERO, 18, Color(color.r, color.g, color.b, 0.25))
	draw_line(Vector2(0, 18), Vector2(0, -24), Color("4d392d"), 4)
	draw_colored_polygon(PackedVector2Array([
		Vector2(2, -22), Vector2(22, -14), Vector2(2, -6)
	]), color)
