extends Area2D

signal impacted(world_position: Vector2, hit_enemy: bool, defeated_enemy: bool)

@export var speed := 560.0
@export var maximum_distance := 390.0

var direction := Vector2.RIGHT
var _start_position := Vector2.ZERO
var _spin := 0.0
var _life := 0.0
var _finished := false
var _power := 0.0
var _damage := 1


func _ready() -> void:
	name = "PiedraDeHonda"
	z_index = 30
	_start_position = global_position
	collision_layer = 16
	collision_mask = 1 | 4
	monitoring = true
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 9.0
	collision.shape = shape
	add_child(collision)
	body_entered.connect(_on_body_entered)
	queue_redraw()


func launch(new_direction: Vector2, power: float = 0.0) -> void:
	direction = new_direction.normalized()
	_power = clampf(power, 0.0, 1.0)
	_damage = 2 if _power >= 0.78 else 1
	speed = lerpf(540.0, 760.0, _power)
	maximum_distance = lerpf(380.0, 620.0, _power)


func _physics_process(delta: float) -> void:
	if _finished:
		return
	position += direction * speed * delta
	_spin += delta * 15.0
	_life += delta
	queue_redraw()
	if global_position.distance_to(_start_position) >= maximum_distance:
		_finish(false, false)


func _on_body_entered(body: Node2D) -> void:
	if _finished or body.name == "Juan":
		return
	if body.has_method("take_projectile_hit"):
		var defeated: bool = bool(body.take_projectile_hit(direction, _damage))
		_finish(true, defeated)
	else:
		_finish(false, false)


func _finish(hit_enemy: bool, defeated_enemy: bool) -> void:
	if _finished:
		return
	_finished = true
	set_deferred("monitoring", false)
	impacted.emit(global_position, hit_enemy, defeated_enemy)
	queue_free()


func _draw() -> void:
	var pulse := 1.0 + 0.12 * sin(_life * 18.0)
	var trail_count := 3 + int(round(_power * 2.0))
	for ring_index in range(trail_count):
		var ring_offset := fmod(_life * 150.0 + float(ring_index) * 22.0, 66.0)
		var ring_center := -direction * (12.0 + ring_offset)
		var alpha := (0.48 + _power * 0.25) * (1.0 - ring_offset / 66.0)
		var wave_angle := direction.angle()
		draw_arc(ring_center, 9.0 + ring_offset * 0.10 + _power * 3.0, wave_angle - 1.25, wave_angle + 1.25, 12, Color(0.96, 0.78, 0.30, alpha), 2.4 + _power * 1.6)
	draw_circle(Vector2.ZERO, (11.0 + _power * 4.0) * pulse, Color(0.10, 0.07, 0.05, 0.42))
	var stone := PackedVector2Array([Vector2(cos(_spin) * 8.0, sin(_spin) * 6.0), Vector2(cos(_spin + 2.1) * 9.0, sin(_spin + 2.1) * 7.0), Vector2(cos(_spin + 4.2) * 8.0, sin(_spin + 4.2) * 6.0)])
	draw_colored_polygon(stone, Color("d2a84e").lerp(Color("fff1b5"), _power))
	draw_circle(Vector2(-2, -2), 2.4 + _power * 1.2, Color("fff4ca"))
