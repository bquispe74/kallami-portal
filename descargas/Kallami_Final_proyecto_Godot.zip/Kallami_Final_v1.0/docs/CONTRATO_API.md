# Contrato de comunicación cliente-servidor 1.1

## Base técnica

- URL local: `http://127.0.0.1:8000`.
- Transporte: HTTP para demostración local.
- Formato: JSON UTF-8.
- Autorización de progreso: `Authorization: Bearer <token>`.
- Persistencia: SQLite parametrizado.

## Endpoints

| Método y ruta | Función | Autorización |
|---|---|---|
| `GET /api/estado` | Salud y versión del servicio | No |
| `GET /api/perfiles` | Lista perfiles sin exponer hashes | No |
| `POST /api/perfiles` | Crea perfil, partida y sesión | No |
| `POST /api/perfiles/login` | Verifica PIN y rota token | No |
| `POST /api/perfiles/{id}/eliminar` | Elimina perfil y progreso | PIN en cuerpo |
| `GET /api/progreso/{id}` | Recupera una partida | Token del mismo perfil |
| `POST /api/progreso` | Valida y guarda avance | Token del mismo perfil |
| `POST /api/progreso/{id}/reiniciar` | Reinicia solo esa partida | Token del mismo perfil |

## Crear perfil

```http
POST /api/perfiles
Content-Type: application/json

{"display_name":"DemoInicio","pin":"2661"}
```

Respuesta `201`:

```json
{
  "profile": {
    "profile_id": "demoinicio-a1b2c3d4",
    "display_name": "DemoInicio",
    "created_at": "2026-09-28T12:00:00+00:00",
    "updated_at": "2026-09-28T12:00:00+00:00"
  },
  "access_token": "token-aleatorio",
  "token_type": "bearer"
}
```

## Guardar progreso

```http
POST /api/progreso
Authorization: Bearer token-aleatorio
Content-Type: application/json

{
  "player_id": "demoinicio-a1b2c3d4",
  "level": 2,
  "clues": 1,
  "clue_ids": ["pista_comunidad"],
  "checkpoint_id": "ascenso_medio",
  "completed": false,
  "health": 3,
  "position_x": 1050.0,
  "position_y": 835.0,
  "mission_state": 1,
  "puzzle_step": 0
}
```

El servidor comprueba que el token pertenezca al `player_id`, que la lista no contenga duplicados, que el contador coincida, que solo se agregue una memoria por transición y que nivel, misión, checkpoint, rompecabezas y final sean coherentes. Las pistas solo pueden registrarse desde el Nivel 2; `puzzle_step` solo puede avanzar en la cámara del Nivel 3.

## Respuestas de seguridad

| Código | Motivo típico |
|---|---|
| `401` | Falta sesión o el PIN es incorrecto |
| `403` | El token pertenece a otro perfil |
| `404` | Perfil o progreso inexistente |
| `409` | Salto o retroceso de progreso |
| `422` | Formato, límite o regla de juego inválida |

## Estrategia de guardado

Godot guarda al cambiar de nivel, recoger una memoria, recibir daño, activar un checkpoint, ordenar un pedestal o completar el altar. También compara el estado cada 2,5 segundos y permite guardado manual con `G`. Si hay una petición activa, conserva una actualización pendiente y la envía al terminar la anterior.
