extends Node2D

signal exit_reached

const WORLD_SIZE := Vector2(2400, 1500)
const EXIT_POSITION := Vector2(2200, 205)
const CLUE_POSITIONS: Array[Vector2] = [
	Vector2(650, 1155),
	Vector2(1375, 760),
	Vector2(1990, 430)
]

var exit_active := false
var _rock_walls: Array[Rect2] = [
	Rect2(300, 1030, 210, 150), Rect2(820, 1110, 260, 170),
	Rect2(1160, 980, 220, 175), Rect2(1550, 1120, 320, 170),
	Rect2(1880, 1020, 310, 190), Rect2(160, 650, 310, 190),
	Rect2(600, 690, 260, 175), Rect2(1030, 545, 250, 170),
	Rect2(1480, 520, 260, 175), Rect2(2050, 610, 250, 180),
	Rect2(380, 185, 330, 170), Rect2(930, 170, 320, 160),
	Rect2(1510, 130, 290, 155)
]


func _ready() -> void:
	name = "AscensoKallami"
	z_index = -20
	_build_collision()
	_build_exit()
	queue_redraw()


func set_exit_active(value: bool) -> void:
	exit_active = value
	queue_redraw()


func _build_collision() -> void:
	_add_wall(Rect2(0, 0, 2400, 28))
	_add_wall(Rect2(0, 1472, 2400, 28))
	_add_wall(Rect2(0, 0, 28, 1500))
	_add_wall(Rect2(2372, 0, 28, 1500))
	for rock_wall in _rock_walls:
		_add_wall(rock_wall)


func _add_wall(rect: Rect2) -> void:
	var body := StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = rect.get_center()
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	body.add_child(collision)
	add_child(body)


func _build_exit() -> void:
	var area := Area2D.new()
	area.name = "PasoCamaraPlata"
	area.position = EXIT_POSITION
	area.collision_layer = 8
	area.collision_mask = 1
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 52.0
	collision.shape = shape
	area.add_child(collision)
	add_child(area)
	area.body_entered.connect(func(body: Node2D) -> void:
		if exit_active and body.name == "Juan":
			exit_reached.emit()
	)


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("171c25"))
	draw_rect(Rect2(28, 28, 2344, 1444), Color("303a49"))
	_draw_cliffs()
	_draw_path()
	_draw_bridge()
	_draw_mist()
	_draw_cairns()
	for clue_index in range(CLUE_POSITIONS.size()):
		_draw_shrine(CLUE_POSITIONS[clue_index], clue_index)
	_draw_cave_entrance()
	_draw_exit()


func _draw_cliffs() -> void:
	for rock_wall in _rock_walls:
		draw_rect(Rect2(rock_wall.position + Vector2(12, 18), rock_wall.size), Color(0.03, 0.04, 0.06, 0.34))
		draw_rect(rock_wall, Color("202a37"))
		draw_colored_polygon(PackedVector2Array([
			rock_wall.position,
			rock_wall.position + Vector2(rock_wall.size.x * 0.42, -22),
			rock_wall.position + Vector2(rock_wall.size.x, 8),
			rock_wall.position + Vector2(rock_wall.size.x, rock_wall.size.y),
			rock_wall.position + Vector2(0, rock_wall.size.y)
		]), Color("354253"))
		for stripe_x in range(int(rock_wall.position.x + 22), int(rock_wall.end.x - 8), 45):
			draw_line(Vector2(stripe_x, rock_wall.position.y + 16), Vector2(stripe_x - 18, rock_wall.end.y - 12), Color(0.09, 0.13, 0.19, 0.74), 5)


func _draw_path() -> void:
	var trail := PackedVector2Array([
		Vector2(190, 1320), Vector2(520, 1320), Vector2(650, 1155),
		Vector2(780, 930), Vector2(1080, 850), Vector2(1375, 760),
		Vector2(1500, 875), Vector2(1770, 790), Vector2(1990, 430),
		Vector2(2130, 315), Vector2(2200, 205)
	])
	draw_polyline(trail, Color("171f2b"), 136.0, true)
	draw_polyline(trail, Color("586576"), 112.0, true)
	draw_polyline(trail, Color("a8b6c8"), 5.0, true)
	for index in range(trail.size() - 1):
		var midpoint: Vector2 = trail[index].lerp(trail[index + 1], 0.5)
		draw_circle(midpoint + Vector2(17, 5), 7, Color("303b4b"))


func _draw_bridge() -> void:
	var bridge := Rect2(1040, 796, 310, 92)
	draw_rect(Rect2(bridge.position + Vector2(0, 13), bridge.size), Color(0.04, 0.04, 0.05, 0.50))
	for plank_x in range(int(bridge.position.x), int(bridge.end.x), 28):
		draw_rect(Rect2(plank_x, bridge.position.y, 22, bridge.size.y), Color("6d4930"))
		draw_line(Vector2(plank_x, bridge.position.y + 7), Vector2(plank_x + 20, bridge.position.y + 7), Color("aa7a48"), 3)
	draw_line(bridge.position + Vector2(0, 4), Vector2(bridge.end.x, bridge.position.y + 4), Color("2c231e"), 6)
	draw_line(Vector2(bridge.position.x, bridge.end.y - 4), bridge.end - Vector2(0, 4), Color("2c231e"), 6)


func _draw_mist() -> void:
	for mist_index in range(12):
		var center := Vector2(160 + mist_index * 196, 420 + int(75.0 * sin(float(mist_index) * 1.7)))
		draw_circle(center, 86, Color(0.70, 0.76, 0.82, 0.055))
		draw_circle(center + Vector2(70, 8), 65, Color(0.70, 0.76, 0.82, 0.04))


func _draw_cairns() -> void:
	var cairns: Array[Vector2] = [
		Vector2(465, 1245), Vector2(810, 905), Vector2(1390, 850),
		Vector2(1760, 705), Vector2(2090, 350)
	]
	for center in cairns:
		draw_circle(center + Vector2(0, 10), 19, Color("30343a"))
		draw_circle(center, 14, Color("525860"))
		draw_circle(center + Vector2(0, -13), 9, Color("737880"))


func _draw_shrine(center: Vector2, clue_index: int) -> void:
	var colors: Array[Color] = [Color("78b6c9"), Color("d4ad58"), Color("aa8bd1")]
	var accent: Color = colors[clue_index]
	draw_circle(center + Vector2(0, 14), 46, Color(0.02, 0.03, 0.05, 0.42))
	draw_rect(Rect2(center + Vector2(-31, 12), Vector2(62, 17)), Color("343941"))
	draw_rect(Rect2(center + Vector2(-22, -4), Vector2(44, 17)), Color("59616a"))
	draw_arc(center + Vector2(0, -5), 31, PI, TAU, 20, accent, 4)


func _draw_cave_entrance() -> void:
	var outer_mouth := PackedVector2Array([
		Vector2(2015, 366), Vector2(2024, 244), Vector2(2050, 166),
		Vector2(2107, 103), Vector2(2182, 70), Vector2(2245, 78),
		Vector2(2314, 132), Vector2(2360, 222), Vector2(2370, 366)
	])
	draw_colored_polygon(outer_mouth, Color("151d2a"))
	var inner_mouth := PackedVector2Array([
		Vector2(2054, 365), Vector2(2060, 254), Vector2(2088, 184),
		Vector2(2135, 135), Vector2(2192, 111), Vector2(2241, 120),
		Vector2(2293, 165), Vector2(2323, 238), Vector2(2332, 365)
	])
	draw_colored_polygon(inner_mouth, Color("070b12"))
	for stalactite in [Vector2(2112, 135), Vector2(2165, 116), Vector2(2278, 150), Vector2(2310, 199)]:
		draw_colored_polygon(PackedVector2Array([
			stalactite, stalactite + Vector2(20, 0), stalactite + Vector2(12, 31), stalactite + Vector2(8, 39)
		]), Color("303b4a"))
	for crystal in [Vector2(2086, 310), Vector2(2310, 326)]:
		draw_circle(crystal, 33, Color(0.30, 0.69, 0.91, 0.10))
		draw_colored_polygon(PackedVector2Array([
			crystal + Vector2(-9, 22), crystal + Vector2(-5, -10),
			crystal + Vector2(2, -35), crystal + Vector2(10, 3), crystal + Vector2(14, 22)
		]), Color("75bdd4"))
		draw_line(crystal + Vector2(1, -23), crystal + Vector2(4, 14), Color("d2f6ff"), 3)


func _draw_exit() -> void:
	var color := Color("f1ce68") if exit_active else Color("4e535b")
	draw_colored_polygon(PackedVector2Array([
		EXIT_POSITION + Vector2(-72, 55), EXIT_POSITION + Vector2(-52, -58),
		EXIT_POSITION + Vector2(0, -92), EXIT_POSITION + Vector2(52, -58),
		EXIT_POSITION + Vector2(72, 55)
	]), Color("242a31"))
	draw_arc(EXIT_POSITION, 54, 0, TAU, 40, color, 7)
	draw_arc(EXIT_POSITION, 38, 0, TAU, 40, Color(color.r, color.g, color.b, 0.42), 4)
	if exit_active:
		for ray_index in range(10):
			var angle := TAU * float(ray_index) / 10.0
			draw_line(EXIT_POSITION + Vector2.from_angle(angle) * 62, EXIT_POSITION + Vector2.from_angle(angle) * 82, color, 3)
