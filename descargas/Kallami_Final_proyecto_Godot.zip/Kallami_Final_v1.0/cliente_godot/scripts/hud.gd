extends CanvasLayer

signal dialogue_finished
signal new_game_requested
signal profile_switch_requested
signal fullscreen_requested
signal profile_create_requested(display_name: String, pin: String)
signal profile_login_requested(profile_id: String, pin: String)
signal profile_delete_requested(profile_id: String, pin: String)

const Minimap = preload("res://scripts/minimap.gd")
const LEVEL_PREVIEW = preload("res://assets/referencias/nivel_1_comunidad.png")
const FLORENCIO_TALK = preload("res://assets/dialogue/florencio_talk.png")
const DIALOGUE_BLIP = preload("res://assets/audio/dialogue_blip.wav")

var objective_label: Label
var level_label: Label
var health_label: Label
var health_fill: ColorRect
var clues_label: Label
var dodge_fill: ColorRect
var charge_fill: ColorRect
var dodge_label: Label
var charge_label: Label
var server_label: Label
var profile_badge: Label
var message_label: Label
var interaction_panel: ColorRect
var interaction_label: Label
var dialogue_panel: ColorRect
var speaker_label: Label
var dialogue_label: Label
var portrait: TextureRect
var pause_panel: ColorRect
var complete_panel: ColorRect
var pause_fullscreen_button: Button
var pause_profile_button: Button
var complete_profile_button: Button
var title_fullscreen_button: Button
var title_panel: ColorRect
var level_card_panel: ColorRect
var level_card_title: Label
var level_card_subtitle: Label
var damage_overlay: ColorRect
var minimap

var profile_list: ItemList
var profile_name_input: LineEdit
var profile_pin_input: LineEdit
var profile_status_label: Label
var create_profile_button: Button
var login_profile_button: Button
var delete_profile_button: Button

var _dialogue_lines: Array = []
var _dialogue_voices: Array = []
var _dialogue_index := 0
var _full_dialogue_line := ""
var _visible_characters := 0.0
var _mouth_elapsed := 0.0
var _mouth_open := false
var _blip_player: AudioStreamPlayer
var _voice_player: AudioStreamPlayer
var _level_card_serial := 0
var _damage_flash_serial := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_interface()
	_blip_player = AudioStreamPlayer.new()
	_blip_player.stream = DIALOGUE_BLIP
	_blip_player.volume_db = -12.0
	add_child(_blip_player)
	_voice_player = AudioStreamPlayer.new()
	_voice_player.name = "VozDialogo"
	_voice_player.volume_db = -4.5
	add_child(_voice_player)


func _process(delta: float) -> void:
	if get_tree().paused:
		return
	if not dialogue_panel.visible:
		return
	if dialogue_label.visible_characters < _full_dialogue_line.length():
		var previous := dialogue_label.visible_characters
		_visible_characters = minf(float(_full_dialogue_line.length()), _visible_characters + delta * 38.0)
		dialogue_label.visible_characters = int(_visible_characters)
		_mouth_elapsed += delta
		if _mouth_elapsed >= 0.12:
			_mouth_elapsed = 0.0
			_mouth_open = not _mouth_open
			_set_portrait_frame(1 if _mouth_open else 0)
		if dialogue_label.visible_characters > previous and dialogue_label.visible_characters % 4 == 0 and not _blip_player.playing and not _voice_player.playing:
			_blip_player.play()
	else:
		if _voice_player.playing:
			_mouth_elapsed += delta
			if _mouth_elapsed >= 0.12:
				_mouth_elapsed = 0.0
				_mouth_open = not _mouth_open
				_set_portrait_frame(1 if _mouth_open else 0)
		else:
			_mouth_open = false
			_set_portrait_frame(0)


func set_level(level_number: int, title: String) -> void:
	level_label.text = "NIVEL %d/3  •  %s" % [level_number, title.to_upper()]


func set_objective(text: String) -> void:
	objective_label.text = "OBJETIVO  •  %s" % text


func set_health(current: int, maximum: int) -> void:
	health_label.text = "VIDA  %s/%s" % [current, maximum]
	var ratio := clampf(float(current) / float(maximum), 0.0, 1.0)
	health_fill.size.x = 150.0 * ratio
	health_fill.color = Color("65c46f")
	if ratio <= 0.35:
		health_fill.color = Color("e3483e")
	elif ratio <= 0.65:
		health_fill.color = Color("e5a842")


func set_clues(current: int, total: int) -> void:
	clues_label.text = "MEMORIAS  %s/%s" % [current, total]


func set_combat_state(dodge_ratio: float, charge_ratio: float, charging: bool) -> void:
	if not is_instance_valid(dodge_fill) or not is_instance_valid(charge_fill):
		return
	var safe_dodge := clampf(dodge_ratio, 0.0, 1.0)
	var safe_charge := clampf(charge_ratio, 0.0, 1.0)
	dodge_fill.size.x = 102.0 * safe_dodge
	dodge_fill.color = Color("70d7a2") if safe_dodge >= 0.99 else Color("5f9fc4")
	dodge_label.text = "ESQUIVA LISTA" if safe_dodge >= 0.99 else "ESQUIVA  %d%%" % int(round(safe_dodge * 100.0))
	charge_fill.size.x = 102.0 * safe_charge
	charge_fill.color = Color("fff0a2") if safe_charge >= 0.98 else Color("d9a94c")
	charge_label.text = "HONDA  ¡SUELTA F!" if safe_charge >= 0.98 else ("HONDA  %d%%" % int(round(safe_charge * 100.0)) if charging else "HONDA  MANTÉN F")


func flash_damage() -> void:
	if not is_instance_valid(damage_overlay):
		return
	_damage_flash_serial += 1
	var serial := _damage_flash_serial
	damage_overlay.color = Color(0.82, 0.06, 0.05, 0.20)
	damage_overlay.visible = true
	await get_tree().create_timer(0.14, true, false, true).timeout
	if is_instance_valid(damage_overlay) and serial == _damage_flash_serial:
		damage_overlay.visible = false


func set_server_status(connected: bool, text: String) -> void:
	server_label.text = text
	server_label.modulate = Color("83d27a") if connected else Color("f0a36b")


func set_profile_name(display_name: String) -> void:
	profile_badge.text = "PERFIL  •  %s" % display_name.to_upper()


func show_message(text: String) -> void:
	message_label.text = text
	message_label.visible = true
	var shown_text := text
	await get_tree().create_timer(2.6, true, false, true).timeout
	if is_instance_valid(message_label) and message_label.text == shown_text:
		message_label.visible = false


func set_interaction_hint(text: String) -> void:
	interaction_label.text = text
	interaction_panel.visible = not text.is_empty()


func show_dialogue(speaker: String, lines: Array, voice_clips: Array = []) -> void:
	_dialogue_lines = lines
	_dialogue_voices = voice_clips
	_dialogue_index = 0
	speaker_label.text = speaker.to_upper()
	dialogue_panel.visible = true
	_show_current_line()


func is_dialogue_open() -> bool:
	return dialogue_panel.visible


func set_pause_visible(value: bool) -> void:
	pause_panel.visible = value
	if is_instance_valid(_voice_player):
		_voice_player.stream_paused = value
	if is_instance_valid(_blip_player):
		_blip_player.stream_paused = value


func show_game_complete() -> void:
	complete_panel.visible = true


func show_level_card(level_number: int, title: String, subtitle: String) -> void:
	_level_card_serial += 1
	var serial := _level_card_serial
	level_card_title.text = "NIVEL %d  •  %s" % [level_number, title.to_upper()]
	level_card_subtitle.text = subtitle
	level_card_panel.visible = true
	await get_tree().create_timer(2.8, true, false, true).timeout
	if is_instance_valid(level_card_panel) and serial == _level_card_serial:
		level_card_panel.visible = false


func is_title_visible() -> bool:
	return title_panel.visible


func setup_minimap(target_player: Node2D, landmarks: Array[Dictionary], title: String = "MAPA") -> void:
	minimap.setup(target_player, landmarks, title)


func reveal_minimap_position(world_position: Vector2, radius := 1) -> void:
	minimap.reveal_position(world_position, radius)


func set_profiles(profiles: Array) -> void:
	profile_list.clear()
	profile_status_label.modulate = Color.WHITE
	for profile in profiles:
		var name := str(profile.get("display_name", "Perfil"))
		var profile_id := str(profile.get("profile_id", ""))
		profile_list.add_item(name)
		profile_list.set_item_metadata(profile_list.get_item_count() - 1, profile_id)
	if profile_list.get_item_count() > 0:
		profile_list.select(0)
		profile_status_label.text = "Selecciona un perfil e ingresa su PIN."
	else:
		profile_status_label.text = "No hay perfiles. Crea el primero para comenzar."
	set_profile_busy(false)


func set_profile_busy(value: bool, message := "") -> void:
	create_profile_button.disabled = value
	login_profile_button.disabled = value
	delete_profile_button.disabled = value
	if not message.is_empty():
		profile_status_label.text = message


func show_profile_error(message: String) -> void:
	set_profile_busy(false)
	profile_status_label.text = message
	profile_status_label.modulate = Color("f29a7d")


func finish_profile_login(display_name: String) -> void:
	set_profile_name(display_name)
	profile_pin_input.text = ""
	title_panel.visible = false
	profile_status_label.modulate = Color.WHITE


func show_profile_selection(status_message: String = "Consultando perfiles del servidor...") -> void:
	title_panel.visible = true
	pause_panel.visible = false
	complete_panel.visible = false
	dialogue_panel.visible = false
	interaction_panel.visible = false
	profile_pin_input.text = ""
	profile_status_label.text = status_message
	profile_status_label.modulate = Color.WHITE
	set_profile_busy(true)
	set_fullscreen_state(_is_fullscreen())


func set_fullscreen_state(is_fullscreen: bool) -> void:
	if is_instance_valid(title_fullscreen_button):
		title_fullscreen_button.text = "VOLVER A VENTANA" if is_fullscreen else "PANTALLA COMPLETA  F11"
	if is_instance_valid(pause_fullscreen_button):
		pause_fullscreen_button.text = "VOLVER A VENTANA" if is_fullscreen else "PANTALLA COMPLETA"


func set_profile_switch_enabled(enabled: bool) -> void:
	if is_instance_valid(pause_profile_button):
		pause_profile_button.disabled = not enabled
	if is_instance_valid(complete_profile_button):
		complete_profile_button.disabled = not enabled


func _is_fullscreen() -> bool:
	var mode: int = DisplayServer.window_get_mode()
	return mode == DisplayServer.WINDOW_MODE_FULLSCREEN or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN


func _unhandled_input(event: InputEvent) -> void:
	if title_panel.visible:
		if event.is_action_pressed("confirmar"):
			_request_login()
			_mark_input_handled()
		return
	if complete_panel.visible and event.is_action_pressed("nueva_partida"):
		_mark_input_handled()
		new_game_requested.emit()
		return
	if pause_panel.visible or not dialogue_panel.visible:
		return
	if event.is_action_pressed("confirmar") or event.is_action_pressed("interactuar"):
		if dialogue_label.visible_characters < _full_dialogue_line.length():
			_visible_characters = float(_full_dialogue_line.length())
			dialogue_label.visible_characters = _full_dialogue_line.length()
			_set_portrait_frame(0)
		else:
			_voice_player.stop()
			_dialogue_index += 1
			if _dialogue_index >= _dialogue_lines.size():
				dialogue_panel.visible = false
				dialogue_finished.emit()
			else:
				_show_current_line()
		_mark_input_handled()


func _show_current_line() -> void:
	if _dialogue_lines.is_empty():
		dialogue_panel.visible = false
		return
	_full_dialogue_line = str(_dialogue_lines[_dialogue_index])
	dialogue_label.text = _full_dialogue_line
	_visible_characters = 0.0
	dialogue_label.visible_characters = 0
	_mouth_elapsed = 0.0
	_set_portrait_frame(0)
	_voice_player.stop()
	if _dialogue_index < _dialogue_voices.size():
		var voice_resource = _dialogue_voices[_dialogue_index]
		if voice_resource is AudioStream:
			_voice_player.stream = voice_resource
			_voice_player.play()


func _build_interface() -> void:
	var title_strip := ColorRect.new()
	title_strip.position = Vector2(12, 8)
	title_strip.size = Vector2(936, 22)
	title_strip.color = Color("173047")
	add_child(title_strip)
	level_label = _label(Vector2(22, 9), Vector2(380, 20), 12)
	level_label.text = "NIVEL 1/3  •  LA COMUNIDAD"
	level_label.modulate = Color("f0d37d")
	add_child(level_label)
	var game_title := _label(Vector2(405, 9), Vector2(530, 20), 12)
	game_title.text = "KALLAMI  •  SENDEROS DE PLATA  •  V1.5"
	game_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	game_title.modulate = Color("e9cc79")
	add_child(game_title)

	var top_bar := ColorRect.new()
	top_bar.position = Vector2(12, 30)
	top_bar.size = Vector2(936, 82)
	top_bar.color = Color(0.025, 0.06, 0.085, 0.92)
	add_child(top_bar)
	objective_label = _label(Vector2(26, 39), Vector2(610, 27), 17)
	add_child(objective_label)
	health_label = _label(Vector2(26, 74), Vector2(100, 22), 14)
	add_child(health_label)
	var health_back := ColorRect.new()
	health_back.position = Vector2(122, 79)
	health_back.size = Vector2(154, 12)
	health_back.color = Color("241f21")
	add_child(health_back)
	health_fill = ColorRect.new()
	health_fill.position = Vector2(2, 2)
	health_fill.size = Vector2(150, 8)
	health_fill.color = Color("65c46f")
	health_back.add_child(health_fill)
	clues_label = _label(Vector2(304, 74), Vector2(180, 22), 14)
	add_child(clues_label)
	profile_badge = _label(Vector2(510, 39), Vector2(420, 22), 12)
	profile_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	profile_badge.modulate = Color("d8c48e")
	add_child(profile_badge)
	server_label = _label(Vector2(585, 72), Vector2(345, 24), 13)
	server_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(server_label)

	var help := _label(Vector2(14, 510), Vector2(930, 24), 10)
	help.text = "WASD/FLECHAS: MOVER   E: USAR   ESPACIO: ESQUIVAR   MANTÉN F: HONDA   G: GUARDAR   ESC: PAUSA   F11: PANTALLA"
	help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	help.modulate = Color(1, 1, 1, 0.80)
	add_child(help)
	message_label = _label(Vector2(250, 118), Vector2(460, 42), 17)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	message_label.add_theme_constant_override("shadow_offset_x", 2)
	message_label.add_theme_constant_override("shadow_offset_y", 2)
	message_label.visible = false
	add_child(message_label)

	var combat_panel := ColorRect.new()
	combat_panel.position = Vector2(14, 441)
	combat_panel.size = Vector2(262, 57)
	combat_panel.color = Color(0.025, 0.055, 0.075, 0.94)
	add_child(combat_panel)
	dodge_label = _label(Vector2(10, 4), Vector2(126, 17), 10)
	dodge_label.text = "ESQUIVA LISTA"
	dodge_label.modulate = Color("bfeaf3")
	combat_panel.add_child(dodge_label)
	charge_label = _label(Vector2(140, 4), Vector2(114, 17), 10)
	charge_label.text = "HONDA  MANTÉN F"
	charge_label.modulate = Color("f3d27c")
	combat_panel.add_child(charge_label)
	var dodge_back := ColorRect.new()
	dodge_back.position = Vector2(10, 28)
	dodge_back.size = Vector2(106, 12)
	dodge_back.color = Color("1b2530")
	combat_panel.add_child(dodge_back)
	dodge_fill = ColorRect.new()
	dodge_fill.position = Vector2(2, 2)
	dodge_fill.size = Vector2(102, 8)
	dodge_fill.color = Color("70d7a2")
	dodge_back.add_child(dodge_fill)
	var charge_back := ColorRect.new()
	charge_back.position = Vector2(140, 28)
	charge_back.size = Vector2(106, 12)
	charge_back.color = Color("2c271c")
	combat_panel.add_child(charge_back)
	charge_fill = ColorRect.new()
	charge_fill.position = Vector2(2, 2)
	charge_fill.size = Vector2(0, 8)
	charge_fill.color = Color("d9a94c")
	charge_back.add_child(charge_fill)

	minimap = Minimap.new()
	minimap.position = Vector2(730, 363)
	minimap.size = Vector2(214, 134)
	add_child(minimap)

	interaction_panel = ColorRect.new()
	interaction_panel.position = Vector2(296, 440)
	interaction_panel.size = Vector2(368, 46)
	interaction_panel.color = Color(0.025, 0.06, 0.085, 0.95)
	interaction_panel.visible = false
	add_child(interaction_panel)
	interaction_label = _label(Vector2(12, 10), Vector2(344, 27), 16)
	interaction_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	interaction_label.modulate = Color("f2d27c")
	interaction_panel.add_child(interaction_label)

	_build_dialogue_panel()
	pause_panel = _center_panel("JUEGO EN PAUSA\n\nEl mundo y sus sombras están detenidos.\nEspacio: esquivar   •   Mantén F: cargar honda\nG: guardar   •   Esc: continuar", Vector2(590, 310))
	pause_panel.visible = false
	var pause_text := pause_panel.get_child(1) as Label
	pause_text.position = Vector2(28, 15)
	pause_text.size = Vector2(534, 214)
	pause_fullscreen_button = _button("PANTALLA COMPLETA", Vector2(34, 250), Vector2(245, 42))
	pause_fullscreen_button.pressed.connect(fullscreen_requested.emit)
	pause_panel.add_child(pause_fullscreen_button)
	pause_profile_button = _button("CAMBIAR PERFIL", Vector2(310, 250), Vector2(245, 42))
	pause_profile_button.pressed.connect(profile_switch_requested.emit)
	pause_panel.add_child(pause_profile_button)
	add_child(pause_panel)
	complete_panel = _center_panel("KALLAMI RESTAURADO\n\nComunidad, ascenso y cámara de plata completados\nLas tres memorias regresaron al pueblo\nProgreso final enviado al perfil\n\nN: reiniciar este perfil", Vector2(590, 300))
	complete_panel.visible = false
	var complete_text := complete_panel.get_child(1) as Label
	complete_text.position = Vector2(28, 13)
	complete_text.size = Vector2(534, 210)
	complete_profile_button = _button("CAMBIAR PERFIL", Vector2(170, 242), Vector2(250, 42))
	complete_profile_button.pressed.connect(profile_switch_requested.emit)
	complete_panel.add_child(complete_profile_button)
	add_child(complete_panel)
	_build_level_card()
	_build_profile_screen()
	_build_damage_overlay()


func _build_damage_overlay() -> void:
	damage_overlay = ColorRect.new()
	damage_overlay.position = Vector2.ZERO
	damage_overlay.size = Vector2(960, 540)
	damage_overlay.color = Color(0.82, 0.06, 0.05, 0.0)
	damage_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	damage_overlay.visible = false
	add_child(damage_overlay)


func _build_level_card() -> void:
	level_card_panel = ColorRect.new()
	level_card_panel.position = Vector2(205, 190)
	level_card_panel.size = Vector2(550, 160)
	level_card_panel.color = Color(0.02, 0.045, 0.07, 0.97)
	level_card_panel.visible = false
	add_child(level_card_panel)
	var accent := ColorRect.new()
	accent.size = Vector2(10, 160)
	accent.color = Color("c89b52")
	level_card_panel.add_child(accent)
	level_card_title = _label(Vector2(34, 28), Vector2(490, 42), 24)
	level_card_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	level_card_title.modulate = Color("f0d37d")
	level_card_panel.add_child(level_card_title)
	level_card_subtitle = _label(Vector2(38, 80), Vector2(482, 48), 15)
	level_card_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	level_card_subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	level_card_panel.add_child(level_card_subtitle)


func _build_dialogue_panel() -> void:
	dialogue_panel = ColorRect.new()
	dialogue_panel.position = Vector2(42, 334)
	dialogue_panel.size = Vector2(876, 170)
	dialogue_panel.color = Color(0.025, 0.055, 0.08, 0.98)
	dialogue_panel.visible = false
	add_child(dialogue_panel)
	var accent := ColorRect.new()
	accent.position = Vector2.ZERO
	accent.size = Vector2(8, 170)
	accent.color = Color("c89b52")
	dialogue_panel.add_child(accent)
	var portrait_frame := ColorRect.new()
	portrait_frame.position = Vector2(18, 11)
	portrait_frame.size = Vector2(178, 148)
	portrait_frame.color = Color("b99d6d")
	dialogue_panel.add_child(portrait_frame)
	portrait = TextureRect.new()
	portrait.position = Vector2(4, 4)
	portrait.size = Vector2(170, 140)
	portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	portrait.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	portrait_frame.add_child(portrait)
	_set_portrait_frame(0)
	speaker_label = _label(Vector2(218, 16), Vector2(620, 25), 18)
	speaker_label.modulate = Color("e8c66a")
	dialogue_panel.add_child(speaker_label)
	dialogue_label = _label(Vector2(218, 48), Vector2(625, 78), 17)
	dialogue_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dialogue_panel.add_child(dialogue_label)
	var continue_label := _label(Vector2(532, 137), Vector2(310, 20), 12)
	continue_label.text = "E / ESPACIO / ENTER  •  CONTINUAR"
	continue_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	continue_label.modulate = Color(1, 1, 1, 0.64)
	dialogue_panel.add_child(continue_label)


func _build_profile_screen() -> void:
	title_panel = ColorRect.new()
	title_panel.position = Vector2.ZERO
	title_panel.size = Vector2(960, 540)
	title_panel.color = Color("0d1720")
	add_child(title_panel)
	var accent := ColorRect.new()
	accent.size = Vector2(18, 540)
	accent.color = Color("c9954f")
	title_panel.add_child(accent)
	var title := _label(Vector2(58, 64), Vector2(430, 124), 39)
	title.text = "KALLAMI\nSENDEROS DE PLATA"
	title.modulate = Color("f1d287")
	title_panel.add_child(title)
	var subtitle := _label(Vector2(61, 198), Vector2(420, 76), 17)
	subtitle.text = "Aventura narrativa 2D en el Cerro Kallami\nVersión final 1.5 para gameplay y defensa"
	subtitle.modulate = Color("d8e1e7")
	title_panel.add_child(subtitle)
	var preview_frame := ColorRect.new()
	preview_frame.position = Vector2(62, 294)
	preview_frame.size = Vector2(395, 188)
	preview_frame.color = Color("b99d6d")
	title_panel.add_child(preview_frame)
	var preview := TextureRect.new()
	preview.position = Vector2(5, 5)
	preview.size = Vector2(385, 178)
	preview.texture = LEVEL_PREVIEW
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	preview.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	preview_frame.add_child(preview)
	title_fullscreen_button = _button("PANTALLA COMPLETA  F11", Vector2(62, 490), Vector2(225, 34))
	title_fullscreen_button.pressed.connect(fullscreen_requested.emit)
	title_panel.add_child(title_fullscreen_button)

	var profile_panel := ColorRect.new()
	profile_panel.position = Vector2(505, 42)
	profile_panel.size = Vector2(410, 450)
	profile_panel.color = Color("152532")
	title_panel.add_child(profile_panel)
	var profile_title := _label(Vector2(24, 18), Vector2(360, 34), 22)
	profile_title.text = "PERFILES DE PARTIDA"
	profile_title.modulate = Color("efd17e")
	profile_panel.add_child(profile_title)
	var profile_note := _label(Vector2(24, 55), Vector2(360, 43), 13)
	profile_note.text = "Cada perfil protege su progreso con un PIN local\ny mantiene una partida independiente."
	profile_note.modulate = Color("bdcbd3")
	profile_panel.add_child(profile_note)
	profile_list = ItemList.new()
	profile_list.position = Vector2(24, 108)
	profile_list.size = Vector2(362, 112)
	profile_list.add_theme_font_size_override("font_size", 16)
	profile_panel.add_child(profile_list)
	profile_name_input = LineEdit.new()
	profile_name_input.position = Vector2(24, 234)
	profile_name_input.size = Vector2(226, 38)
	profile_name_input.placeholder_text = "Nombre del nuevo perfil"
	profile_name_input.max_length = 24
	profile_panel.add_child(profile_name_input)
	profile_pin_input = LineEdit.new()
	profile_pin_input.position = Vector2(260, 234)
	profile_pin_input.size = Vector2(126, 38)
	profile_pin_input.placeholder_text = "PIN (4)"
	profile_pin_input.max_length = 4
	profile_pin_input.secret = true
	profile_panel.add_child(profile_pin_input)
	create_profile_button = _button("CREAR", Vector2(24, 286), Vector2(108, 40))
	create_profile_button.pressed.connect(_request_create)
	profile_panel.add_child(create_profile_button)
	login_profile_button = _button("INGRESAR", Vector2(141, 286), Vector2(118, 40))
	login_profile_button.pressed.connect(_request_login)
	profile_panel.add_child(login_profile_button)
	delete_profile_button = _button("ELIMINAR", Vector2(268, 286), Vector2(118, 40))
	delete_profile_button.pressed.connect(_request_delete)
	profile_panel.add_child(delete_profile_button)
	profile_status_label = _label(Vector2(24, 343), Vector2(362, 70), 14)
	profile_status_label.text = "Consultando perfiles del servidor..."
	profile_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	profile_panel.add_child(profile_status_label)
	var footer := _label(Vector2(24, 415), Vector2(362, 20), 11)
	footer.text = "ENTER: ingresar  •  F11: pantalla completa  •  PIN protegido"
	footer.modulate = Color(1, 1, 1, 0.50)
	profile_panel.add_child(footer)
	set_profile_busy(true)


func _request_create() -> void:
	var name := profile_name_input.text.strip_edges()
	var pin := profile_pin_input.text.strip_edges()
	if name.length() < 2:
		show_profile_error("Escribe un nombre de al menos 2 caracteres.")
		return
	if not _valid_pin(pin):
		show_profile_error("El PIN debe tener exactamente 4 números.")
		return
	set_profile_busy(true, "Creando perfil protegido...")
	profile_create_requested.emit(name, pin)


func _request_login() -> void:
	var selected := profile_list.get_selected_items()
	var pin := profile_pin_input.text.strip_edges()
	if selected.is_empty():
		show_profile_error("Selecciona un perfil.")
		return
	if not _valid_pin(pin):
		show_profile_error("Ingresa el PIN de 4 números.")
		return
	var profile_id := str(profile_list.get_item_metadata(selected[0]))
	set_profile_busy(true, "Verificando perfil...")
	profile_login_requested.emit(profile_id, pin)


func _request_delete() -> void:
	var selected := profile_list.get_selected_items()
	var pin := profile_pin_input.text.strip_edges()
	if selected.is_empty() or not _valid_pin(pin):
		show_profile_error("Selecciona el perfil e ingresa su PIN para eliminarlo.")
		return
	var profile_id := str(profile_list.get_item_metadata(selected[0]))
	set_profile_busy(true, "Eliminando perfil y su progreso...")
	profile_delete_requested.emit(profile_id, pin)


func _valid_pin(pin: String) -> bool:
	return pin.length() == 4 and pin.is_valid_int()


func _set_portrait_frame(frame: int) -> void:
	if not is_instance_valid(portrait):
		return
	var atlas := AtlasTexture.new()
	atlas.atlas = FLORENCIO_TALK
	# La hoja contiene dos retratos cuadrados de 887 px: boca cerrada y abierta.
	atlas.region = Rect2(frame * 887, 0, 887, 887)
	portrait.texture = atlas


func _mark_input_handled() -> void:
	var viewport := get_viewport()
	if viewport != null:
		viewport.set_input_as_handled()


func _label(at: Vector2, dimensions: Vector2, font_size: int) -> Label:
	var label := Label.new()
	label.position = at
	label.size = dimensions
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", Color("f5f0e6"))
	return label


func _button(text: String, at: Vector2, dimensions: Vector2) -> Button:
	var button := Button.new()
	button.text = text
	button.position = at
	button.size = dimensions
	button.add_theme_font_size_override("font_size", 13)
	return button


func _center_panel(text: String, dimensions: Vector2) -> ColorRect:
	var panel := ColorRect.new()
	panel.position = Vector2(480, 270) - dimensions / 2.0
	panel.size = dimensions
	panel.color = Color(0.025, 0.055, 0.08, 0.98)
	var accent := ColorRect.new()
	accent.size = Vector2(8, dimensions.y)
	accent.color = Color("c89b52")
	panel.add_child(accent)
	var label := Label.new()
	label.position = Vector2(28, 20)
	label.size = dimensions - Vector2(48, 40)
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", 20)
	label.add_theme_color_override("font_color", Color("f5f0e6"))
	panel.add_child(label)
	return panel
