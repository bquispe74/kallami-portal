extends Node2D

const TRAIL_DISTANCE := 185.0
const MAX_TRAIL_LIGHTS := 46

var player: Node2D
var _light_texture: GradientTexture2D
var _darkness: CanvasModulate
var _explorer_light: PointLight2D
var _cave_entrance := Vector2(-9999.0, -9999.0)
var _cave_transition_radius := 1.0
var _last_trail_position := Vector2(-9999, -9999)
var _trail_lights: Array[PointLight2D] = []


func setup(target_player: Node2D) -> void:
	player = target_player
	_build_darkness()
	_light_texture = _create_light_texture()
	_explorer_light = _make_light(1.30, 1.15)
	_explorer_light.name = "LuzExploracion"
	player.add_child(_explorer_light)
	_leave_trail_light(player.global_position)


func set_cave_transition(entrance: Vector2, radius: float) -> void:
	_cave_entrance = entrance
	_cave_transition_radius = maxf(radius, 1.0)


func _process(_delta: float) -> void:
	if not is_instance_valid(player):
		return
	_update_cave_lighting()
	if player.global_position.distance_to(_last_trail_position) >= TRAIL_DISTANCE:
		_leave_trail_light(player.global_position)


func _build_darkness() -> void:
	_darkness = CanvasModulate.new()
	_darkness.name = "SombraDelCerro"
	_darkness.color = Color(0.19, 0.22, 0.30, 1.0)
	add_child(_darkness)


func _update_cave_lighting() -> void:
	if not is_instance_valid(_darkness) or not is_instance_valid(_explorer_light):
		return
	var distance := player.global_position.distance_to(_cave_entrance)
	var progress := 1.0 - smoothstep(0.0, _cave_transition_radius, distance)
	var outdoor_tone := Color(0.19, 0.22, 0.30, 1.0)
	var cave_tone := Color(0.075, 0.095, 0.17, 1.0)
	_darkness.color = outdoor_tone.lerp(cave_tone, progress)
	_explorer_light.color = Color("f7d58a").lerp(Color("9bdcff"), progress)


func _create_light_texture() -> GradientTexture2D:
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.52, 1.0])
	gradient.colors = PackedColorArray([
		Color(1.0, 0.94, 0.73, 1.0),
		Color(0.82, 0.76, 0.60, 0.72),
		Color(0.0, 0.0, 0.0, 0.0)
	])
	var texture := GradientTexture2D.new()
	texture.width = 384
	texture.height = 384
	texture.fill = GradientTexture2D.FILL_RADIAL
	texture.fill_from = Vector2(0.5, 0.5)
	texture.fill_to = Vector2(1.0, 0.5)
	texture.gradient = gradient
	return texture


func _make_light(texture_scale: float, energy: float) -> PointLight2D:
	var light := PointLight2D.new()
	light.texture = _light_texture
	light.texture_scale = texture_scale
	light.energy = energy
	light.color = Color("f7d58a")
	light.shadow_enabled = true
	light.range_z_min = -100
	light.range_z_max = 100
	return light


func _leave_trail_light(at_position: Vector2) -> void:
	_last_trail_position = at_position
	var trail := _make_light(0.58, 0.26)
	trail.name = "RecuerdoDeLuz"
	trail.position = at_position
	trail.shadow_enabled = false
	add_child(trail)
	_trail_lights.append(trail)
	if _trail_lights.size() > MAX_TRAIL_LIGHTS:
		var oldest: PointLight2D = _trail_lights.pop_front()
		if is_instance_valid(oldest):
			oldest.queue_free()
