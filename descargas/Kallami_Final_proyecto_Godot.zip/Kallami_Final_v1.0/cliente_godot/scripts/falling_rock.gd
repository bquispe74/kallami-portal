extends Node2D

signal resolved(world_position: Vector2, hit_player: bool)

const WARNING_SECONDS := 1.0
const IMPACT_SECONDS := 0.26

var target_player: Node2D
var impact_radius := 56.0
var _elapsed := 0.0
var _impact_done := false
var _impact_elapsed := 0.0


func setup(player: Node2D, radius: float = 56.0) -> void:
	target_player = player
	impact_radius = radius


func _ready() -> void:
	z_index = 35
	queue_redraw()


func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed >= WARNING_SECONDS and not _impact_done:
		_impact_done = true
		var hit_player := false
		if is_instance_valid(target_player):
			var distance := target_player.global_position.distance_to(global_position)
			if distance <= impact_radius + 15.0 and target_player.has_method("receive_damage"):
				hit_player = bool(target_player.receive_damage(1))
		resolved.emit(global_position, hit_player)
	if _impact_done:
		_impact_elapsed += delta
		if _impact_elapsed >= IMPACT_SECONDS:
			queue_free()
	queue_redraw()


func _draw() -> void:
	if not _impact_done:
		var warning_progress := clampf(_elapsed / WARNING_SECONDS, 0.0, 1.0)
		var pulse := 1.0 + sin(_elapsed * 17.0) * 0.07
		draw_circle(Vector2.ZERO, impact_radius * 0.72, Color(0.91, 0.20, 0.14, 0.12 + warning_progress * 0.09))
		draw_arc(Vector2.ZERO, impact_radius * pulse, 0, TAU, 36, Color(1.0, 0.48, 0.29, 0.8), 3.0)
		var rock_progress := clampf((_elapsed - WARNING_SECONDS * 0.58) / (WARNING_SECONDS * 0.42), 0.0, 1.0)
		var rock_y := lerpf(-145.0, -9.0, rock_progress)
		var rock_scale := lerpf(0.28, 1.0, rock_progress)
		for trail_index in range(3):
			var trail_y := rock_y - 24.0 - float(trail_index) * 19.0
			draw_line(Vector2(-7.0, trail_y), Vector2(7.0, trail_y + 16.0), Color(0.92, 0.82, 0.65, 0.35 - float(trail_index) * 0.08), 4.0)
		draw_circle(Vector2(0, rock_y), 18.0 * rock_scale, Color("545b68"))
		draw_circle(Vector2(-5, rock_y - 5), 6.0 * rock_scale, Color("808995"))
		return
	var progress := clampf(_impact_elapsed / IMPACT_SECONDS, 0.0, 1.0)
	draw_circle(Vector2.ZERO, impact_radius * progress, Color(0.92, 0.37, 0.22, (1.0 - progress) * 0.18))
	draw_arc(Vector2.ZERO, lerpf(10.0, impact_radius * 1.2, progress), 0, TAU, 32, Color(1.0, 0.65, 0.35, 1.0 - progress), 4.0)
	for debris_index in range(7):
		var angle := TAU * float(debris_index) / 7.0
		var start := Vector2.from_angle(angle) * impact_radius * progress * 0.45
		var finish := Vector2.from_angle(angle) * impact_radius * progress
		draw_line(start, finish, Color("a8a093", 1.0 - progress), 3.0)
