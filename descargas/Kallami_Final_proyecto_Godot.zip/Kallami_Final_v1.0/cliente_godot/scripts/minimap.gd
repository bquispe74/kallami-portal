extends Control

const WORLD_SIZE := Vector2(2400, 1500)
const GRID := Vector2i(20, 13)

var player: Node2D
var landmarks: Array[Dictionary] = []
var _discovered: Dictionary = {}
var _last_cell := Vector2i(-99, -99)
var _map_title := "COMUNIDAD"


func _ready() -> void:
	custom_minimum_size = Vector2(214, 134)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS


func setup(target_player: Node2D, map_landmarks: Array[Dictionary], title: String = "MAPA") -> void:
	player = target_player
	landmarks = map_landmarks
	_map_title = title.to_upper()
	_discovered.clear()
	_last_cell = Vector2i(-99, -99)
	_reveal_around(_world_to_cell(player.global_position), 1)
	queue_redraw()


func reveal_position(world_position: Vector2, radius := 1) -> void:
	_reveal_around(_world_to_cell(world_position), radius)
	queue_redraw()


func _process(_delta: float) -> void:
	if not is_instance_valid(player):
		return
	var cell := _world_to_cell(player.global_position)
	if cell != _last_cell:
		_last_cell = cell
		_reveal_around(cell, 1)
		queue_redraw()


func _world_to_cell(world_position: Vector2) -> Vector2i:
	return Vector2i(
		clampi(int(world_position.x / WORLD_SIZE.x * GRID.x), 0, GRID.x - 1),
		clampi(int(world_position.y / WORLD_SIZE.y * GRID.y), 0, GRID.y - 1)
	)


func _reveal_around(center: Vector2i, radius: int) -> void:
	for y in range(center.y - radius, center.y + radius + 1):
		for x in range(center.x - radius, center.x + radius + 1):
			if x >= 0 and y >= 0 and x < GRID.x and y < GRID.y:
				_discovered[Vector2i(x, y)] = true


func _draw() -> void:
	var map_rect := Rect2(7, 23, size.x - 14, size.y - 30)
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.025, 0.045, 0.06, 0.94))
	draw_rect(Rect2(Vector2.ZERO, size), Color("b99050"), false, 2.0)
	draw_string(ThemeDB.fallback_font, Vector2(10, 17), "MAPA • %s" % _map_title, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("ead28d"))
	draw_rect(map_rect, Color("101820"))
	var cell_size := Vector2(map_rect.size.x / GRID.x, map_rect.size.y / GRID.y)
	for key in _discovered.keys():
		var cell: Vector2i = key
		var cell_rect := Rect2(map_rect.position + Vector2(cell.x, cell.y) * cell_size, cell_size + Vector2.ONE)
		var variation := (cell.x * 5 + cell.y * 3) % 3
		var color := Color("816847") if variation == 0 else Color("96794f")
		draw_rect(cell_rect, color)
	for landmark in landmarks:
		var world_position: Vector2 = landmark.get("position", Vector2.ZERO)
		var landmark_cell := _world_to_cell(world_position)
		if not _discovered.has(landmark_cell):
			continue
		var point := map_rect.position + world_position / WORLD_SIZE * map_rect.size
		var landmark_color: Color = landmark.get("color", Color.WHITE)
		draw_circle(point, 3.2, landmark_color)
	if is_instance_valid(player):
		var player_point := map_rect.position + player.global_position / WORLD_SIZE * map_rect.size
		draw_circle(player_point, 4.3, Color("f5f1df"))
		draw_arc(player_point, 6.4, 0, TAU, 12, Color("22303a"), 1.5)
