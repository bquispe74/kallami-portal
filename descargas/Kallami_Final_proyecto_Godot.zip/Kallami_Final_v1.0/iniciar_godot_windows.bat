@echo off
setlocal
set "PROJECT_DIR=%~dp0cliente_godot"

where godot4 >nul 2>nul
if %errorlevel%==0 (
  godot4 --editor --path "%PROJECT_DIR%"
  exit /b
)

where godot >nul 2>nul
if %errorlevel%==0 (
  godot --editor --path "%PROJECT_DIR%"
  exit /b
)

for %%G in (
  "%USERPROFILE%\Downloads\Godot_v4.7.2-stable_win64.exe"
  "%USERPROFILE%\Downloads\Godot_v4.7.2-stable_mono_win64.exe"
) do (
  if exist %%G (
    start "" %%G --editor --path "%PROJECT_DIR%"
    exit /b
  )
)

echo No se encontro Godot. Abre el ejecutable manualmente e importa cliente_godot\project.godot.
pause
