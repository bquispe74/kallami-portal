extends Node

const AMBIENT = preload("res://assets/audio/ambient_village.wav")
const AMBIENT_MOUNTAIN = preload("res://assets/audio/ambient_mountain.wav")
const AMBIENT_CHAMBER = preload("res://assets/audio/ambient_chamber.wav")
const COMBAT = preload("res://assets/audio/combat_tension.wav")
const FINAL_CHASE = preload("res://assets/audio/final_chase.wav")
const SFX := {
	"throw": preload("res://assets/audio/throw_rock.wav"),
	"charged_throw": preload("res://assets/audio/charged_throw.wav"),
	"hit": preload("res://assets/audio/rock_hit.wav"),
	"dodge": preload("res://assets/audio/dodge.wav"),
	"enemy_shot": preload("res://assets/audio/enemy_shot.wav"),
	"player_hurt": preload("res://assets/audio/player_hurt.wav"),
	"shadow_near": preload("res://assets/audio/shadow_near.wav"),
	"shadow_defeat": preload("res://assets/audio/shadow_defeat.wav"),
	"quake": preload("res://assets/audio/earthquake.wav"),
	"clue": preload("res://assets/audio/clue_pickup.wav"),
	"confirm": preload("res://assets/audio/ui_confirm.wav")
}

var player: Node2D
var shadows: Array = []
var ambient_player: AudioStreamPlayer
var combat_player: AudioStreamPlayer
var finale_player: AudioStreamPlayer
var _sfx_players: Array[AudioStreamPlayer] = []
var _ghost_cooldown := 0.0
var _finale_active := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	ambient_player = _music_player("AmbientePueblo", AMBIENT, -5.0)
	combat_player = _music_player("TensionSombras", COMBAT, -60.0)
	finale_player = _music_player("MusicaPersecucionFinal", FINAL_CHASE, -60.0)
	for index in range(10):
		var effect := AudioStreamPlayer.new()
		effect.name = "Efecto%d" % (index + 1)
		effect.volume_db = -4.0
		add_child(effect)
		_sfx_players.append(effect)


func setup(target_player: Node2D, enemies: Array) -> void:
	player = target_player
	shadows = enemies


func set_level(level_number: int) -> void:
	set_finale_active(false)
	var selected_stream: AudioStream = AMBIENT
	if level_number == 2:
		selected_stream = AMBIENT_MOUNTAIN
	elif level_number == 3:
		selected_stream = AMBIENT_CHAMBER
	if ambient_player.stream == selected_stream:
		return
	ambient_player.stop()
	ambient_player.stream = selected_stream
	ambient_player.play()


func _process(delta: float) -> void:
	if get_tree().paused:
		return
	_ghost_cooldown = maxf(0.0, _ghost_cooldown - delta)
	var nearest := _nearest_shadow_distance()
	var danger := clampf(1.0 - (nearest - 95.0) / 340.0, 0.0, 1.0)
	var ambient_target := lerpf(-5.0, -18.0, danger)
	if _finale_active:
		ambient_target = -19.0
	ambient_player.volume_db = lerpf(ambient_player.volume_db, ambient_target, minf(1.0, delta * 2.2))
	combat_player.volume_db = lerpf(combat_player.volume_db, lerpf(-55.0, -5.0, danger), minf(1.0, delta * 2.6))
	var finale_target := -8.0 if _finale_active else -60.0
	finale_player.volume_db = lerpf(finale_player.volume_db, finale_target, minf(1.0, delta * 1.8))
	if _finale_active and not finale_player.playing:
		finale_player.play()
	elif not _finale_active and finale_player.playing and finale_player.volume_db <= -55.0:
		finale_player.stop()
	if nearest < 250.0 and _ghost_cooldown <= 0.0:
		play_sfx("shadow_near", -8.0)
		_ghost_cooldown = 4.5


func play_sfx(effect_name: String, volume_db := -4.0) -> void:
	if not SFX.has(effect_name):
		return
	var selected: AudioStreamPlayer = _sfx_players[0]
	for candidate in _sfx_players:
		if not candidate.playing:
			selected = candidate
			break
	selected.stream = SFX[effect_name]
	selected.volume_db = volume_db
	selected.play()


func set_game_paused(value: bool) -> void:
	ambient_player.stream_paused = value
	combat_player.stream_paused = value
	finale_player.stream_paused = value
	for effect in _sfx_players:
		effect.stream_paused = value


func set_finale_active(value: bool) -> void:
	_finale_active = value


func _music_player(node_name: String, music_stream: AudioStream, initial_volume: float) -> AudioStreamPlayer:
	var music := AudioStreamPlayer.new()
	music.name = node_name
	music.stream = music_stream
	music.volume_db = initial_volume
	add_child(music)
	music.finished.connect(func() -> void: music.play())
	music.play()
	return music


func _nearest_shadow_distance() -> float:
	if not is_instance_valid(player):
		return 9999.0
	var nearest := 9999.0
	for enemy in shadows:
		if is_instance_valid(enemy):
			nearest = minf(nearest, player.global_position.distance_to(enemy.global_position))
	return nearest
