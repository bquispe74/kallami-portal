from pathlib import Path
import sqlite3

from fastapi.testclient import TestClient

from app import main


def make_client(tmp_path: Path) -> TestClient:
    main.DATABASE_PATH = tmp_path / "test_kallami_final.db"
    main.initialize_database()
    return TestClient(main.app)


def create_profile(client: TestClient, name: str = "Brayan", pin: str = "2661") -> tuple[str, dict[str, str]]:
    response = client.post("/api/perfiles", json={"display_name": name, "pin": pin})
    assert response.status_code == 201
    data = response.json()
    return data["profile"]["profile_id"], {"Authorization": f"Bearer {data['access_token']}"}


def progress_payload(profile_id: str) -> dict:
    return {
        "player_id": profile_id,
        "level": 1,
        "clues": 0,
        "clue_ids": [],
        "checkpoint_id": "inicio",
        "completed": False,
        "health": 5,
        "position_x": 220.0,
        "position_y": 1260.0,
        "mission_state": 0,
        "puzzle_step": 0,
    }


def test_status(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    response = client.get("/api/estado")
    assert response.status_code == 200
    assert response.json() == {"estado": "ok", "version": "1.1.0", "perfiles": "habilitados"}


def test_create_list_and_login_profile(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, _headers = create_profile(client)
    listed = client.get("/api/perfiles")
    assert listed.status_code == 200
    assert listed.json()[0]["display_name"] == "Brayan"
    logged = client.post("/api/perfiles/login", json={"profile_id": profile_id, "pin": "2661"})
    assert logged.status_code == 200
    assert logged.json()["access_token"]


def test_pin_is_not_stored_in_plain_text(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, _headers = create_profile(client, "Eduardo", "9042")
    with sqlite3.connect(main.DATABASE_PATH) as connection:
        stored = connection.execute(
            "SELECT pin_salt, pin_hash FROM profiles WHERE profile_id = ?", (profile_id,)
        ).fetchone()
    assert stored is not None
    assert "9042" not in stored
    assert len(stored[1]) == 64


def test_rejects_wrong_pin(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, _headers = create_profile(client)
    response = client.post("/api/perfiles/login", json={"profile_id": profile_id, "pin": "0000"})
    assert response.status_code == 401


def test_progress_requires_authorization(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, _headers = create_profile(client)
    assert client.get(f"/api/progreso/{profile_id}").status_code == 401
    assert client.post("/api/progreso", json=progress_payload(profile_id)).status_code == 401


def test_profiles_cannot_read_each_other(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    first_id, first_headers = create_profile(client, "Juan", "1111")
    second_id, _second_headers = create_profile(client, "Florencio", "2222")
    assert first_id != second_id
    response = client.get(f"/api/progreso/{second_id}", headers=first_headers)
    assert response.status_code == 403


def test_load_and_save_independent_progress(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, headers = create_profile(client)
    base = progress_payload(profile_id)
    base.update(
        level=2,
        checkpoint_id="ascenso_inicio",
        clues=1,
        clue_ids=["pista_comunidad"],
        health=3,
        position_x=635.0,
        position_y=720.0,
        mission_state=1,
    )
    saved = client.post("/api/progreso", json=base, headers=headers)
    assert saved.status_code == 200
    loaded = client.get(f"/api/progreso/{profile_id}", headers=headers)
    assert loaded.status_code == 200
    assert loaded.json()["clue_ids"] == ["pista_comunidad"]
    assert loaded.json()["health"] == 3
    assert loaded.json()["position_x"] == 635.0


def test_rejects_forged_clue_counter_and_jump(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, headers = create_profile(client)
    mismatch = progress_payload(profile_id)
    mismatch.update(clues=2, clue_ids=["pista_comunidad"], mission_state=1)
    assert client.post("/api/progreso", json=mismatch, headers=headers).status_code == 422
    jump = progress_payload(profile_id)
    jump.update(
        level=2,
        checkpoint_id="ascenso_inicio",
        clues=2,
        clue_ids=["pista_comunidad", "pista_mineros"],
        mission_state=1,
    )
    assert client.post("/api/progreso", json=jump, headers=headers).status_code == 409


def test_rejects_impossible_checkpoint(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, headers = create_profile(client)
    payload = progress_payload(profile_id)
    payload["checkpoint_id"] = "camara_final"
    assert client.post("/api/progreso", json=payload, headers=headers).status_code == 422


def test_complete_run_and_reset(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, headers = create_profile(client)
    payload = progress_payload(profile_id)
    payload["mission_state"] = 1
    assert client.post("/api/progreso", json=payload, headers=headers).status_code == 200
    payload.update(level=2, checkpoint_id="ascenso_inicio", position_x=190.0, position_y=1320.0)
    assert client.post("/api/progreso", json=payload, headers=headers).status_code == 200
    for clue_id in ["pista_comunidad", "pista_mineros", "pista_cerro"]:
        payload["clue_ids"].append(clue_id)
        payload["clues"] = len(payload["clue_ids"])
        payload["mission_state"] = 2 if payload["clues"] == 3 else 1
        assert client.post("/api/progreso", json=payload, headers=headers).status_code == 200
    payload.update(level=3, checkpoint_id="camara_inicio", position_x=1200.0, position_y=1320.0)
    assert client.post("/api/progreso", json=payload, headers=headers).status_code == 200
    for puzzle_step in [1, 2, 3]:
        payload["puzzle_step"] = puzzle_step
        assert client.post("/api/progreso", json=payload, headers=headers).status_code == 200
    payload.update(completed=True, mission_state=3, checkpoint_id="camara_final", position_y=475.0)
    assert client.post("/api/progreso", json=payload, headers=headers).status_code == 200
    reset = client.post(f"/api/progreso/{profile_id}/reiniciar", headers=headers)
    assert reset.status_code == 200
    assert reset.json()["clues"] == 0
    assert reset.json()["health"] == 5
    assert reset.json()["checkpoint_id"] == "inicio"
    assert reset.json()["puzzle_step"] == 0


def test_rejects_final_puzzle_outside_chamber(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, headers = create_profile(client, "Rosario", "2802")
    payload = progress_payload(profile_id)
    payload.update(level=1, mission_state=1, puzzle_step=1)
    response = client.post("/api/progreso", json=payload, headers=headers)
    assert response.status_code == 409


def test_delete_profile_cascades_progress(tmp_path: Path) -> None:
    client = make_client(tmp_path)
    profile_id, _headers = create_profile(client, "Douglas", "3333")
    deleted = client.post(f"/api/perfiles/{profile_id}/eliminar", json={"pin": "3333"})
    assert deleted.status_code == 200
    assert client.get("/api/perfiles").json() == []
    with sqlite3.connect(main.DATABASE_PATH) as connection:
        count = connection.execute("SELECT COUNT(*) FROM progress").fetchone()[0]
    assert count == 0
