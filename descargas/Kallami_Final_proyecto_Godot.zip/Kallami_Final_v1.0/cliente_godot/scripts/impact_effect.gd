extends Node2D

var effect_color := Color("f5cf69")
var strong := false
var _elapsed := 0.0
var _duration := 0.34


func setup(color: Color, is_strong: bool = false) -> void:
	effect_color = color
	strong = is_strong
	_duration = 0.46 if strong else 0.34


func _ready() -> void:
	z_index = 40
	queue_redraw()


func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed >= _duration:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	var progress := clampf(_elapsed / _duration, 0.0, 1.0)
	var alpha := 1.0 - progress
	var radius := lerpf(5.0, 30.0 if strong else 22.0, progress)
	draw_arc(Vector2.ZERO, radius, 0, TAU, 24, Color(effect_color.r, effect_color.g, effect_color.b, alpha), 4.0 if strong else 2.8)
	draw_circle(Vector2.ZERO, lerpf(7.0, 2.0, progress), Color(1.0, 0.95, 0.78, alpha * 0.8))
	var spark_count := 10 if strong else 7
	for spark_index in range(spark_count):
		var angle := TAU * float(spark_index) / float(spark_count) + 0.22
		var start := Vector2.from_angle(angle) * radius * 0.55
		var finish := Vector2.from_angle(angle) * radius * 1.25
		draw_line(start, finish, Color(effect_color.r, effect_color.g, effect_color.b, alpha), 2.5 if strong else 1.7)
