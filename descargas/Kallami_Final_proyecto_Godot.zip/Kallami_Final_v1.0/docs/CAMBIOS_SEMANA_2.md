# Registro de cambios de la Semana 2

## Revisión Alpha 0.5 Estable

- `N` y `n` crean una sesión y comienzan la nueva partida directamente, sin exigir `Enter` otra vez.
- `Esc` congela realmente el jugador, los enemigos y los demás elementos del mundo; solo la interfaz continúa procesando para poder reanudar.
- Se añadió autoguardado por cambios cada tres segundos y guardado manual con `G`.
- El servidor guarda y restaura misión, salud y posición exacta, además de pista y checkpoint.
- La tabla SQLite se migra automáticamente al arrancar y conserva los registros anteriores.
- Se amplió el escenario con plaza empedrada, faroles, bancas, vasijas, chimeneas, humo y terrazas al pie del cerro.
- Se aumentó la distribución a cinco sombras para dar más recorrido y riesgo al mapa.

## Revisión Alpha 0.4 Pro

- La escena principal procesa directamente la tecla `E` y decide el objeto interactivo más cercano.
- Se eliminó una señal intermedia para evitar fallos silenciosos al hablar con Florencio.
- La nueva partida utiliza recarga diferida y ya no destruye el HUD durante el procesamiento de la tecla `N`.
- Juan posee vistas diferenciadas hacia arriba, abajo, izquierda y derecha.
- El movimiento modifica las piernas y la orientación del rostro, cabello, poncho y bolso.

## Revisión Alpha 0.3 Pro

- Se distribuyeron tres sombras en distintos tramos del recorrido.
- La pista se trasladó al sureste, junto a los cultivos y lejos del punto inicial.
- La salida permanece en el extremo opuesto para exigir exploración y regreso.
- Se ajustó la velocidad y el radio de detección de las sombras para mantener una dificultad razonable.
- Se añadió la opción `N: NUEVA PARTIDA` para repetir la demostración sin borrar archivos manualmente.

## Revisión Alpha 0.2 Pro

- Se sustituyó la interacción silenciosa por una comprobación directa de distancia.
- Se añadió un aviso visible para hablar con Florencio y recoger la pista.
- Se corrigió la incompatibilidad del nombre `draw_ellipse` con Godot 4.7.2.
- Se incorporó una pantalla de inicio con el arte de referencia del nivel.
- Se añadió un retrato conceptual de Florencio a la ventana de diálogo.
- Se rediseñó el escenario con montaña, casas de adobe, cultivos, muros de piedra, vegetación, senderos y santuario de la pista.
- Se mejoraron las siluetas de Juan y Florencio para acercarlas al boceto conceptual.

## Versión Alpha 0.1

- Se confirmó que la integración cliente-servidor es obligatoria.
- Se concretó Godot 4.7.2 con renderizador Compatibility para el cliente.
- Se mantuvo PC como plataforma principal y la exportación web quedó para una prueba posterior.
- Se implementó movimiento top-down con WASD y flechas.
- Se añadieron cámara, colisiones, diálogo, objetivo, HUD, checkpoint y reinicio.
- Se implementó a Florencio Mamani con estados de diálogo vinculados al progreso.
- Se incorporó una sombra con patrulla, persecución, ataque por contacto y dos puntos de salud.
- Se limitó el combate a un único ataque para proteger el alcance.
- Se construyó un escenario tutorial con una pista y una salida verificable.
- Se creó una API FastAPI y un modelo SQLite para sesión y progreso.
- El servidor valida rangos, checkpoints y transiciones antes de guardar.
- Se añadió tolerancia básica a desconexión: el juego sigue funcionando y el HUD informa el estado.

## Contenido aplazado para Semana 3

- Niveles 2 y 3 completos.
- Tres pistas definitivas y decisión narrativa final.
- Sprites y animaciones finales.
- Música, ambiente y efectos de sonido.
- Menú principal, créditos y opciones completos.
- Exportación web y pruebas de red fuera del equipo local.

## Decisiones todavía pendientes

- Confirmación de los diálogos definitivos con base en el soporte primario del relato.
- Observaciones de las mesas de IA y Redes.
- Resultado de la primera auditoría de Seguridad.
- Evidencias reales obtenidas al ejecutar el prototipo en los equipos del grupo.
