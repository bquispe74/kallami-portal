# Recorrido de demostración final

## Preparación

Inicia FastAPI, abre Godot y crea dos perfiles: `DemoInicio` y `DemoFinal`. Usa PIN distintos que puedas recordar. El primero sirve para enseñar el flujo narrativo; el segundo puede quedar cerca del portal para grabar el clímax.

## Ruta principal

1. En **Nivel 1 – La comunidad**, camina hacia Florencio y pulsa `E`.
2. Deja reproducir una línea completa para mostrar la voz y la boca animada; después usa `E` para acelerar.
3. Cruza el pueblo, muestra una sombra con `F` y entra por el portal de la cumbre.
4. En **Nivel 2 – El ascenso**, recoge **Memoria de la comunidad** en la parte baja.
5. Cruza el puente, activa el checkpoint y recoge **Señal de los mineros**.
6. Continúa por la niebla, recoge **Relato del cerro** y entra al portal superior.
7. En **Nivel 3 – La cámara de plata**, dispersa a los dos guardianes; requieren cuatro impactos cada uno.
8. Activa los pedestales en el orden narrativo: comunidad, mineros y cerro.
9. Cuando desaparezca el sello, acércate al altar para mostrar `KALLAMI RESTAURADO`.

## Prueba de perfiles

1. En `DemoInicio`, llega al Nivel 2, recoge una memoria, pierde dos puntos de vida y pulsa `G`.
2. Cierra el juego y vuelve a abrirlo.
3. Entra a `DemoFinal`: debe cargar su posición y estado propios.
4. Reinicia y entra a `DemoInicio`: debe conservar nivel, memoria, vida y posición, sin mezclarse con el otro perfil.

## Si algo no responde

- **No aparece la interacción:** acércate hasta ver la indicación amarilla y haz clic dentro de la ventana.
- **No lanza la piedra:** espera medio segundo entre pulsaciones de `F`.
- **Servidor desconectado:** visita `http://127.0.0.1:8000/api/estado` y reinicia `iniciar_servidor.sh`.
- **PIN rechazado:** usa exactamente cuatro números y confirma que seleccionaste el perfil correcto.
- **No se restaura:** espera el mensaje verde de guardado antes de cerrar la ejecución.
