# Guía de demostración de la Semana 2

Duración sugerida: entre tres y cuatro minutos.

## Preparación

1. Iniciar FastAPI y mostrar `/api/estado`.
2. Abrir el proyecto en Godot con Compatibility.
3. Mantener visible la terminal del servidor para mostrar solicitudes.
4. Presionar `N` en la portada para generar una partida nueva antes de grabar.

## Secuencia

| Tiempo | Demostración | Responsable sugerido |
|---|---|---|
| 0:00-0:30 | Explicar el objetivo del Alpha y la arquitectura cliente-servidor. | Douglas |
| 0:30-1:20 | Mostrar movimiento, cámara y colisiones. | Brayan |
| 1:20-2:00 | Interactuar con Florencio y activar la misión. | Brayan |
| 2:00-2:40 | Mostrar checkpoint y al menos dos de las cinco sombras. | Brayan |
| 2:40-3:10 | Llegar a los cultivos del sureste, recoger la pista y regresar a la salida. | Brayan |
| 3:10-3:40 | Presionar G, esperar el guardado, salir con F8 y demostrar la recuperación exacta. | Douglas |
| 3:40-4:00 | Indicar límites, pruebas y siguiente iteración. | Equipo |

## Evidencias que deben capturarse

- Proyecto abierto en Godot y árbol del sistema de archivos.
- Ventana jugable con HUD.
- Diálogo con Florencio.
- Sombra persiguiendo al jugador.
- Mensaje de checkpoint y pista recuperada.
- Estado conectado y progreso guardado.
- Terminal con `POST /api/progreso ... 200 OK`.
- Pausa con `Esc`, verificando que Juan y las sombras quedan inmóviles.
- Confirmación verde del guardado manual con `G`.
- Juego cerrado y abierto nuevamente, recuperando posición, salud, misión, checkpoint, pista y objetivo.
- Como evidencia opcional adicional, tabla SQLite o respuesta de `GET /api/progreso/{player_id}`.
- Resultado de las pruebas automáticas del servidor.

## Demostración clara del guardado

1. Después de hablar con Florencio, deja a Juan en un lugar fácil de reconocer y permite que pierda un punto de salud.
2. Presiona `G` y espera `Progreso guardado en el servidor`.
3. Enfoca brevemente la terminal y muestra `POST /api/progreso ... 200 OK`.
4. Usa `F8`, ejecuta otra vez y presiona `Enter`.
5. Muestra que se conservan la misión, `SALUD: 2/3` y la misma posición aproximada.
6. En la terminal señala `GET /api/progreso/... 200 OK`.
