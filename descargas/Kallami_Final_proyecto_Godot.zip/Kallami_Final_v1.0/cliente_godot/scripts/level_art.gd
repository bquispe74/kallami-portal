extends Node2D

signal exit_reached

const WORLD_SIZE := Vector2(2400, 1500)
const EXIT_POSITION := Vector2(2205, 255)
const CLUE_POSITIONS: Array[Vector2] = [
	Vector2(635, 720),
	Vector2(1650, 1190),
	Vector2(2055, 455)
]

var exit_active := false
var _houses: Array[Rect2] = [
	Rect2(70, 905, 280, 175), Rect2(465, 1015, 275, 175),
	Rect2(840, 1130, 265, 178), Rect2(1220, 1010, 295, 185),
	Rect2(1770, 1125, 300, 180), Rect2(2080, 1000, 250, 165),
	Rect2(180, 370, 260, 170), Rect2(780, 330, 280, 178),
	Rect2(1300, 350, 270, 175)
]
var _walls: Array[Rect2] = []


func _ready() -> void:
	name = "PuebloKallami"
	z_index = -20
	_build_world()
	_build_exit()
	queue_redraw()


func set_exit_active(value: bool) -> void:
	exit_active = value
	queue_redraw()


func _build_world() -> void:
	_add_wall(Rect2(0, 0, 2400, 28))
	_add_wall(Rect2(0, 1472, 2400, 28))
	_add_wall(Rect2(0, 0, 28, 1500))
	_add_wall(Rect2(2372, 0, 28, 1500))
	for house in _houses:
		_add_wall(house)
	# Formaciones que obligan a seguir el sendero sin convertirlo en un pasillo.
	_add_wall(Rect2(500, 160, 230, 115))
	_add_wall(Rect2(1110, 130, 270, 120))
	_add_wall(Rect2(1610, 145, 250, 120))
	_add_wall(Rect2(1430, 650, 160, 95))
	_add_wall(Rect2(1860, 730, 190, 105))


func _add_wall(rect: Rect2) -> void:
	_walls.append(rect)
	var wall := StaticBody2D.new()
	wall.collision_layer = 1
	wall.collision_mask = 0
	wall.position = rect.get_center()
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	wall.add_child(collision)
	add_child(wall)


func _build_exit() -> void:
	var area := Area2D.new()
	area.name = "SalidaCerro"
	area.position = EXIT_POSITION
	area.collision_layer = 8
	area.collision_mask = 1
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 48.0
	collision.shape = shape
	area.add_child(collision)
	add_child(area)
	area.body_entered.connect(func(body: Node2D) -> void:
		if exit_active and body.name == "Juan":
			exit_reached.emit()
	)


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("4b382c"))
	draw_rect(Rect2(28, 28, 2344, 1444), Color("a98758"))
	_draw_ground_texture()
	_draw_mountains()
	_draw_terraces()
	_draw_paths()
	_draw_fields()
	_draw_plaza()
	for house_index in range(_houses.size()):
		_draw_house(_houses[house_index], house_index)
	_draw_stone_walls()
	_draw_market_and_lamps()
	_draw_vegetation_and_rocks()
	_draw_exit()


func _draw_ground_texture() -> void:
	for y in range(48, 1460, 34):
		for x in range(48, 2360, 38):
			var selector := (x * 11 + y * 7) % 17
			if selector < 4:
				var tone := Color("8d6e49") if selector < 2 else Color("bd9862")
				draw_rect(Rect2(x, y, 3, 3), tone)


func _draw_mountains() -> void:
	var far_range := PackedVector2Array([
		Vector2(28, 315), Vector2(28, 170), Vector2(190, 88), Vector2(390, 192),
		Vector2(600, 72), Vector2(805, 205), Vector2(1050, 58), Vector2(1260, 186),
		Vector2(1490, 85), Vector2(1700, 190), Vector2(1940, 66), Vector2(2160, 175),
		Vector2(2372, 105), Vector2(2372, 315)
	])
	draw_colored_polygon(far_range, Color("74634e"))
	var kallami := PackedVector2Array([
		Vector2(1110, 312), Vector2(1330, 185), Vector2(1560, 35),
		Vector2(1770, 175), Vector2(2010, 312)
	])
	draw_colored_polygon(kallami, Color("62473d"))
	draw_colored_polygon(PackedVector2Array([
		Vector2(1470, 94), Vector2(1560, 35), Vector2(1645, 91),
		Vector2(1590, 78), Vector2(1548, 112), Vector2(1512, 79)
	]), Color("d8d4c7"))
	draw_line(Vector2(28, 312), Vector2(2372, 312), Color("4a4036"), 7)


func _draw_terraces() -> void:
	for terrace_index in range(6):
		var y := 315 + terrace_index * 38
		var from := Vector2(1540 + terrace_index * 32, y)
		var to := Vector2(2320, y - 30)
		draw_line(from, to, Color("5b5146"), 8)
		for x in range(int(from.x + 16), int(to.x), 34):
			draw_circle(Vector2(x, lerpf(from.y, to.y, (x - from.x) / (to.x - from.x))), 5, Color("867b6b"))


func _draw_paths() -> void:
	var main_path := PackedVector2Array([
		Vector2(210, 1280), Vector2(420, 1240), Vector2(760, 1360),
		Vector2(780, 1050), Vector2(950, 1010), Vector2(1060, 835), Vector2(1280, 790),
		Vector2(1510, 850), Vector2(1670, 1030), Vector2(1660, 1190),
		Vector2(1850, 1040), Vector2(2130, 900), Vector2(2180, 650),
		Vector2(2055, 455), Vector2(2205, 255)
	])
	_draw_path(main_path, 128.0)
	var community_branch := PackedVector2Array([
		Vector2(950, 1010), Vector2(820, 830), Vector2(635, 720), Vector2(480, 620)
	])
	_draw_path(community_branch, 92.0)
	var plaza_branch := PackedVector2Array([
		Vector2(1060, 835), Vector2(1160, 600), Vector2(1320, 520), Vector2(1450, 560)
	])
	_draw_path(plaza_branch, 82.0)


func _draw_path(points: PackedVector2Array, width: float) -> void:
	draw_polyline(points, Color("6b503a"), width + 18.0, true)
	draw_polyline(points, Color("c4a36d"), width, true)
	draw_polyline(points, Color("e2c88f"), 5.0, true)
	for index in range(points.size() - 1):
		var middle := points[index].lerp(points[index + 1], 0.5)
		draw_circle(middle + Vector2(13, -8), 5, Color("857055"))


func _draw_fields() -> void:
	var fields: Array[Rect2] = [
		Rect2(370, 1110, 350, 160), Rect2(1120, 1195, 410, 210),
		Rect2(1545, 1260, 430, 150), Rect2(1970, 1190, 340, 190),
		Rect2(500, 430, 330, 150)
	]
	for field in fields:
		draw_rect(field, Color("777442"))
		draw_rect(field.grow(-7), Color("afa255"), false, 4)
		for furrow_y in range(int(field.position.y + 16), int(field.end.y - 8), 19):
			draw_line(Vector2(field.position.x + 12, furrow_y), Vector2(field.end.x - 12, furrow_y), Color("cbb466"), 4)


func _draw_plaza() -> void:
	var plaza := Rect2(860, 725, 480, 285)
	draw_rect(plaza, Color("796958"))
	draw_rect(plaza.grow(-8), Color("9c8464"), false, 6)
	for stone_y in range(int(plaza.position.y + 16), int(plaza.end.y - 8), 26):
		var offset := 13 if int(stone_y / 26) % 2 == 0 else 0
		for stone_x in range(int(plaza.position.x + 14 + offset), int(plaza.end.x - 8), 30):
			draw_custom_ellipse(Vector2(stone_x, stone_y), Vector2(11, 6), Color(0.33, 0.29, 0.25, 0.55))
	# Fuente seca de la plaza.
	draw_circle(Vector2(1095, 865), 54, Color("50483f"))
	draw_circle(Vector2(1095, 865), 43, Color("7a7064"))
	draw_circle(Vector2(1095, 865), 29, Color("55727d"))
	draw_circle(Vector2(1095, 865), 12, Color("a7a095"))


func _draw_house(rect: Rect2, house_index: int) -> void:
	draw_rect(Rect2(rect.position + Vector2(14, 18), rect.size), Color(0.12, 0.08, 0.06, 0.34))
	draw_rect(rect, Color("664635"))
	draw_rect(rect.grow(-7), Color("926744"))
	for row_y in range(int(rect.position.y + 12), int(rect.end.y - 10), 22):
		var offset := 11 if int(row_y / 22) % 2 == 0 else 0
		for brick_x in range(int(rect.position.x + offset), int(rect.end.x), 42):
			draw_line(Vector2(brick_x, row_y), Vector2(mini(brick_x + 34, int(rect.end.x)), row_y), Color("ab7951"), 2)
	var roof_color := Color("b48b4f") if house_index % 3 != 1 else Color("913e35")
	var roof := Rect2(rect.position + Vector2(-14, -26), Vector2(rect.size.x + 28, 36))
	draw_rect(roof, Color("493229"))
	draw_rect(roof.grow(-5), roof_color)
	for roof_x in range(int(roof.position.x + 7), int(roof.end.x - 6), 20):
		draw_line(Vector2(roof_x, roof.position.y + 5), Vector2(roof_x + 10, roof.end.y - 5), Color(0.22, 0.13, 0.09, 0.38), 2)
	var door := Rect2(rect.get_center() + Vector2(-20, 11), Vector2(40, rect.size.y * 0.45))
	draw_rect(door, Color("35261f"))
	draw_rect(Rect2(rect.position + Vector2(25, 47), Vector2(33, 31)), Color("20303c"))
	draw_rect(Rect2(rect.position + Vector2(30, 52), Vector2(23, 21)), Color("d2aa58"))
	if house_index % 2 == 0:
		var chimney := rect.position + Vector2(rect.size.x - 52, -43)
		draw_rect(Rect2(chimney, Vector2(21, 35)), Color("493329"))
		draw_circle(chimney + Vector2(10, -10), 11, Color(0.72, 0.70, 0.64, 0.24))
		draw_circle(chimney + Vector2(19, -28), 15, Color(0.74, 0.72, 0.67, 0.17))


func _draw_stone_walls() -> void:
	var segments: Array[Rect2] = [
		Rect2(365, 1080, 290, 18), Rect2(760, 1060, 250, 18),
		Rect2(1380, 950, 310, 18), Rect2(1710, 985, 250, 18),
		Rect2(455, 600, 250, 18), Rect2(1650, 600, 330, 18)
	]
	for segment in segments:
		draw_rect(segment, Color("4b4640"))
		for stone_x in range(int(segment.position.x + 5), int(segment.end.x - 4), 24):
			draw_circle(Vector2(stone_x, segment.position.y + 9), 8, Color("777065"))
			draw_circle(Vector2(stone_x - 2, segment.position.y + 6), 2, Color("a1988a"))


func _draw_market_and_lamps() -> void:
	# Puesto comunal y mantas para que el mapa se lea como un pueblo habitado.
	draw_rect(Rect2(1360, 805, 170, 18), Color("55392b"))
	draw_colored_polygon(PackedVector2Array([Vector2(1345, 805), Vector2(1545, 805), Vector2(1518, 750), Vector2(1370, 750)]), Color("8e3d34"))
	for stripe_x in range(1380, 1520, 34):
		draw_line(Vector2(stripe_x, 758), Vector2(stripe_x + 18, 800), Color("d6a452"), 8)
	var lamps: Array[Vector2] = [
		Vector2(420, 1140), Vector2(790, 1040), Vector2(1010, 740),
		Vector2(1360, 760), Vector2(1720, 1030), Vector2(2080, 845),
		Vector2(2040, 500), Vector2(2200, 330)
	]
	for lamp in lamps:
		draw_line(lamp, lamp + Vector2(0, -48), Color("3c2d25"), 6)
		draw_rect(Rect2(lamp + Vector2(-9, -61), Vector2(18, 18)), Color("35414b"))
		draw_rect(Rect2(lamp + Vector2(-5, -57), Vector2(10, 10)), Color("f0c967"))
		draw_circle(lamp + Vector2(0, -52), 28, Color(0.96, 0.72, 0.25, 0.09))


func _draw_vegetation_and_rocks() -> void:
	for x in range(58, 2350, 82):
		var y := 560 + int(62.0 * sin(float(x) * 0.026))
		draw_line(Vector2(x, y), Vector2(x + 6, y - 25), Color("696a39"), 4)
		draw_line(Vector2(x + 7, y), Vector2(x + 14, y - 21), Color("8a8444"), 4)
		draw_line(Vector2(x + 13, y), Vector2(x + 19, y - 16), Color("b1a65d"), 3)
	var rocks: Array[Vector2] = [
		Vector2(390, 720), Vector2(540, 1340), Vector2(770, 650), Vector2(910, 550),
		Vector2(1260, 660), Vector2(1470, 890), Vector2(1760, 620), Vector2(1960, 920),
		Vector2(2160, 690), Vector2(2250, 420), Vector2(1550, 1370), Vector2(900, 1390)
	]
	for point in rocks:
		draw_circle(point, 24, Color("514c47"))
		draw_circle(point + Vector2(-7, -7), 12, Color("7a7369"))
		draw_circle(point + Vector2(-11, -11), 4, Color("aaa093"))


func _draw_clue_shrine(center: Vector2, clue_index: int) -> void:
	var accent_colors: Array[Color] = [Color("78a6b8"), Color("bf9b51"), Color("8d76b8")]
	var accent: Color = accent_colors[clue_index]
	draw_circle(center + Vector2(0, 17), 43, Color(0.12, 0.10, 0.09, 0.33))
	draw_rect(Rect2(center + Vector2(-34, 14), Vector2(68, 15)), Color("555149"))
	draw_rect(Rect2(center + Vector2(-25, 0), Vector2(50, 15)), Color("777066"))
	draw_rect(Rect2(center + Vector2(-15, -15), Vector2(30, 16)), Color("968c7e"))
	draw_arc(center + Vector2(0, -12), 29, PI, TAU, 18, accent, 4)


func _draw_exit() -> void:
	var exit_color := Color("f0ce65") if exit_active else Color("55565a")
	draw_rect(Rect2(EXIT_POSITION - Vector2(48, 58), Vector2(96, 116)), Color(exit_color.r, exit_color.g, exit_color.b, 0.12))
	draw_arc(EXIT_POSITION, 52, 0, TAU, 36, exit_color, 6)
	draw_arc(EXIT_POSITION, 38, 0, TAU, 36, Color(exit_color.r, exit_color.g, exit_color.b, 0.40), 4)
	if exit_active:
		for ray_index in range(8):
			var angle := TAU * float(ray_index) / 8.0
			draw_line(EXIT_POSITION + Vector2.from_angle(angle) * 58, EXIT_POSITION + Vector2.from_angle(angle) * 76, Color(0.95, 0.80, 0.34, 0.62), 3)


func draw_custom_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for index in range(24):
		var angle := TAU * float(index) / 24.0
		points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
	draw_colored_polygon(points, color)
