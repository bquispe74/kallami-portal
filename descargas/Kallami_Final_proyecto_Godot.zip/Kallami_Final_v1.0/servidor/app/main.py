from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import unicodedata
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from fastapi import FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


ROOT = Path(__file__).resolve().parents[1]
DATABASE_PATH = Path(os.getenv("KALLAMI_DATABASE", ROOT / "data" / "kallami_final.db"))
ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "KALLAMI_ALLOWED_ORIGINS",
        "http://localhost:8060,http://127.0.0.1:8060",
    ).split(",")
    if origin.strip()
]

WORLD_X = (28.0, 2372.0)
WORLD_Y = (28.0, 1472.0)
CHECKPOINTS_BY_LEVEL = {
    1: {"inicio", "plaza", "cerro"},
    2: {"ascenso_inicio", "ascenso_medio"},
    3: {"camara_inicio", "camara_final"},
}
ALLOWED_CLUES = {"pista_comunidad", "pista_mineros", "pista_cerro"}
PIN_ITERATIONS = 210_000


class ProfileCreate(BaseModel):
    display_name: str = Field(min_length=2, max_length=24)
    pin: str = Field(pattern=r"^\d{4}$")


class ProfileLogin(BaseModel):
    profile_id: str = Field(min_length=8, max_length=80, pattern=r"^[a-z0-9_-]+$")
    pin: str = Field(pattern=r"^\d{4}$")


class ProfileDelete(BaseModel):
    pin: str = Field(pattern=r"^\d{4}$")


class ProfileOut(BaseModel):
    profile_id: str
    display_name: str
    created_at: str
    updated_at: str


class SessionOut(BaseModel):
    profile: ProfileOut
    access_token: str
    token_type: str = "bearer"


class ProgressIn(BaseModel):
    player_id: str = Field(min_length=8, max_length=80, pattern=r"^[a-z0-9_-]+$")
    level: int = Field(ge=1, le=3)
    clues: int = Field(ge=0, le=3)
    clue_ids: list[str] = Field(default_factory=list, max_length=3)
    checkpoint_id: str = Field(min_length=3, max_length=40)
    completed: bool = False
    health: int = Field(default=5, ge=1, le=5)
    position_x: float = Field(default=220.0, ge=WORLD_X[0], le=WORLD_X[1])
    position_y: float = Field(default=1260.0, ge=WORLD_Y[0], le=WORLD_Y[1])
    mission_state: int = Field(default=0, ge=0, le=3)
    puzzle_step: int = Field(default=0, ge=0, le=3)


class ProgressOut(ProgressIn):
    updated_at: str


def connect_db() -> sqlite3.Connection:
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def database() -> Iterator[sqlite3.Connection]:
    connection = connect_db()
    try:
        yield connection
    finally:
        connection.close()


def initialize_database() -> None:
    with connect_db() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS profiles (
                profile_id TEXT PRIMARY KEY,
                display_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
                pin_salt TEXT NOT NULL,
                pin_hash TEXT NOT NULL,
                token_hash TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS progress (
                player_id TEXT PRIMARY KEY,
                level INTEGER NOT NULL CHECK(level BETWEEN 1 AND 3),
                clues INTEGER NOT NULL CHECK(clues BETWEEN 0 AND 3),
                clue_ids TEXT NOT NULL DEFAULT '[]',
                checkpoint_id TEXT NOT NULL,
                completed INTEGER NOT NULL DEFAULT 0 CHECK(completed IN (0, 1)),
                health INTEGER NOT NULL DEFAULT 5 CHECK(health BETWEEN 1 AND 5),
                position_x REAL NOT NULL DEFAULT 220.0,
                position_y REAL NOT NULL DEFAULT 1260.0,
                mission_state INTEGER NOT NULL DEFAULT 0 CHECK(mission_state BETWEEN 0 AND 3),
                puzzle_step INTEGER NOT NULL DEFAULT 0 CHECK(puzzle_step BETWEEN 0 AND 3),
                updated_at TEXT NOT NULL,
                FOREIGN KEY(player_id) REFERENCES profiles(profile_id) ON DELETE CASCADE
            )
            """
        )
        columns = {
            row["name"] for row in connection.execute("PRAGMA table_info(progress)").fetchall()
        }
        if "puzzle_step" not in columns:
            connection.execute(
                "ALTER TABLE progress ADD COLUMN puzzle_step INTEGER NOT NULL DEFAULT 0"
            )


@asynccontextmanager
async def lifespan(_app: FastAPI):
    initialize_database()
    yield


app = FastAPI(
    title="Kallami Profile & Progress API",
    version="1.1.0",
    description=(
        "Perfiles protegidos por PIN y persistencia autorizada de la versión final "
        "de Kallami: Senderos de Plata."
    ),
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)


@app.get("/api/estado")
def api_status() -> dict[str, str]:
    return {"estado": "ok", "version": "1.1.0", "perfiles": "habilitados"}


@app.get("/api/perfiles", response_model=list[ProfileOut])
def list_profiles() -> list[ProfileOut]:
    with connect_db() as connection:
        rows = connection.execute(
            "SELECT profile_id, display_name, created_at, updated_at "
            "FROM profiles ORDER BY updated_at DESC"
        ).fetchall()
    return [row_to_profile(row) for row in rows]


@app.post("/api/perfiles", response_model=SessionOut, status_code=status.HTTP_201_CREATED)
def create_profile(payload: ProfileCreate) -> SessionOut:
    display_name = validate_display_name(payload.display_name)
    profile_id = generate_profile_id(display_name)
    salt = secrets.token_hex(16)
    token = secrets.token_urlsafe(32)
    now = utc_now()
    try:
        with connect_db() as connection:
            connection.execute(
                """
                INSERT INTO profiles (
                    profile_id, display_name, pin_salt, pin_hash,
                    token_hash, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    profile_id,
                    display_name,
                    salt,
                    derive_pin(payload.pin, salt),
                    hash_token(token),
                    now,
                    now,
                ),
            )
            insert_default_progress(connection, profile_id, now)
            row = connection.execute(
                "SELECT profile_id, display_name, created_at, updated_at "
                "FROM profiles WHERE profile_id = ?",
                (profile_id,),
            ).fetchone()
    except sqlite3.IntegrityError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Ya existe un perfil con ese nombre.",
        ) from exc
    return SessionOut(profile=row_to_profile(row), access_token=token)


@app.post("/api/perfiles/login", response_model=SessionOut)
def login_profile(payload: ProfileLogin) -> SessionOut:
    with connect_db() as connection:
        row = connection.execute(
            "SELECT * FROM profiles WHERE profile_id = ?",
            (payload.profile_id,),
        ).fetchone()
        if row is None or not verify_pin(payload.pin, row["pin_salt"], row["pin_hash"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Perfil o PIN incorrecto.",
            )
        token = secrets.token_urlsafe(32)
        now = utc_now()
        connection.execute(
            "UPDATE profiles SET token_hash = ?, updated_at = ? WHERE profile_id = ?",
            (hash_token(token), now, payload.profile_id),
        )
        profile_row = connection.execute(
            "SELECT profile_id, display_name, created_at, updated_at "
            "FROM profiles WHERE profile_id = ?",
            (payload.profile_id,),
        ).fetchone()
    return SessionOut(profile=row_to_profile(profile_row), access_token=token)


@app.post("/api/perfiles/{profile_id}/eliminar")
def delete_profile(profile_id: str, payload: ProfileDelete) -> dict[str, str]:
    with connect_db() as connection:
        row = connection.execute(
            "SELECT * FROM profiles WHERE profile_id = ?",
            (profile_id,),
        ).fetchone()
        if row is None or not verify_pin(payload.pin, row["pin_salt"], row["pin_hash"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="No se pudo verificar el PIN del perfil.",
            )
        connection.execute("DELETE FROM profiles WHERE profile_id = ?", (profile_id,))
    return {"estado": "eliminado", "profile_id": profile_id}


@app.get("/api/progreso/{player_id}", response_model=ProgressOut)
def get_progress(
    player_id: str,
    authorization: str | None = Header(default=None),
) -> ProgressOut:
    require_profile(player_id, authorization)
    with connect_db() as connection:
        row = connection.execute(
            "SELECT * FROM progress WHERE player_id = ?",
            (player_id,),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Progreso no encontrado.")
    return row_to_progress(row)


@app.post("/api/progreso", response_model=ProgressOut)
def save_progress(
    payload: ProgressIn,
    authorization: str | None = Header(default=None),
) -> ProgressOut:
    require_profile(payload.player_id, authorization)
    validate_game_rules(payload)
    now = utc_now()
    with connect_db() as connection:
        existing = connection.execute(
            "SELECT * FROM progress WHERE player_id = ?",
            (payload.player_id,),
        ).fetchone()
        if existing is None:
            raise HTTPException(status_code=404, detail="El perfil no tiene una partida inicial.")
        validate_transition(existing, payload)
        connection.execute(
            """
            UPDATE progress SET
                level = ?, clues = ?, clue_ids = ?, checkpoint_id = ?,
                completed = ?, health = ?, position_x = ?, position_y = ?,
                mission_state = ?, puzzle_step = ?, updated_at = ?
            WHERE player_id = ?
            """,
            (
                payload.level,
                payload.clues,
                json.dumps(payload.clue_ids, separators=(",", ":")),
                payload.checkpoint_id,
                int(payload.completed),
                payload.health,
                payload.position_x,
                payload.position_y,
                payload.mission_state,
                payload.puzzle_step,
                now,
                payload.player_id,
            ),
        )
        connection.execute(
            "UPDATE profiles SET updated_at = ? WHERE profile_id = ?",
            (now, payload.player_id),
        )
        saved = connection.execute(
            "SELECT * FROM progress WHERE player_id = ?",
            (payload.player_id,),
        ).fetchone()
    return row_to_progress(saved)


@app.post("/api/progreso/{player_id}/reiniciar", response_model=ProgressOut)
def reset_progress(
    player_id: str,
    authorization: str | None = Header(default=None),
) -> ProgressOut:
    require_profile(player_id, authorization)
    now = utc_now()
    with connect_db() as connection:
        connection.execute("DELETE FROM progress WHERE player_id = ?", (player_id,))
        insert_default_progress(connection, player_id, now)
        connection.execute(
            "UPDATE profiles SET updated_at = ? WHERE profile_id = ?",
            (now, player_id),
        )
        row = connection.execute(
            "SELECT * FROM progress WHERE player_id = ?",
            (player_id,),
        ).fetchone()
    return row_to_progress(row)


def validate_display_name(raw_name: str) -> str:
    name = " ".join(raw_name.strip().split())
    if not 2 <= len(name) <= 24:
        raise HTTPException(status_code=422, detail="El nombre debe tener entre 2 y 24 caracteres.")
    if not re.fullmatch(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9 _-]+", name):
        raise HTTPException(status_code=422, detail="El nombre contiene caracteres no permitidos.")
    return name


def generate_profile_id(display_name: str) -> str:
    normalized = unicodedata.normalize("NFKD", display_name)
    ascii_name = normalized.encode("ascii", "ignore").decode("ascii").lower()
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_name).strip("-")[:32] or "perfil"
    return f"{slug}-{secrets.token_hex(4)}"


def derive_pin(pin: str, salt_hex: str) -> str:
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        pin.encode("utf-8"),
        bytes.fromhex(salt_hex),
        PIN_ITERATIONS,
    )
    return digest.hex()


def verify_pin(pin: str, salt_hex: str, expected_hash: str) -> bool:
    return hmac.compare_digest(derive_pin(pin, salt_hex), expected_hash)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def require_profile(profile_id: str, authorization: str | None) -> None:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Se requiere una sesión de perfil.",
        )
    token = authorization.removeprefix("Bearer ").strip()
    with connect_db() as connection:
        row = connection.execute(
            "SELECT token_hash FROM profiles WHERE profile_id = ?",
            (profile_id,),
        ).fetchone()
    if row is None or not hmac.compare_digest(hash_token(token), row["token_hash"]):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="La sesión no pertenece a este perfil.",
        )


def validate_game_rules(payload: ProgressIn) -> None:
    if payload.checkpoint_id not in CHECKPOINTS_BY_LEVEL[payload.level]:
        raise HTTPException(status_code=422, detail="El checkpoint no corresponde al nivel indicado.")
    if len(payload.clue_ids) != len(set(payload.clue_ids)):
        raise HTTPException(status_code=422, detail="Una memoria no puede registrarse dos veces.")
    if not set(payload.clue_ids).issubset(ALLOWED_CLUES):
        raise HTTPException(status_code=422, detail="La partida contiene una memoria desconocida.")
    if payload.clues != len(payload.clue_ids):
        raise HTTPException(status_code=422, detail="El contador no coincide con las memorias verificadas.")
    if payload.mission_state == 0 and payload.clues > 0:
        raise HTTPException(status_code=422, detail="La misión debe iniciarse antes de registrar memorias.")
    if payload.level == 1 and payload.clues > 0:
        raise HTTPException(status_code=422, detail="Las memorias se recuperan durante el ascenso.")
    if payload.mission_state >= 2 and payload.clues != 3:
        raise HTTPException(status_code=409, detail="El regreso requiere las tres memorias.")
    if payload.puzzle_step > 0 and (payload.level != 3 or payload.clues != 3):
        raise HTTPException(status_code=409, detail="El relato final solo puede ordenarse en la cámara.")
    if payload.completed and (
        payload.level != 3
        or payload.clues != 3
        or payload.mission_state != 3
        or payload.puzzle_step != 3
    ):
        raise HTTPException(status_code=409, detail="La partida final exige tres memorias y el portal completado.")


def validate_transition(existing: sqlite3.Row, payload: ProgressIn) -> None:
    old_ids = set(json.loads(existing["clue_ids"] or "[]"))
    new_ids = set(payload.clue_ids)
    if not old_ids.issubset(new_ids):
        raise HTTPException(status_code=409, detail="No se puede retirar una memoria ya confirmada.")
    if len(new_ids) > len(old_ids) + 1:
        raise HTTPException(status_code=409, detail="Las memorias se registran una por una.")
    if payload.level < existing["level"] or payload.level > existing["level"] + 1:
        raise HTTPException(status_code=409, detail="La transición de nivel no es válida.")
    if payload.mission_state < existing["mission_state"]:
        raise HTTPException(status_code=409, detail="No se puede retroceder el estado de la misión.")
    old_puzzle_step = int(existing["puzzle_step"] if "puzzle_step" in existing.keys() else 0)
    if payload.puzzle_step > old_puzzle_step + 1:
        raise HTTPException(status_code=409, detail="Las memorias finales se ordenan una por una.")
    if bool(existing["completed"]) and not payload.completed:
        raise HTTPException(status_code=409, detail="Usa el endpoint de reinicio para una partida nueva.")


def insert_default_progress(connection: sqlite3.Connection, profile_id: str, now: str) -> None:
    connection.execute(
        """
        INSERT INTO progress (
            player_id, level, clues, clue_ids, checkpoint_id, completed,
            health, position_x, position_y, mission_state, puzzle_step, updated_at
        ) VALUES (?, 1, 0, '[]', 'inicio', 0, 5, 220.0, 1260.0, 0, 0, ?)
        """,
        (profile_id, now),
    )


def row_to_profile(row: sqlite3.Row) -> ProfileOut:
    return ProfileOut(
        profile_id=row["profile_id"],
        display_name=row["display_name"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def row_to_progress(row: sqlite3.Row) -> ProgressOut:
    return ProgressOut(
        player_id=row["player_id"],
        level=row["level"],
        clues=row["clues"],
        clue_ids=json.loads(row["clue_ids"] or "[]"),
        checkpoint_id=row["checkpoint_id"],
        completed=bool(row["completed"]),
        health=row["health"],
        position_x=row["position_x"],
        position_y=row["position_y"],
        mission_state=row["mission_state"],
        puzzle_step=row["puzzle_step"],
        updated_at=row["updated_at"],
    )


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()
