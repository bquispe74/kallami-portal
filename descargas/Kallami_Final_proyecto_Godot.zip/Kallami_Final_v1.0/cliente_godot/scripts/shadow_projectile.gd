extends Area2D

signal impacted(world_position: Vector2, hit_player: bool)

var direction := Vector2.RIGHT
var speed := 330.0
var maximum_distance := 520.0
var guardian_shot := false
var _start_position := Vector2.ZERO
var _life := 0.0
var _finished := false


func _ready() -> void:
	name = "EcoDeSombra"
	z_index = 28
	_start_position = global_position
	collision_layer = 32
	collision_mask = 1
	monitoring = true
	var collision := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 10.0 if guardian_shot else 8.0
	collision.shape = shape
	add_child(collision)
	body_entered.connect(_on_body_entered)
	queue_redraw()


func launch(new_direction: Vector2, from_guardian: bool = false) -> void:
	direction = new_direction.normalized()
	guardian_shot = from_guardian
	speed = 360.0 if guardian_shot else 315.0
	maximum_distance = 600.0 if guardian_shot else 520.0


func _physics_process(delta: float) -> void:
	if _finished:
		return
	position += direction * speed * delta
	_life += delta
	queue_redraw()
	if global_position.distance_to(_start_position) >= maximum_distance:
		_finish(false)


func _on_body_entered(body: Node2D) -> void:
	if _finished:
		return
	if body.name == "Juan" and body.has_method("receive_damage"):
		var damaged: bool = bool(body.receive_damage(1))
		_finish(damaged)
	else:
		_finish(false)


func _finish(hit_player: bool) -> void:
	if _finished:
		return
	_finished = true
	set_deferred("monitoring", false)
	impacted.emit(global_position, hit_player)
	queue_free()


func _draw() -> void:
	var base_color := Color("e3a1ff") if not guardian_shot else Color("ffd56f")
	var radius := 8.0 if not guardian_shot else 11.0
	var pulse := 1.0 + sin(_life * 20.0) * 0.15
	for trail_index in range(3):
		var trail_position := -direction * (14.0 + float(trail_index) * 13.0)
		var trail_alpha := 0.36 - float(trail_index) * 0.09
		draw_circle(trail_position, radius * (0.65 - float(trail_index) * 0.12), Color(base_color.r, base_color.g, base_color.b, trail_alpha))
	draw_circle(Vector2.ZERO, radius * pulse, Color(0.09, 0.04, 0.14, 0.92))
	draw_arc(Vector2.ZERO, radius + 3.0, _life * 7.0, _life * 7.0 + PI * 1.45, 14, base_color, 2.5)
	draw_circle(Vector2.ZERO, 3.0 + (2.0 if guardian_shot else 0.0), base_color)
